/// Endpoint bisa diganti saat build tanpa edit source:
/// flutter build apk --release \\
///   --dart-define=API_BASE_URL=http://domain-kamu:9325
///
/// Chat All sekarang memakai WebSocket API UTAMA yang sama.
/// Kalau reverse proxy/domain kamu berbeda, cukup ubah API_BASE_URL.
const String baseUrl = String.fromEnvironment(
  'API_BASE_URL',
  defaultValue: 'http://host.asta-official.my.id:9325',
);

Uri get apiBaseUri => Uri.parse(baseUrl);

/// WebSocket API utama memakai host/port yang sama dengan HTTP API,
/// tetapi skemanya harus ws/wss.
String get mainWsUrl {
  final uri = apiBaseUri;
  final scheme = uri.scheme == 'https' ? 'wss' : 'ws';
  return uri.replace(scheme: scheme).toString();
}

/// Chat All tidak lagi memakai server/port terpisah.
String get chatWsUrl => mainWsUrl;

/// Endpoint health Chat All memakai endpoint history yang sudah ada di API utama.
Uri chatHealthUri(String sessionKey) {
  return Uri.parse('$baseUrl/api/chat/messages').replace(
    queryParameters: {'session_key': sessionKey},
  );
}
