import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';

import 'fang_global_theme.dart';

class PortScannerPage extends StatefulWidget {
  const PortScannerPage({super.key});

  @override
  State<PortScannerPage> createState() => _PortScannerPageState();
}

class _PortScannerPageState extends State<PortScannerPage> {
  final _hostController = TextEditingController();
  final _portsController = TextEditingController(text: '22,80,443,3000,8080');

  bool _loading = false;
  String? _error;
  List<_PortResult> _results = const [];

  @override
  void dispose() {
    _hostController.dispose();
    _portsController.dispose();
    super.dispose();
  }

  List<int> _parsePorts(String raw) {
    final values = raw
        .split(RegExp(r'[,\s]+'))
        .map((e) => int.tryParse(e.trim()))
        .whereType<int>()
        .where((p) => p >= 1 && p <= 65535)
        .toSet()
        .toList()
      ..sort();
    if (values.length > 12) return values.take(12).toList();
    return values;
  }

  Future<void> _check() async {
    final host = _hostController.text.trim();
    final ports = _parsePorts(_portsController.text);
    if (host.isEmpty) {
      setState(() => _error = 'Isi host/domain terlebih dahulu.');
      return;
    }
    if (ports.isEmpty) {
      setState(() => _error = 'Masukkan minimal satu port valid.');
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
      _results = const [];
    });

    try {
      final resolved = await InternetAddress.lookup(host)
          .timeout(const Duration(seconds: 5));
      if (resolved.isEmpty) throw Exception('Host tidak dapat di-resolve.');
      final address = resolved.first.address;

      final results = <_PortResult>[];
      for (final port in ports) {
        final sw = Stopwatch()..start();
        Socket? socket;
        try {
          socket = await Socket.connect(
            address,
            port,
            timeout: const Duration(milliseconds: 900),
          );
          sw.stop();
          results.add(_PortResult(
            port: port,
            open: true,
            latencyMs: sw.elapsedMilliseconds,
            service: _service(port),
          ));
        } catch (_) {
          sw.stop();
          results.add(_PortResult(
            port: port,
            open: false,
            latencyMs: sw.elapsedMilliseconds,
            service: _service(port),
          ));
        } finally {
          socket?.destroy();
        }
        if (mounted) setState(() => _results = List.of(results));
      }
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _service(int port) {
    const map = <int, String>{
      20: 'FTP data',
      21: 'FTP',
      22: 'SSH',
      25: 'SMTP',
      53: 'DNS',
      80: 'HTTP',
      110: 'POP3',
      143: 'IMAP',
      443: 'HTTPS',
      465: 'SMTPS',
      587: 'SMTP submission',
      993: 'IMAPS',
      995: 'POP3S',
      3000: 'App / dev',
      3306: 'MySQL',
      5432: 'PostgreSQL',
      6379: 'Redis',
      8080: 'HTTP alt',
      8443: 'HTTPS alt',
    };
    return map[port] ?? 'Unknown';
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: FangThemeController.instance,
      builder: (context, _) {
        final fang = FangThemeController.instance.config;
        return Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            title: const Text('Port Checker',
                style: TextStyle(fontWeight: FontWeight.w800)),
          ),
          body: FangBackground(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
              children: [
                FangCard(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      TextField(
                        controller: _hostController,
                        textInputAction: TextInputAction.next,
                        decoration: const InputDecoration(
                          labelText: 'Host / domain',
                          hintText: 'example.com atau 192.168.1.1',
                          prefixIcon: Icon(Icons.language_rounded),
                        ),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: _portsController,
                        keyboardType: TextInputType.number,
                        textInputAction: TextInputAction.done,
                        onSubmitted: (_) => _check(),
                        decoration: const InputDecoration(
                          labelText: 'Port (maks. 12)',
                          hintText: '22,80,443,8080',
                          prefixIcon: Icon(Icons.settings_ethernet_rounded),
                        ),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: _loading ? null : _check,
                          icon: _loading
                              ? const SizedBox(
                                  width: 16,
                                  height: 16,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white,
                                  ),
                                )
                              : const Icon(Icons.network_check_rounded),
                          label: const Text('CHECK PORTS'),
                        ),
                      ),
                    ],
                  ),
                ),
                if (_error != null) ...[
                  const SizedBox(height: 12),
                  FangCard(
                    padding: const EdgeInsets.all(14),
                    child: Text(_error!,
                        style: const TextStyle(color: Color(0xFFFF8A8A))),
                  ),
                ],
                if (_results.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  ..._results.map((result) => Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: FangCard(
                          padding: const EdgeInsets.all(14),
                          child: Row(
                            children: [
                              Icon(
                                result.open
                                    ? Icons.lock_open_rounded
                                    : Icons.lock_rounded,
                                color: result.open
                                    ? const Color(0xFF41F5B2)
                                    : Colors.white38,
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('${result.port} · ${result.service}',
                                        style: const TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.w800)),
                                    const SizedBox(height: 3),
                                    Text(
                                      result.open
                                          ? 'OPEN · ${result.latencyMs} ms'
                                          : 'CLOSED / FILTERED',
                                      style: TextStyle(
                                          color: result.open
                                              ? const Color(0xFF41F5B2)
                                              : fang.textSecondary,
                                          fontSize: 10.5),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      )),
                ],
                const SizedBox(height: 10),
                Text(
                  'Gunakan hanya untuk server/perangkat yang kamu miliki atau punya izin untuk diperiksa. '
                  'Checker dibatasi maksimal 12 port per sekali jalan.',
                  style: TextStyle(
                    color: fang.textSecondary,
                    fontSize: 10.5,
                    height: 1.45,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _PortResult {
  final int port;
  final bool open;
  final int latencyMs;
  final String service;

  const _PortResult({
    required this.port,
    required this.open,
    required this.latencyMs,
    required this.service,
  });
}
