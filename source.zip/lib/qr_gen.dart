import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:path_provider/path_provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:share_plus/share_plus.dart';

import 'fang_global_theme.dart';

class QrGeneratorPage extends StatefulWidget {
  const QrGeneratorPage({super.key});

  @override
  State<QrGeneratorPage> createState() => _QrGeneratorPageState();
}

class _QrGeneratorPageState extends State<QrGeneratorPage> {
  final TextEditingController _controller = TextEditingController();
  final GlobalKey _qrKey = GlobalKey();

  String? _value;
  bool _sharing = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _generate() {
    final text = _controller.text.trim();
    if (text.isEmpty) {
      _snack('Isi teks atau URL terlebih dahulu.', error: true);
      return;
    }
    setState(() => _value = text);
  }

  Future<File> _exportQr() async {
    final boundary = _qrKey.currentContext?.findRenderObject()
        as RenderRepaintBoundary?;
    if (boundary == null) {
      throw Exception('QR belum siap diekspor.');
    }

    final ui.Image image = await boundary.toImage(pixelRatio: 3);
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    if (data == null) throw Exception('Gagal membuat PNG QR.');

    final dir = await getTemporaryDirectory();
    final file = File(
      '${dir.path}/fang_qr_${DateTime.now().millisecondsSinceEpoch}.png',
    );
    await file.writeAsBytes(data.buffer.asUint8List(), flush: true);
    return file;
  }

  Future<void> _share() async {
    if (_value == null) return;
    setState(() => _sharing = true);
    try {
      final file = await _exportQr();
      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'QR Code: $_value',
      );
    } catch (e) {
      if (mounted) _snack('Gagal membagikan QR: $e', error: true);
    } finally {
      if (mounted) setState(() => _sharing = false);
    }
  }

  void _snack(String text, {bool error = false}) {
    final fang = FangThemeController.instance.config;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text),
        backgroundColor:
            error ? const Color(0xFFB42318) : fang.accentColor,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: FangThemeController.instance,
      builder: (context, _) {
        final fang = FangThemeController.instance.config;
        return Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            title: const Text(
              'QR Generator',
              style: TextStyle(fontWeight: FontWeight.w800),
            ),
          ),
          body: FangBackground(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
              children: [
                FangCard(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const FangNeonIcon(icon: Icons.qr_code_2_rounded),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'QR OFFLINE',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                                Text(
                                  'Tidak memakai API pihak ketiga. QR dibuat langsung di perangkat.',
                                  style: TextStyle(
                                    color: fang.textSecondary,
                                    fontSize: 11,
                                    height: 1.4,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: _controller,
                        minLines: 2,
                        maxLines: 5,
                        textInputAction: TextInputAction.done,
                        onSubmitted: (_) => _generate(),
                        decoration: const InputDecoration(
                          labelText: 'Teks / URL',
                          hintText: 'https://example.com atau teks bebas',
                          prefixIcon: Icon(Icons.edit_rounded),
                        ),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: _generate,
                          icon: const Icon(Icons.auto_awesome_rounded),
                          label: const Text('BUAT QR'),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                if (_value != null)
                  FangCard(
                    strongerGlow: true,
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      children: [
                        RepaintBoundary(
                          key: _qrKey,
                          child: Container(
                            color: Colors.white,
                            padding: const EdgeInsets.all(16),
                            child: QrImageView(
                              data: _value!,
                              version: QrVersions.auto,
                              size: 230,
                              backgroundColor: Colors.white,
                              eyeStyle: const QrEyeStyle(
                                eyeShape: QrEyeShape.square,
                                color: Colors.black,
                              ),
                              dataModuleStyle: const QrDataModuleStyle(
                                dataModuleShape: QrDataModuleShape.square,
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 14),
                        SelectableText(
                          _value!,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: fang.textSecondary,
                            fontSize: 11,
                          ),
                        ),
                        const SizedBox(height: 14),
                        SizedBox(
                          width: double.infinity,
                          child: OutlinedButton.icon(
                            onPressed: _sharing ? null : _share,
                            icon: _sharing
                                ? const SizedBox(
                                    width: 16,
                                    height: 16,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                    ),
                                  )
                                : const Icon(Icons.share_rounded),
                            label: const Text('BAGIKAN PNG'),
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }
}
