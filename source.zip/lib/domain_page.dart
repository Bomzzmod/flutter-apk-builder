import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'fang_global_theme.dart';
import 'tool_api_client.dart';

class DomainOsintPage extends StatefulWidget {
  const DomainOsintPage({super.key});

  @override
  State<DomainOsintPage> createState() => _DomainOsintPageState();
}

class _DomainOsintPageState extends State<DomainOsintPage> {
  final _controller = TextEditingController();
  bool _loading = false;
  String? _error;
  Map<String, List<_DnsRecord>> _records = const {};

  static const _types = ['A', 'AAAA', 'MX', 'NS', 'TXT', 'CNAME'];

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  String _normalizeDomain(String input) {
    var value = input.trim().toLowerCase();
    if (value.startsWith('http://') || value.startsWith('https://')) {
      try {
        value = Uri.parse(value).host;
      } catch (_) {}
    }
    value = value.split('/').first;
    if (value.startsWith('www.')) value = value.substring(4);
    return value;
  }

  bool _validDomain(String value) {
    return RegExp(
      r'^(?=.{1,253}$)(?!-)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$',
      caseSensitive: false,
    ).hasMatch(value);
  }

  Future<void> _check() async {
    final domain = _normalizeDomain(_controller.text);
    if (!_validDomain(domain)) {
      setState(() {
        _error = 'Domain tidak valid. Contoh: example.com';
        _records = const {};
      });
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
      _records = const {};
    });

    try {
      final futures = _types.map((type) async {
        try {
          final data = await ToolApiClient.instance.dnsQuery(domain, type);
          return MapEntry(type, _parse(type, data));
        } catch (_) {
          return MapEntry(type, <_DnsRecord>[]);
        }
      });
      final result = await Future.wait(futures);
      if (!mounted) return;
      setState(() => _records = Map.fromEntries(result));
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  List<_DnsRecord> _parse(String type, Map<String, dynamic> json) {
    final raw = json['Answer'];
    if (raw is! List) return const [];
    return raw.whereType<Map>().map((record) {
      return _DnsRecord(
        type: type,
        value: record['data']?.toString() ?? '-',
        ttl: int.tryParse(record['TTL']?.toString() ?? '') ?? 0,
      );
    }).toList(growable: false);
  }

  void _copy(String value) {
    Clipboard.setData(ClipboardData(text: value));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Disalin ke clipboard'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: FangThemeController.instance,
      builder: (context, _) {
        final fang = FangThemeController.instance.config;
        final total = _records.values.fold<int>(0, (a, b) => a + b.length);
        return Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            title: const Text('Domain DNS',
                style: TextStyle(fontWeight: FontWeight.w800)),
          ),
          body: FangBackground(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
              children: [
                FangCard(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      TextField(
                        controller: _controller,
                        keyboardType: TextInputType.url,
                        textInputAction: TextInputAction.search,
                        onSubmitted: (_) => _check(),
                        decoration: const InputDecoration(
                          labelText: 'Domain',
                          hintText: 'example.com',
                          prefixIcon: Icon(Icons.language_rounded),
                        ),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: _loading ? null : _check,
                          icon: _loading
                              ? const SizedBox(
                                  width: 16,
                                  height: 16,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white,
                                  ),
                                )
                              : const Icon(Icons.dns_rounded),
                          label: const Text('CEK DNS'),
                        ),
                      ),
                    ],
                  ),
                ),
                if (_error != null) ...[
                  const SizedBox(height: 14),
                  FangCard(
                    padding: const EdgeInsets.all(14),
                    child: Text(_error!,
                        style: const TextStyle(color: Color(0xFFFF8A8A))),
                  ),
                ],
                if (!_loading && _records.isNotEmpty) ...[
                  const SizedBox(height: 14),
                  FangCard(
                    strongerGlow: true,
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        const FangNeonIcon(icon: Icons.hub_rounded),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('DNS RESULT',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w900)),
                              Text('$total record ditemukan',
                                  style: TextStyle(
                                      color: fang.textSecondary,
                                      fontSize: 11)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  ..._types.map((type) => _recordSection(fang, type)),
                ],
                const SizedBox(height: 10),
                Text(
                  'DNS diperiksa melalui resolver DNS-over-HTTPS. Hasil mengikuti record publik domain.',
                  style: TextStyle(
                      color: fang.textSecondary, fontSize: 10.5, height: 1.4),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _recordSection(FangThemeConfig fang, String type) {
    final values = _records[type] ?? const [];
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: FangCard(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: fang.accentSoft,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(type,
                      style: TextStyle(
                          color: fang.accentColor,
                          fontSize: 10,
                          fontWeight: FontWeight.w900)),
                ),
                const Spacer(),
                Text('${values.length}',
                    style: TextStyle(color: fang.textSecondary, fontSize: 10)),
              ],
            ),
            const SizedBox(height: 8),
            if (values.isEmpty)
              Text('Tidak ada record.',
                  style: TextStyle(color: fang.textSecondary, fontSize: 11))
            else
              ...values.map((r) => InkWell(
                    onTap: () => _copy(r.value),
                    borderRadius: BorderRadius.circular(10),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 6),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: SelectableText(r.value,
                                style: const TextStyle(
                                    color: Colors.white70, fontSize: 11.5)),
                          ),
                          const SizedBox(width: 8),
                          Text('TTL ${r.ttl}',
                              style: TextStyle(
                                  color: fang.textMuted, fontSize: 9.5)),
                        ],
                      ),
                    ),
                  )),
          ],
        ),
      ),
    );
  }
}

class _DnsRecord {
  final String type;
  final String value;
  final int ttl;

  const _DnsRecord({required this.type, required this.value, required this.ttl});
}
