import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

class FangThemeConfig {
  final String backgroundPreset;
  final String? customBackgroundPath;
  final String customBackgroundType;
  final Color accentColor;
  final Color lisColor;
  final double lisLight;
  final double glowIntensity;
  final double glowBlur;
  final bool showGrid;

  const FangThemeConfig({
    this.backgroundPreset = 'abyss',
    this.customBackgroundPath,
    this.customBackgroundType = 'image',
    this.accentColor = const Color(0xFF9D43FF),
    this.lisColor = const Color(0xFF9D43FF),
    this.lisLight = 0.72,
    this.glowIntensity = 0.68,
    this.glowBlur = 24,
    this.showGrid = false,
  });

  FangThemeConfig copyWith({
    String? backgroundPreset,
    String? customBackgroundPath,
    String? customBackgroundType,
    bool clearCustomBackground = false,
    Color? accentColor,
    Color? lisColor,
    double? lisLight,
    double? glowIntensity,
    double? glowBlur,
    bool? showGrid,
  }) {
    return FangThemeConfig(
      backgroundPreset: backgroundPreset ?? this.backgroundPreset,
      customBackgroundPath: clearCustomBackground
          ? null
          : (customBackgroundPath ?? this.customBackgroundPath),
      customBackgroundType: clearCustomBackground
          ? 'image'
          : (customBackgroundType ?? this.customBackgroundType),
      accentColor: accentColor ?? this.accentColor,
      lisColor: lisColor ?? this.lisColor,
      lisLight: lisLight ?? this.lisLight,
      glowIntensity: glowIntensity ?? this.glowIntensity,
      glowBlur: glowBlur ?? this.glowBlur,
      showGrid: showGrid ?? this.showGrid,
    );
  }

  List<Color> get backgroundColors {
    switch (backgroundPreset) {
      case 'midnight':
        return const [
          Color(0xFF020817),
          Color(0xFF071426),
          Color(0xFF03050D),
        ];
      case 'carbon':
        return const [
          Color(0xFF050505),
          Color(0xFF111111),
          Color(0xFF030303),
        ];
      case 'violet':
        return const [
          Color(0xFF080312),
          Color(0xFF1B0730),
          Color(0xFF05020B),
        ];
      case 'galaxy':
        return const [
          Color(0xFF02040F),
          Color(0xFF100526),
          Color(0xFF06111F),
        ];
      case 'abyss':
      default:
        return const [
          Color(0xFF04030A),
          Color(0xFF0D0718),
          Color(0xFF030207),
        ];
    }
  }

  bool get hasCustomBackground {
    final path = customBackgroundPath;
    return path != null && path.trim().isNotEmpty && File(path).existsSync();
  }

  bool get hasCustomImage =>
      hasCustomBackground && customBackgroundType != 'video';

  bool get hasCustomVideo =>
      hasCustomBackground && customBackgroundType == 'video';

  Color get background => backgroundColors.first;

  Color get surface => Color.alphaBlend(
        accentColor.withOpacity(.055),
        const Color(0xFF09070F),
      );

  Color get surfaceAlt => Color.alphaBlend(
        accentColor.withOpacity(.08),
        const Color(0xFF100B18),
      );

  Color get appBarColor => Color.alphaBlend(
        accentColor.withOpacity(.045),
        const Color(0xFF08060F),
      );

  Color get navigationColor => Color.alphaBlend(
        accentColor.withOpacity(.065),
        const Color(0xFF0B0813),
      );

  // Semua LIS / border neon wajib mengikuti warna theme utama.
  // lisColor tetap disimpan demi kompatibilitas setting versi lama, tetapi tidak
  // lagi menjadi sumber warna terpisah agar tidak ada ungu yang tertinggal.
  Color get neonColor => accentColor;

  double get _neonBoost => lisLight.clamp(.10, 2.00).toDouble();

  Color get borderColor => neonColor.withOpacity(
        (.20 + (.58 * _neonBoost)).clamp(0.0, 1.0).toDouble(),
      );
  Color get weakBorderColor => neonColor.withOpacity(
        (.08 + (.28 * _neonBoost)).clamp(0.0, 1.0).toDouble(),
      );
  Color get accentSoft => accentColor.withOpacity(.14);
  Color get accentMedium => accentColor.withOpacity(.30);
  Color get textPrimary => Colors.white;
  Color get textSecondary => Colors.white60;
  Color get textMuted => Colors.white38;

  List<Color> get accentGradient {
    final hsl = HSLColor.fromColor(accentColor);
    final left = hsl
        .withLightness((hsl.lightness + .10).clamp(0.0, 1.0).toDouble())
        .toColor();
    final right = hsl
        .withLightness((hsl.lightness - .08).clamp(0.0, 1.0).toDouble())
        .toColor();
    return [left, accentColor, right];
  }

  // FANG SHADOW: glow blobs/effects disabled. Neon colors and borders remain.
  BoxShadow glow({
    double multiplier = 1,
    Offset offset = Offset.zero,
    double spreadRadius = -4,
  }) {
    return BoxShadow(
      color: Colors.transparent,
      blurRadius: 0,
      spreadRadius: 0,
      offset: offset,
    );
  }

  ThemeData toThemeData() {
    final scheme = ColorScheme.fromSeed(
      seedColor: accentColor,
      brightness: Brightness.dark,
      surface: surface,
    );

    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: Colors.transparent,
      colorScheme: scheme.copyWith(
        primary: accentColor,
        secondary: accentColor,
        surface: surface,
      ),
      appBarTheme: AppBarTheme(
        elevation: 0,
        centerTitle: true,
        backgroundColor: appBarColor,
        foregroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
        iconTheme: IconThemeData(color: accentColor),
        titleTextStyle: const TextStyle(
          color: Colors.white,
          fontSize: 18,
          fontWeight: FontWeight.w800,
        ),
      ),
      cardTheme: CardThemeData(
        color: surface,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: weakBorderColor),
        ),
      ),
      dividerColor: accentColor.withOpacity(.14),
      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: accentColor,
        linearTrackColor: accentColor.withOpacity(.12),
        circularTrackColor: accentColor.withOpacity(.12),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return accentColor;
          return Colors.white54;
        }),
        trackColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return accentColor.withOpacity(.30);
          }
          return Colors.white12;
        }),
      ),
      sliderTheme: SliderThemeData(
        activeTrackColor: accentColor,
        thumbColor: accentColor,
        overlayColor: accentColor.withOpacity(.15),
        inactiveTrackColor: Colors.white12,
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: navigationColor,
        elevation: 18,
        indicatorColor: accentMedium,
        iconTheme: WidgetStateProperty.resolveWith((states) {
          return IconThemeData(
            color: states.contains(WidgetState.selected)
                ? accentColor
                : Colors.white54,
          );
        }),
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          return TextStyle(
            color: states.contains(WidgetState.selected)
                ? accentColor
                : Colors.white54,
            fontWeight: states.contains(WidgetState.selected)
                ? FontWeight.w800
                : FontWeight.w600,
          );
        }),
      ),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: navigationColor,
        elevation: 18,
        selectedItemColor: accentColor,
        unselectedItemColor: Colors.white54,
        type: BottomNavigationBarType.fixed,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: accentColor,
          foregroundColor: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: accentColor,
          backgroundColor: Colors.transparent,
          elevation: 0,
          side: BorderSide(color: borderColor),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surface,
        labelStyle: TextStyle(color: textSecondary),
        hintStyle: TextStyle(color: textMuted),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: weakBorderColor),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: accentColor, width: 1.4),
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
        ),
      ),
      iconTheme: IconThemeData(color: accentColor),
      splashColor: neonColor.withOpacity(.22),
      highlightColor: neonColor.withOpacity(.10),
      hoverColor: neonColor.withOpacity(.08),
      focusColor: neonColor.withOpacity(.10),
      filledButtonTheme: FilledButtonThemeData(
        style: ButtonStyle(
          overlayColor: WidgetStateProperty.resolveWith((states) {
            if (states.contains(WidgetState.pressed)) {
              return neonColor.withOpacity(.30);
            }
            if (states.contains(WidgetState.hovered) ||
                states.contains(WidgetState.focused)) {
              return neonColor.withOpacity(.14);
            }
            return null;
          }),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: ButtonStyle(
          overlayColor: WidgetStatePropertyAll(neonColor.withOpacity(.16)),
        ),
      ),
    );
  }
}

class FangThemeStorage {
  static const defaults = FangThemeConfig();

  static String _safeAccount(String value) {
    final clean = value.trim().toLowerCase().replaceAll(
          RegExp(r'[^a-z0-9._-]'),
          '_',
        );
    return clean.isEmpty ? 'guest' : clean;
  }

  static String _key(String accountId, String name) =>
      'fang_theme_${_safeAccount(accountId)}_$name';

  static Future<FangThemeConfig> load(String accountId) async {
    final prefs = await SharedPreferences.getInstance();
    final prefixCheck = prefs.containsKey(_key(accountId, 'bg'));

    // Migrasi otomatis setting global lama ke akun pertama yang membuka versi ini.
    if (!prefixCheck && prefs.containsKey('fang_global_bg')) {
      final migrated = FangThemeConfig(
        backgroundPreset: prefs.getString('fang_global_bg') ?? defaults.backgroundPreset,
        accentColor: Color(prefs.getInt('fang_global_accent') ?? defaults.accentColor.value),
        glowIntensity: prefs.getDouble('fang_global_glow_intensity') ?? defaults.glowIntensity,
        glowBlur: prefs.getDouble('fang_global_glow_blur') ?? defaults.glowBlur,
        showGrid: false,
      );
      await save(accountId, migrated);
      return migrated;
    }

    return FangThemeConfig(
      backgroundPreset: prefs.getString(_key(accountId, 'bg')) ?? defaults.backgroundPreset,
      customBackgroundPath: prefs.getString(_key(accountId, 'custom_bg')),
      customBackgroundType:
          prefs.getString(_key(accountId, 'custom_bg_type')) ?? 'image',
      accentColor: Color(
        prefs.getInt(_key(accountId, 'accent')) ?? defaults.accentColor.value,
      ),
      lisColor: Color(
        prefs.getInt(_key(accountId, 'lis')) ?? defaults.lisColor.value,
      ),
      lisLight:
          prefs.getDouble(_key(accountId, 'lis_light')) ?? defaults.lisLight,
      glowIntensity: prefs.getDouble(_key(accountId, 'intensity')) ?? defaults.glowIntensity,
      glowBlur: prefs.getDouble(_key(accountId, 'blur')) ?? defaults.glowBlur,
      showGrid: false,
    );
  }

  static Future<void> save(String accountId, FangThemeConfig config) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key(accountId, 'bg'), config.backgroundPreset);
    if (config.customBackgroundPath == null || config.customBackgroundPath!.isEmpty) {
      await prefs.remove(_key(accountId, 'custom_bg'));
    } else {
      await prefs.setString(_key(accountId, 'custom_bg'), config.customBackgroundPath!);
    }
    await prefs.setString(
      _key(accountId, 'custom_bg_type'),
      config.customBackgroundType,
    );
    await prefs.setInt(_key(accountId, 'accent'), config.accentColor.value);
    await prefs.setInt(_key(accountId, 'lis'), config.lisColor.value);
    await prefs.setDouble(_key(accountId, 'lis_light'), config.lisLight);
    await prefs.setDouble(_key(accountId, 'intensity'), config.glowIntensity);
    await prefs.setDouble(_key(accountId, 'blur'), config.glowBlur);
    await prefs.setBool(_key(accountId, 'grid'), config.showGrid);
  }

  static Future<void> reset(String accountId) async {
    final prefs = await SharedPreferences.getInstance();
    for (final name in [
      'bg',
      'custom_bg',
      'custom_bg_type',
      'accent',
      'lis',
      'lis_light',
      'intensity',
      'blur',
      'grid',
    ]) {
      await prefs.remove(_key(accountId, name));
    }
  }
}

class FangThemeController extends ChangeNotifier {
  FangThemeController._();

  static final FangThemeController instance = FangThemeController._();

  FangThemeConfig _config = FangThemeStorage.defaults;
  String _accountId = 'guest';
  bool _initialized = false;

  FangThemeConfig get config => _config;
  String get accountId => _accountId;
  bool get initialized => _initialized;

  Future<void> init({String accountId = 'guest'}) async {
    if (_initialized && _accountId == accountId) return;
    _accountId = accountId.trim().isEmpty ? 'guest' : accountId.trim();
    _config = await FangThemeStorage.load(_accountId);
    _initialized = true;
    notifyListeners();
  }

  Future<void> switchAccount(String accountId) async {
    final next = accountId.trim().isEmpty ? 'guest' : accountId.trim();
    if (_initialized && next == _accountId) return;
    _accountId = next;
    _config = await FangThemeStorage.load(_accountId);
    _initialized = true;
    notifyListeners();
  }

  Future<void> update(FangThemeConfig config) async {
    _config = config;
    notifyListeners();
    await FangThemeStorage.save(_accountId, config);
  }

  Future<void> setAccent(Color color) => update(
        _config.copyWith(accentColor: color, lisColor: color),
      );
  Future<void> setLisColor(Color color) => setAccent(color);
  Future<void> setLisLight(double value) => update(_config.copyWith(lisLight: value));
  Future<void> setBackground(String preset) => update(
        _config.copyWith(backgroundPreset: preset, clearCustomBackground: true),
      );
  Future<void> setGlowIntensity(double value) =>
      update(_config.copyWith(glowIntensity: value));
  Future<void> setGlowBlur(double value) => update(_config.copyWith(glowBlur: value));
  Future<void> setGrid(bool value) => update(_config.copyWith(showGrid: false));

  Future<void> reset() async {
    await FangThemeStorage.reset(_accountId);
    _config = FangThemeStorage.defaults;
    notifyListeners();
  }
}

class FangThemeBuilder extends StatelessWidget {
  final Widget Function(BuildContext context, FangThemeConfig config) builder;

  const FangThemeBuilder({
    super.key,
    required this.builder,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: FangThemeController.instance,
      builder: (context, _) => builder(
        context,
        FangThemeController.instance.config,
      ),
    );
  }
}

class FangBackground extends StatelessWidget {
  final Widget child;
  final bool useSafeArea;

  const FangBackground({
    super.key,
    required this.child,
    this.useSafeArea = false,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: FangThemeController.instance,
      builder: (context, _) {
        final theme = FangThemeController.instance.config;
        return _FangBackgroundStack(
          theme: theme,
          child: useSafeArea ? SafeArea(child: child) : child,
        );
      },
    );
  }
}

class _FangBackgroundStack extends StatelessWidget {
  final FangThemeConfig theme;
  final Widget child;

  const _FangBackgroundStack({required this.theme, required this.child});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: theme.backgroundColors,
              ),
            ),
          ),
        ),
        if (!theme.hasCustomBackground && theme.backgroundPreset == 'fang_art')
          Positioned.fill(
            child: Image.asset(
              'assets/images/fang_shadow_theme.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const SizedBox.shrink(),
            ),
          ),
        if (theme.hasCustomImage)
          Positioned.fill(
            child: Image.file(
              File(theme.customBackgroundPath!),
              fit: BoxFit.cover,
              alignment: Alignment.center,
              errorBuilder: (_, __, ___) => const SizedBox.shrink(),
            ),
          ),
        if (theme.hasCustomVideo)
          Positioned.fill(
            child: _FangVideoBackground(path: theme.customBackgroundPath!),
          ),
        if (theme.hasCustomBackground || theme.backgroundPreset == 'fang_art')
          Positioned.fill(
            child: ColoredBox(color: Colors.black.withOpacity(.58)),
          ),
        // One clean background layer only: no radial blob, no decorative circle,
        // and no extra gradient over the user's selected image/video.
        Positioned.fill(child: child),
      ],
    );
  }
}


class _FangVideoBackground extends StatefulWidget {
  final String path;

  const _FangVideoBackground({required this.path});

  @override
  State<_FangVideoBackground> createState() => _FangVideoBackgroundState();
}

class _FangVideoBackgroundState extends State<_FangVideoBackground>
    with WidgetsBindingObserver {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void didUpdateWidget(covariant _FangVideoBackground oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.path != widget.path) {
      _load();
    }
  }

  Future<void> _load() async {
    final previous = _controller;
    _controller = null;
    await previous?.dispose();

    final file = File(widget.path);
    if (!file.existsSync()) {
      if (mounted) setState(() {});
      return;
    }

    final controller = VideoPlayerController.file(file);
    _controller = controller;
    try {
      await controller.initialize();
      await controller.setLooping(true);
      await controller.setVolume(0);
      await controller.play();
      if (mounted) setState(() {});
    } catch (_) {
      await controller.dispose();
      if (_controller == controller) _controller = null;
      if (mounted) setState(() {});
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final controller = _controller;
    if (controller == null || !controller.value.isInitialized) return;

    if (state == AppLifecycleState.resumed &&
        !controller.value.isPlaying) {
      controller.play();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = _controller;
    if (controller == null || !controller.value.isInitialized) {
      return const SizedBox.expand();
    }
    final size = controller.value.size;
    if (size.width <= 0 || size.height <= 0) {
      return const SizedBox.expand();
    }

    return ClipRect(
      child: FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(
          width: size.width,
          height: size.height,
          child: VideoPlayer(controller),
        ),
      ),
    );
  }
}

class FangCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? margin;
  final double radius;
  final VoidCallback? onTap;
  final bool strongerGlow;

  const FangCard({
    super.key,
    required this.child,
    this.padding,
    this.margin,
    this.radius = 20,
    this.onTap,
    this.strongerGlow = false,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: FangThemeController.instance,
      builder: (context, _) {
        final theme = FangThemeController.instance.config;
        final card = AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          margin: margin,
          padding: padding,
          decoration: BoxDecoration(
            color: theme.surface,
            borderRadius: BorderRadius.circular(radius),
            border: Border.all(color: theme.borderColor),
            boxShadow: [
              theme.glow(
                multiplier: strongerGlow ? 1.0 : .55,
                offset: const Offset(0, 5),
              ),
              BoxShadow(
                color: Colors.black.withOpacity(.34),
                blurRadius: 18,
                offset: const Offset(0, 9),
              ),
            ],
          ),
          child: child,
        );
        if (onTap == null) return card;
        return Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(radius),
            splashColor: theme.neonColor.withOpacity(
              (.18 + (.18 * theme._neonBoost)).clamp(0.0, .52).toDouble(),
            ),
            highlightColor: theme.neonColor.withOpacity(.10),
            hoverColor: theme.neonColor.withOpacity(.08),
            onTap: onTap,
            child: card,
          ),
        );
      },
    );
  }
}

class FangNeonIcon extends StatelessWidget {
  final IconData icon;
  final double size;
  final double boxSize;

  const FangNeonIcon({
    super.key,
    required this.icon,
    this.size = 22,
    this.boxSize = 48,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: FangThemeController.instance,
      builder: (context, _) {
        final theme = FangThemeController.instance.config;
        return Container(
          width: boxSize,
          height: boxSize,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(boxSize * .32),
            color: theme.accentSoft,
            border: Border.all(color: theme.borderColor),
            boxShadow: [theme.glow(multiplier: .55)],
          ),
          child: Icon(icon, color: theme.accentColor, size: size),
        );
      },
    );
  }
}

class FangGridPainter extends CustomPainter {
  final Color color;

  const FangGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    return; // home-ui: grid disabled globally

    final paint = Paint()
      ..color = color
      ..strokeWidth = .65;
    const spacing = 34.0;
    for (double x = 0; x <= size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y <= size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant FangGridPainter oldDelegate) =>
      oldDelegate.color != color;
}

class FangAppearancePage extends StatefulWidget {
  const FangAppearancePage({super.key});

  @override
  State<FangAppearancePage> createState() => _FangAppearancePageState();
}

class _FangAppearancePageState extends State<FangAppearancePage> {
  late FangThemeConfig _draft;
  bool _pickingImage = false;
  bool _pickingVideo = false;

  static const backgrounds = [
    ('fang_art', 'Fang Shadow', 'Official Fang Shadow artwork'),
    ('abyss', 'Abyss', 'Dark purple shadow'),
    ('midnight', 'Midnight', 'Deep blue cyber'),
    ('carbon', 'Carbon', 'Clean black'),
    ('violet', 'Violet', 'Purple dominant'),
    ('galaxy', 'Galaxy', 'Blue + purple space'),
  ];

  static const quickColors = [
    Color(0xFF9D43FF),
    Color(0xFFD84CFF),
    Color(0xFF329BFF),
    Color(0xFF45D9FF),
    Color(0xFF41F5B2),
    Color(0xFFFF3D71),
    Color(0xFFFFB020),
    Color(0xFFFFFFFF),
  ];

  @override
  void initState() {
    super.initState();
    _draft = FangThemeController.instance.config;
  }

  Future<void> _apply() async {
    await FangThemeController.instance.update(_draft);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: _draft.accentColor.withOpacity(.88),
        behavior: SnackBarBehavior.floating,
        content: Text(
          'Tema disimpan khusus akun ${FangThemeController.instance.accountId}.',
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
        ),
      ),
    );
  }

  Future<void> _reset() async {
    await FangThemeController.instance.reset();
    if (!mounted) return;
    setState(() => _draft = FangThemeController.instance.config);
  }

  Future<void> _pickBackground() async {
    if (_pickingImage) return;
    setState(() => _pickingImage = true);
    try {
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        imageQuality: 88,
        maxWidth: 1800,
      );
      if (picked == null) return;
      final dir = await getApplicationDocumentsDirectory();
      final account = FangThemeController.instance.accountId
          .replaceAll(RegExp(r'[^a-zA-Z0-9._-]'), '_');
      final ext = picked.path.toLowerCase().endsWith('.png') ? 'png' : 'jpg';
      final target = File('${dir.path}/fang_background_$account.$ext');
      final copied = await File(picked.path).copy(target.path);
      if (!mounted) return;
      setState(() {
        _draft = _draft.copyWith(
          customBackgroundPath: copied.path,
          customBackgroundType: 'image',
        );
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal memilih background: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _pickingImage = false);
    }
  }


  Future<void> _pickFreeColor() async {
    final selected = await showDialog<Color>(
      context: context,
      builder: (_) => _FullColorPickerDialog(initial: _draft.accentColor),
    );
    if (selected != null && mounted) {
      setState(() => _draft = _draft.copyWith(
            accentColor: selected,
            lisColor: selected,
          ));
    }
  }

  @override
  Widget build(BuildContext context) {
    final accent = _draft.accentColor;
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: const Text('Appearance'),
        actions: [
          IconButton(
            tooltip: 'Reset tema akun ini',
            onPressed: _reset,
            icon: const Icon(Icons.restart_alt_rounded),
          ),
        ],
      ),
      body: _FangBackgroundStack(
        theme: _draft,
        child: SafeArea(
          top: false,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
            children: [
              _accountBanner(accent),
              const SizedBox(height: 14),
              _preview(),
              const SizedBox(height: 24),
              _sectionTitle(Icons.wallpaper_rounded, 'Background'),
              const SizedBox(height: 12),
              _customBackgroundCard(),
              const SizedBox(height: 10),
              ...backgrounds.map(_backgroundCard),
              const SizedBox(height: 18),
              _sectionTitle(Icons.palette_rounded, 'Warna Neon'),
              const SizedBox(height: 12),
              _colorCard(),
              const SizedBox(height: 16),
              _sliderCard(
                icon: Icons.lightbulb_rounded,
                title: 'Kecerahan Neon',
                value: '${(_draft.lisLight * 100).round()}%',
                slider: Slider(
                  min: 0.10,
                  max: 2.00,
                  divisions: 38,
                  value: _draft.lisLight.clamp(.10, 2.00).toDouble(),
                  activeColor: accent,
                  inactiveColor: Colors.white12,
                  onChanged: (value) {
                    setState(() {
                      _draft = _draft.copyWith(lisLight: value);
                    });
                  },
                ),
              ),
              const SizedBox(height: 12),
              _sliderCard(
                icon: Icons.blur_on_rounded,
                title: 'Glow Softness',
                value: _draft.glowBlur.round().toString(),
                slider: Slider(
                  min: 6,
                  max: 48,
                  divisions: 21,
                  value: _draft.glowBlur.clamp(6, 48).toDouble(),
                  activeColor: accent,
                  inactiveColor: Colors.white12,
                  onChanged: (value) {
                    setState(() => _draft = _draft.copyWith(glowBlur: value));
                  },
                ),
              ),
              const SizedBox(height: 12),
              Container(
                decoration: BoxDecoration(
                  color: _draft.surface,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: accent.withOpacity(.24)),
                ),
                child: SwitchListTile(
                  value: _draft.showGrid,
                  activeColor: accent,
                  title: const Text(
                    'Grid Pattern',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                  ),
                  subtitle: const Text(
                    'Tampilkan pola grid tipis di background.',
                    style: TextStyle(color: Colors.white54, fontSize: 11),
                  ),
                  secondary: Icon(Icons.grid_4x4_rounded, color: accent),
                  onChanged: (value) {
                    setState(() => _draft = _draft.copyWith(showGrid: value));
                  },
                ),
              ),
              const SizedBox(height: 24),
              SizedBox(
                height: 56,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    gradient: LinearGradient(colors: _draft.accentGradient),
                    boxShadow: [
                      BoxShadow(
                        color: accent.withOpacity(.36 * _draft.glowIntensity),
                        blurRadius: _draft.glowBlur,
                        spreadRadius: -4,
                      ),
                    ],
                  ),
                  child: ElevatedButton.icon(
                    onPressed: _apply,
                    style: ElevatedButton.styleFrom(
                      elevation: 0,
                      backgroundColor: Colors.transparent,
                      shadowColor: Colors.transparent,
                    ),
                    icon: const Icon(Icons.save_rounded),
                    label: const Text(
                      'SIMPAN TEMA AKUN',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _accountBanner(Color accent) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: _draft.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: accent.withOpacity(.25)),
      ),
      child: Row(
        children: [
          Icon(Icons.person_rounded, color: accent),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Tema khusus akun',
                  style: TextStyle(color: Colors.white54, fontSize: 11),
                ),
                Text(
                  FangThemeController.instance.accountId,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _customBackgroundCard() {
    final selected = _draft.hasCustomBackground;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _draft.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: selected ? _draft.accentColor : _draft.weakBorderColor,
          width: selected ? 1.5 : 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 58,
            height: 58,
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              color: _draft.accentSoft,
            ),
            child: selected
                ? Image.file(
                    File(_draft.customBackgroundPath!),
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Icon(
                      Icons.broken_image_rounded,
                      color: _draft.accentColor,
                    ),
                  )
                : Icon(
                    Icons.wallpaper_rounded,
                    color: _draft.accentColor,
                  ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Background dari galeri',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Pilih gambar background khusus akun ini.',
                  style: TextStyle(color: Colors.white54, fontSize: 10.5),
                ),
              ],
            ),
          ),
          if (selected)
            IconButton(
              tooltip: 'Hapus gambar',
              onPressed: () {
                setState(() => _draft = _draft.copyWith(clearCustomBackground: true));
              },
              icon: const Icon(Icons.delete_outline_rounded),
            ),
          const SizedBox(width: 6),
          FilledButton.tonalIcon(
            onPressed: _pickingImage ? null : _pickBackground,
            icon: _pickingImage
                ? const SizedBox(
                    width: 14,
                    height: 14,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.photo_library_rounded, size: 17),
            label: const Text('PILIH GAMBAR'),
          ),
        ],
      ),
    );
  }

  Widget _backgroundCard((String, String, String) bg) {
    final selected = !_draft.hasCustomBackground && _draft.backgroundPreset == bg.$1;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () {
          setState(() {
            _draft = _draft.copyWith(
              backgroundPreset: bg.$1,
              clearCustomBackground: true,
            );
          });
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: _draft.surface,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: selected ? _draft.accentColor : _draft.weakBorderColor,
              width: selected ? 1.5 : 1,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                clipBehavior: Clip.antiAlias,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(13),
                  gradient: LinearGradient(
                    colors: FangThemeConfig(backgroundPreset: bg.$1).backgroundColors,
                  ),
                ),
                child: bg.$1 == 'fang_art'
                    ? Image.asset(
                        'assets/images/fang_shadow_theme.jpg',
                        fit: BoxFit.cover,
                      )
                    : null,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      bg.$2,
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 3),
                    Text(bg.$3, style: const TextStyle(color: Colors.white54, fontSize: 10.5)),
                  ],
                ),
              ),
              if (selected) Icon(Icons.check_circle_rounded, color: _draft.accentColor),
            ],
          ),
        ),
      ),
    );
  }

  Widget _colorCard() {
    final hex = '#${_draft.accentColor.value.toRadixString(16).padLeft(8, '0').substring(2).toUpperCase()}';
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _draft.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _draft.weakBorderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: quickColors.map((color) {
              final selected = color.value == _draft.accentColor.value;
              return InkWell(
                customBorder: const CircleBorder(),
                onTap: () => setState(() => _draft = _draft.copyWith(
                      accentColor: color,
                      lisColor: color,
                    )),
                child: Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: color,
                    border: Border.all(
                      color: selected ? Colors.white : Colors.white24,
                      width: selected ? 3 : 1,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: color.withOpacity(selected ? .62 : .18),
                        blurRadius: selected ? 18 : 8,
                      ),
                    ],
                  ),
                  child: selected
                      ? const Icon(Icons.check_rounded, color: Colors.white)
                      : null,
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _pickFreeColor,
              icon: const Icon(Icons.colorize_rounded),
              label: Text('PILIH WARNA BEBAS  •  $hex'),
            ),
          ),
        ],
      ),
    );
  }


  Widget _sectionTitle(IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, color: _draft.accentColor),
        const SizedBox(width: 9),
        Text(
          text,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w800,
            fontSize: 14,
          ),
        ),
      ],
    );
  }

  Widget _sliderCard({
    required IconData icon,
    required String title,
    required String value,
    required Widget slider,
  }) {
    return Container(
      padding: const EdgeInsets.fromLTRB(15, 14, 15, 7),
      decoration: BoxDecoration(
        color: _draft.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _draft.weakBorderColor),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(icon, color: _draft.accentColor),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                ),
              ),
              Text(
                value,
                style: TextStyle(color: _draft.accentColor, fontWeight: FontWeight.w800),
              ),
            ],
          ),
          slider,
        ],
      ),
    );
  }

  Widget _preview() {
    return Container(
      height: 200,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: _draft.accentColor.withOpacity(.60)),
        boxShadow: const [],
      ),
      child: _FangBackgroundStack(
        theme: _draft,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  FangNeonIcon(icon: Icons.visibility_rounded, boxSize: 38, size: 19),
                  const SizedBox(width: 10),
                  const Text(
                    'FANG SHADOW',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800),
                  ),
                ],
              ),
              const Spacer(),
              Row(
                children: [
                  _previewTile('HOME', Icons.home_rounded),
                  const SizedBox(width: 8),
                  _previewTile('CHAT', Icons.chat_bubble_rounded),
                  const SizedBox(width: 8),
                  _previewTile('TOOLS', Icons.build_rounded),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _previewTile(String label, IconData icon) {
    return Expanded(
      child: Container(
        height: 72,
        decoration: BoxDecoration(
          color: _draft.surface.withOpacity(.92),
          borderRadius: BorderRadius.circular(15),
          border: Border.all(color: _draft.accentColor.withOpacity(.32)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: _draft.accentColor, size: 21),
            const SizedBox(height: 6),
            Text(
              label,
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 9),
            ),
          ],
        ),
      ),
    );
  }
}

class _FullColorPickerDialog extends StatefulWidget {
  final Color initial;

  const _FullColorPickerDialog({required this.initial});

  @override
  State<_FullColorPickerDialog> createState() => _FullColorPickerDialogState();
}

class _FullColorPickerDialogState extends State<_FullColorPickerDialog> {
  late HSVColor hsv;
  late TextEditingController hexController;

  @override
  void initState() {
    super.initState();
    hsv = HSVColor.fromColor(widget.initial);
    hexController = TextEditingController(text: _hex(hsv.toColor()));
  }

  @override
  void dispose() {
    hexController.dispose();
    super.dispose();
  }

  static String _hex(Color color) =>
      '#${color.value.toRadixString(16).padLeft(8, '0').substring(2).toUpperCase()}';

  void _syncHex() {
    hexController.text = _hex(hsv.toColor());
  }

  void _applyHex() {
    var raw = hexController.text.trim().replaceAll('#', '');
    if (raw.length == 3) {
      raw = '${raw[0]}${raw[0]}${raw[1]}${raw[1]}${raw[2]}${raw[2]}';
    }
    if (raw.length != 6) return;
    final value = int.tryParse(raw, radix: 16);
    if (value == null) return;
    setState(() {
      hsv = HSVColor.fromColor(Color(0xFF000000 | value));
      _syncHex();
    });
  }

  @override
  Widget build(BuildContext context) {
    final color = hsv.toColor();
    return AlertDialog(
      title: const Text('Pilih warna bebas'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              height: 62,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [BoxShadow(color: color.withOpacity(.55), blurRadius: 24)],
              ),
            ),
            const SizedBox(height: 18),
            _colorSlider(
              'Hue',
              hsv.hue,
              0,
              360,
              (v) => setState(() {
                hsv = hsv.withHue(v);
                _syncHex();
              }),
            ),
            _colorSlider(
              'Saturation',
              hsv.saturation,
              0,
              1,
              (v) => setState(() {
                hsv = hsv.withSaturation(v);
                _syncHex();
              }),
            ),
            _colorSlider(
              'Brightness',
              hsv.value,
              .05,
              1,
              (v) => setState(() {
                hsv = hsv.withValue(v);
                _syncHex();
              }),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: hexController,
              textCapitalization: TextCapitalization.characters,
              decoration: InputDecoration(
                labelText: 'HEX',
                hintText: '#9D43FF',
                suffixIcon: IconButton(
                  onPressed: _applyHex,
                  icon: const Icon(Icons.check_rounded),
                ),
              ),
              onSubmitted: (_) => _applyHex(),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('BATAL')),
        FilledButton(
          onPressed: () => Navigator.pop(context, color),
          child: const Text('PILIH WARNA'),
        ),
      ],
    );
  }

  Widget _colorSlider(
    String label,
    double value,
    double min,
    double max,
    ValueChanged<double> onChanged,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
        Slider(min: min, max: max, value: value.clamp(min, max).toDouble(), onChanged: onChanged),
      ],
    );
  }
}
