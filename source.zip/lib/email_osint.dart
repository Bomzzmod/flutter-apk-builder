import 'package:flutter/material.dart';

import 'fang_global_theme.dart';
import 'tool_api_client.dart';

class EmailOsintPage extends StatefulWidget {
  const EmailOsintPage({super.key});

  @override
  State<EmailOsintPage> createState() => _EmailOsintPageState();
}

class _EmailOsintPageState extends State<EmailOsintPage> {
  final _controller = TextEditingController();
  bool _loading = false;
  String? _error;
  _EmailCheck? _result;

  static const _disposableDomains = <String>{
    '10minutemail.com',
    'guerrillamail.com',
    'mailinator.com',
    'tempmail.com',
    'temp-mail.org',
    'yopmail.com',
  };

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _check() async {
    final email = _controller.text.trim().toLowerCase();
    final match = RegExp(
      r"^[a-z0-9.!#$%&'()*+/=?^_`{|}~-]+@([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$",
      caseSensitive: false,
    ).firstMatch(email);

    if (match == null) {
      setState(() {
        _error = 'Format email tidak valid.';
        _result = null;
      });
      return;
    }

    final domain = email.split('@').last;
    setState(() {
      _loading = true;
      _error = null;
      _result = null;
    });

    try {
      final mx = await ToolApiClient.instance.dnsQuery(domain, 'MX');
      final a = await ToolApiClient.instance.dnsQuery(domain, 'A');
      final mxAnswers = _answers(mx);
      final aAnswers = _answers(a);
      final disposable = _disposableDomains.contains(domain);

      if (!mounted) return;
      setState(() {
        _result = _EmailCheck(
          email: email,
          domain: domain,
          provider: _providerFor(domain),
          disposable: disposable,
          hasMx: mxAnswers.isNotEmpty,
          mxRecords: mxAnswers,
          addressRecords: aAnswers,
        );
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  List<String> _answers(Map<String, dynamic> json) {
    final raw = json['Answer'];
    if (raw is! List) return const [];
    return raw
        .whereType<Map>()
        .map((e) => e['data']?.toString().trim())
        .whereType<String>()
        .where((e) => e.isNotEmpty)
        .toList(growable: false);
  }

  String _providerFor(String domain) {
    if (domain == 'gmail.com' || domain == 'googlemail.com') return 'Google';
    if (domain.contains('outlook') ||
        domain.contains('hotmail') ||
        domain.contains('live.com')) return 'Microsoft';
    if (domain.contains('yahoo')) return 'Yahoo';
    if (domain.contains('proton')) return 'Proton';
    if (domain.contains('icloud') || domain == 'me.com') return 'Apple';
    return 'Custom domain';
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: FangThemeController.instance,
      builder: (context, _) {
        final fang = FangThemeController.instance.config;
        return Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            title: const Text('Email Check',
                style: TextStyle(fontWeight: FontWeight.w800)),
          ),
          body: FangBackground(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
              children: [
                FangCard(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      TextField(
                        controller: _controller,
                        keyboardType: TextInputType.emailAddress,
                        textInputAction: TextInputAction.search,
                        onSubmitted: (_) => _check(),
                        decoration: const InputDecoration(
                          labelText: 'Alamat email',
                          hintText: 'nama@example.com',
                          prefixIcon: Icon(Icons.alternate_email_rounded),
                        ),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: _loading ? null : _check,
                          icon: _loading
                              ? const SizedBox(
                                  width: 16,
                                  height: 16,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white,
                                  ),
                                )
                              : const Icon(Icons.search_rounded),
                          label: const Text('CEK EMAIL'),
                        ),
                      ),
                    ],
                  ),
                ),
                if (_error != null) ...[
                  const SizedBox(height: 14),
                  FangCard(
                    padding: const EdgeInsets.all(14),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(Icons.error_outline_rounded,
                            color: Color(0xFFFF6B6B)),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(_error!,
                              style: const TextStyle(color: Colors.white70)),
                        ),
                      ],
                    ),
                  ),
                ],
                if (_result != null) ...[
                  const SizedBox(height: 14),
                  _resultCard(fang, _result!),
                ],
                const SizedBox(height: 12),
                Text(
                  'Pemeriksaan ini hanya memvalidasi format dan DNS domain (MX/A). '
                  'Tidak mengecek apakah mailbox tertentu benar-benar dimiliki atau aktif.',
                  style: TextStyle(
                    color: fang.textSecondary,
                    fontSize: 10.5,
                    height: 1.45,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _resultCard(FangThemeConfig fang, _EmailCheck r) {
    return FangCard(
      strongerGlow: true,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              FangNeonIcon(
                icon: r.hasMx
                    ? Icons.mark_email_read_rounded
                    : Icons.mark_email_unread_rounded,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(r.email,
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w800)),
                    Text(
                      r.hasMx ? 'Domain menerima email' : 'MX tidak ditemukan',
                      style: TextStyle(
                        color: r.hasMx
                            ? const Color(0xFF41F5B2)
                            : const Color(0xFFFFB020),
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _row('Domain', r.domain),
          _row('Provider', r.provider),
          _row('Disposable', r.disposable ? 'Kemungkinan ya' : 'Tidak terdeteksi'),
          _row('MX', r.hasMx ? '${r.mxRecords.length} record' : 'Tidak ada'),
          if (r.mxRecords.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text('MX RECORDS',
                style: TextStyle(
                    color: fang.accentColor,
                    fontSize: 10,
                    fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            ...r.mxRecords.map((e) => SelectableText(
                  '• $e',
                  style: const TextStyle(color: Colors.white70, fontSize: 11),
                )),
          ],
        ],
      ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 92,
            child: Text(label,
                style: const TextStyle(color: Colors.white54, fontSize: 11)),
          ),
          Expanded(
            child: SelectableText(value,
                style: const TextStyle(color: Colors.white, fontSize: 11.5)),
          ),
        ],
      ),
    );
  }
}

class _EmailCheck {
  final String email;
  final String domain;
  final String provider;
  final bool disposable;
  final bool hasMx;
  final List<String> mxRecords;
  final List<String> addressRecords;

  const _EmailCheck({
    required this.email,
    required this.domain,
    required this.provider,
    required this.disposable,
    required this.hasMx,
    required this.mxRecords,
    required this.addressRecords,
  });
}
