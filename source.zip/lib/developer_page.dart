import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'api_config.dart';
import 'fang_global_theme.dart';

class DeveloperPage extends StatefulWidget {
  final String sessionKey;

  const DeveloperPage({
    super.key,
    required this.sessionKey,
  });

  @override
  State<DeveloperPage> createState() => _DeveloperPageState();
}

class _DeveloperPageState extends State<DeveloperPage> {
  final TextEditingController _search = TextEditingController();

  final TextEditingController _createUsername = TextEditingController();
  final TextEditingController _createPassword = TextEditingController();
  final TextEditingController _createDays = TextEditingController();
  final TextEditingController _creatorTelegram = TextEditingController();

  String _createRole = 'owner';
  bool _creating = false;

  static const List<String> _developerCreateRoles = [
    'owner',
    'admin',
    'reseller',
    'vip',
    'member',
  ];
  List<Map<String, dynamic>> _users = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _search.dispose();
    _createUsername.dispose();
    _createPassword.dispose();
    _createDays.dispose();
    _creatorTelegram.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    if (mounted) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }

    try {
      final uri = Uri.parse('$baseUrl/developer/users').replace(
        queryParameters: {'key': widget.sessionKey},
      );
      final res = await http.get(uri).timeout(const Duration(seconds: 12));
      final decoded = jsonDecode(res.body);
      if (decoded is! Map) throw Exception('Response server tidak valid');
      final data = Map<String, dynamic>.from(decoded);

      if (data['valid'] != true || data['authorized'] != true) {
        throw Exception(data['message']?.toString() ?? 'Akses Developer ditolak');
      }

      final raw = data['users'] as List? ?? const [];
      final users = raw
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList();

      if (!mounted) return;
      setState(() {
        _users = users;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }


  Future<void> _createAccount() async {
    final username = _createUsername.text.trim();
    final password = _createPassword.text.trim();
    final days = _createDays.text.trim();
    final telegramId = _creatorTelegram.text.trim();
    final selectedRole = _createRole;

    if (username.isEmpty ||
        password.isEmpty ||
        days.isEmpty ||
        telegramId.isEmpty) {
      _showCreateMessage(
        'Field belum lengkap',
        'Username, password, durasi, dan Telegram ID Pembuat wajib diisi.',
      );
      return;
    }

    final parsedDays = int.tryParse(days);
    if (parsedDays == null || parsedDays <= 0) {
      _showCreateMessage(
        'Durasi tidak valid',
        'Durasi harus berupa angka dan lebih dari 0 hari.',
      );
      return;
    }

    if (!RegExp(r'^\d+$').hasMatch(telegramId)) {
      _showCreateMessage(
        'Telegram ID tidak valid',
        'Telegram ID harus berupa ID numerik yang sudah terdaftar di bot.',
      );
      return;
    }

    setState(() => _creating = true);

    try {
      final uri = Uri.parse('$baseUrl/userAdd').replace(
        queryParameters: {
          'key': widget.sessionKey,
          'username': username,
          'password': password,
          'day': parsedDays.toString(),
          'role': selectedRole,
          'creatorTelegram': telegramId,
        },
      );

      final response =
          await http.get(uri).timeout(const Duration(seconds: 15));
      final decoded = jsonDecode(response.body);

      if (decoded is! Map) {
        throw Exception('Response server tidak valid');
      }

      final data = Map<String, dynamic>.from(decoded);

      if (data['created'] == true) {
        _createUsername.clear();
        _createPassword.clear();
        _createDays.clear();
        _creatorTelegram.clear();

        _showCreateMessage(
          'Akun berhasil dibuat',
          '${username.toUpperCase()} berhasil dibuat sebagai ${selectedRole.toUpperCase()}.',
        );

        await _load();
        return;
      }

      _showCreateMessage(
        'Create Account gagal',
        data['message']?.toString() ?? 'Server menolak pembuatan akun.',
      );
    } catch (e) {
      _showCreateMessage(
        'Create Account gagal',
        e.toString().replaceFirst('Exception: ', ''),
      );
    } finally {
      if (mounted) {
        setState(() => _creating = false);
      }
    }
  }

  void _showCreateMessage(String title, String message) {
    if (!mounted) return;
    final fang = FangThemeController.instance.config;

    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: fang.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(
            color: fang.accentColor.withOpacity(.55),
          ),
        ),
        title: Text(
          title,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w900,
          ),
        ),
        content: Text(
          message,
          style: TextStyle(color: fang.textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'OK',
              style: TextStyle(
                color: fang.accentColor,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _developerCreateField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
    bool obscureText = false,
  }) {
    final fang = FangThemeController.instance.config;

    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      obscureText: obscureText,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: fang.textSecondary),
        prefixIcon: Icon(icon, color: fang.accentColor),
      ),
    );
  }

  Widget _developerCreateCard(FangThemeConfig fang) {
    return FangCard(
      padding: const EdgeInsets.all(16),
      strongerGlow: true,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const FangNeonIcon(
                icon: Icons.person_add_alt_1_rounded,
                boxSize: 50,
                size: 24,
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'CREATE ACCOUNT',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 15,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'Developer dapat membuat Owner, Admin, Reseller, VIP, dan Member.',
                      style: TextStyle(
                        color: Colors.white54,
                        fontSize: 10,
                        height: 1.35,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          _developerCreateField(
            controller: _createUsername,
            label: 'Username',
            icon: Icons.person_rounded,
          ),
          const SizedBox(height: 10),
          _developerCreateField(
            controller: _createPassword,
            label: 'Password',
            icon: Icons.lock_rounded,
            obscureText: true,
          ),
          const SizedBox(height: 10),
          _developerCreateField(
            controller: _createDays,
            label: 'Durasi (Hari)',
            icon: Icons.calendar_month_rounded,
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 10),
          _developerCreateField(
            controller: _creatorTelegram,
            label: 'Telegram ID Pembuat',
            icon: Icons.telegram_rounded,
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: _createRole,
            dropdownColor: fang.surface,
            decoration: InputDecoration(
              labelText: 'Role akun baru',
              prefixIcon: Icon(
                Icons.admin_panel_settings_rounded,
                color: fang.accentColor,
              ),
            ),
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w800,
            ),
            items: _developerCreateRoles
                .map(
                  (role) => DropdownMenuItem<String>(
                    value: role,
                    child: Text(role.toUpperCase()),
                  ),
                )
                .toList(),
            onChanged: _creating
                ? null
                : (value) {
                    if (value != null) {
                      setState(() => _createRole = value);
                    }
                  },
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton.icon(
              onPressed: _creating ? null : _createAccount,
              icon: _creating
                  ? const SizedBox(
                      width: 17,
                      height: 17,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Icon(Icons.person_add_alt_1_rounded),
              label: Text(
                _creating ? 'MEMBUAT AKUN...' : 'CREATE ACCOUNT',
                style: const TextStyle(
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  List<Map<String, dynamic>> get _filtered {
    final q = _search.text.trim().toLowerCase();
    if (q.isEmpty) return _users;
    return _users.where((u) {
      final device = (u['device'] is Map)
          ? Map<String, dynamic>.from(u['device'] as Map)
          : <String, dynamic>{};
      final haystack = [
        u['username'],
        u['role'],
        u['expiredDate'],
        device['brand'],
        device['model'],
        device['androidVersion'],
        device['appVersion'],
      ].map((e) => (e ?? '').toString().toLowerCase()).join(' ');
      return haystack.contains(q);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: FangThemeController.instance,
      builder: (context, _) {
        final fang = FangThemeController.instance.config;
        final online = _users.where((e) => e['online'] == true).length;
        final developers = _users
            .where((e) => e['role']?.toString().toLowerCase() == 'developer')
            .length;

        return Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            title: const Text(
              'DEVELOPER PANEL',
              style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2),
            ),
            actions: [
              IconButton(
                tooltip: 'Refresh',
                onPressed: _loading ? null : _load,
                icon: const Icon(Icons.refresh_rounded),
              ),
            ],
          ),
          body: FangBackground(
            child: SafeArea(
              top: false,
              child: RefreshIndicator(
                onRefresh: _load,
                color: fang.accentColor,
                child: ListView(
                  physics: const AlwaysScrollableScrollPhysics(
                    parent: BouncingScrollPhysics(),
                  ),
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
                  children: [
                    FangCard(
                      padding: const EdgeInsets.all(18),
                      strongerGlow: true,
                      child: Row(
                        children: [
                          const FangNeonIcon(
                            icon: Icons.code_rounded,
                            boxSize: 56,
                            size: 27,
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'FANG SHADOW DEVELOPER',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                                const SizedBox(height: 5),
                                Text(
                                  'Akses tertinggi • monitoring akun & perangkat',
                                  style: TextStyle(
                                    color: fang.textSecondary,
                                    fontSize: 10.5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(999),
                              color: const Color(0xFF22D3EE).withOpacity(.12),
                              border: Border.all(color: const Color(0xFF22D3EE).withOpacity(.45)),
                            ),
                            child: const Text(
                              'LEVEL 7',
                              style: TextStyle(
                                color: Color(0xFF22D3EE),
                                fontSize: 9,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(child: _statCard('TOTAL AKUN', '${_users.length}', Icons.people_alt_rounded, fang)),
                        const SizedBox(width: 10),
                        Expanded(child: _statCard('ONLINE', '$online', Icons.wifi_rounded, fang)),
                        const SizedBox(width: 10),
                        Expanded(child: _statCard('DEVELOPER', '$developers', Icons.code_rounded, fang)),
                      ],
                    ),
                    const SizedBox(height: 16),
                    _developerCreateCard(fang),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _search,
                      onChanged: (_) => setState(() {}),
                      style: const TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        hintText: 'Cari username, role, brand atau model HP…',
                        hintStyle: TextStyle(color: fang.textMuted, fontSize: 11),
                        prefixIcon: Icon(Icons.search_rounded, color: fang.accentColor),
                        suffixIcon: _search.text.isEmpty
                            ? null
                            : IconButton(
                                onPressed: () {
                                  _search.clear();
                                  setState(() {});
                                },
                                icon: const Icon(Icons.close_rounded),
                              ),
                        filled: true,
                        fillColor: fang.surface,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(17),
                          borderSide: BorderSide(color: fang.weakBorderColor),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(17),
                          borderSide: BorderSide(color: fang.weakBorderColor),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(17),
                          borderSide: BorderSide(color: fang.accentColor),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    if (_loading)
                      Padding(
                        padding: const EdgeInsets.only(top: 70),
                        child: Center(child: CircularProgressIndicator(color: fang.accentColor)),
                      )
                    else if (_error != null)
                      FangCard(
                        padding: const EdgeInsets.all(18),
                        child: Column(
                          children: [
                            const Icon(Icons.error_outline_rounded, color: Color(0xFFFF4D67), size: 32),
                            const SizedBox(height: 10),
                            Text(
                              _error!,
                              textAlign: TextAlign.center,
                              style: const TextStyle(color: Colors.white70),
                            ),
                            const SizedBox(height: 12),
                            OutlinedButton.icon(
                              onPressed: _load,
                              icon: const Icon(Icons.refresh_rounded),
                              label: const Text('Coba Lagi'),
                            ),
                          ],
                        ),
                      )
                    else if (_filtered.isEmpty)
                      FangCard(
                        padding: const EdgeInsets.all(22),
                        child: const Center(
                          child: Text('Tidak ada akun yang cocok.', style: TextStyle(color: Colors.white54)),
                        ),
                      )
                    else
                      ..._filtered.map((u) => Padding(
                            padding: const EdgeInsets.only(bottom: 11),
                            child: _userCard(u, fang),
                          )),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _statCard(String label, String value, IconData icon, FangThemeConfig fang) {
    return FangCard(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 13),
      child: Column(
        children: [
          Icon(icon, color: fang.accentColor, size: 19),
          const SizedBox(height: 7),
          Text(value, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w900)),
          const SizedBox(height: 3),
          Text(label, textAlign: TextAlign.center, style: TextStyle(color: fang.textMuted, fontSize: 7.5, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }

  Widget _userCard(Map<String, dynamic> user, FangThemeConfig fang) {
    final role = (user['role'] ?? 'member').toString().toLowerCase();
    final online = user['online'] == true;
    final device = user['device'] is Map
        ? Map<String, dynamic>.from(user['device'] as Map)
        : <String, dynamic>{};

    final brand = _clean(device['brand']);
    final model = _clean(device['model']);
    final android = _clean(device['androidVersion']);
    final sdk = _clean(device['androidSdk']);
    final appVersion = _clean(device['appVersion']);
    final phone = [brand, model].where((e) => e != '-').join(' ');

    return FangCard(
      padding: const EdgeInsets.all(15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _roleColor(role, fang).withOpacity(.12),
                  border: Border.all(color: _roleColor(role, fang).withOpacity(.40)),
                ),
                child: Icon(_roleIcon(role), color: _roleColor(role, fang), size: 21),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      (user['username'] ?? '-').toString(),
                      style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(999),
                            color: _roleColor(role, fang).withOpacity(.12),
                            border: Border.all(color: _roleColor(role, fang).withOpacity(.30)),
                          ),
                          child: Text(
                            role.toUpperCase(),
                            style: TextStyle(color: _roleColor(role, fang), fontSize: 7.5, fontWeight: FontWeight.w900),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          width: 7,
                          height: 7,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: online ? const Color(0xFF31D58B) : Colors.white24,
                          ),
                        ),
                        const SizedBox(width: 5),
                        Text(
                          online ? 'ONLINE' : 'OFFLINE',
                          style: TextStyle(
                            color: online ? const Color(0xFF31D58B) : fang.textMuted,
                            fontSize: 8,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Text(
                'EXP ${_clean(user['expiredDate'])}',
                style: TextStyle(color: fang.textSecondary, fontSize: 8.5, fontWeight: FontWeight.w700),
              ),
            ],
          ),
          const SizedBox(height: 13),
          Divider(color: fang.weakBorderColor, height: 1),
          const SizedBox(height: 12),
          _infoRow(Icons.smartphone_rounded, 'TIPE HP', phone.isEmpty ? 'Belum terdeteksi' : phone, fang),
          const SizedBox(height: 8),
          _infoRow(
            Icons.android_rounded,
            'ANDROID',
            android == '-' ? 'Belum terdeteksi' : 'Android $android${sdk == '-' ? '' : ' • SDK $sdk'}',
            fang,
          ),
          const SizedBox(height: 8),
          _infoRow(Icons.apps_rounded, 'VERSI APP', appVersion == '-' ? 'Belum terdeteksi' : 'v$appVersion', fang),
          const SizedBox(height: 8),
          _infoRow(Icons.login_rounded, 'LAST LOGIN', _formatDate(user['lastLogin']), fang),
          const SizedBox(height: 8),
          _infoRow(Icons.schedule_rounded, 'LAST SEEN', _formatDate(user['lastSeen']), fang),
        ],
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value, FangThemeConfig fang) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 16, color: fang.accentColor),
        const SizedBox(width: 8),
        SizedBox(
          width: 74,
          child: Text(label, style: TextStyle(color: fang.textMuted, fontSize: 7.5, fontWeight: FontWeight.w800)),
        ),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(color: Colors.white70, fontSize: 9.5, fontWeight: FontWeight.w600),
          ),
        ),
      ],
    );
  }

  Color _roleColor(String role, FangThemeConfig fang) {
    switch (role) {
      case 'developer':
        return const Color(0xFF22D3EE);
      case 'owner':
        return const Color(0xFFFFB020);
      case 'admin':
        return const Color(0xFFFF4D67);
      case 'reseller':
        return const Color(0xFF31D58B);
      case 'vip':
        return const Color(0xFFB56CFF);
      default:
        return fang.accentColor;
    }
  }

  IconData _roleIcon(String role) {
    switch (role) {
      case 'developer':
        return Icons.code_rounded;
      case 'owner':
        return Icons.workspace_premium_rounded;
      case 'admin':
        return Icons.admin_panel_settings_rounded;
      case 'reseller':
        return Icons.storefront_rounded;
      case 'vip':
        return Icons.star_rounded;
      default:
        return Icons.person_rounded;
    }
  }

  String _clean(dynamic value) {
    final text = (value ?? '').toString().trim();
    if (text.isEmpty || text.toLowerCase() == 'unknown') return '-';
    return text;
  }

  String _formatDate(dynamic value) {
    final raw = (value ?? '').toString().trim();
    if (raw.isEmpty) return 'Belum ada data';
    try {
      final dt = DateTime.parse(raw).toLocal();
      String two(int n) => n.toString().padLeft(2, '0');
      return '${two(dt.day)}/${two(dt.month)}/${dt.year} ${two(dt.hour)}:${two(dt.minute)}';
    } catch (_) {
      return raw;
    }
  }
}
