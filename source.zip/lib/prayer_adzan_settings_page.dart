import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import 'fang_global_theme.dart';
import 'prayer_adzan_service.dart';

class PrayerAdzanSettingsPage extends StatefulWidget {
  const PrayerAdzanSettingsPage({super.key});

  @override
  State<PrayerAdzanSettingsPage> createState() =>
      _PrayerAdzanSettingsPageState();
}

class _PrayerAdzanSettingsPageState extends State<PrayerAdzanSettingsPage> {
  final _cityController = TextEditingController();
  PrayerAdzanSettings _settings = const PrayerAdzanSettings();
  PrayerAdzanPermissionState? _permission;
  bool _loading = true;
  bool _saving = false;
  bool _testing = false;
  bool _locating = false;
  int _scheduledCount = 0;
  DateTime? _lastSync;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _cityController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final service = PrayerAdzanService.instance;
      final settings = await service.loadSettings();
      PrayerAdzanPermissionState? permission;
      try {
        permission = await service.permissionState();
      } catch (_) {
        permission = const PrayerAdzanPermissionState(
          notificationsAllowed: false,
          exactAlarmAllowed: false,
        );
      }
      final count = await service.lastScheduledCount();
      final sync = await service.lastSync();
      if (!mounted) return;
      setState(() {
        _settings = settings;
        _cityController.text = settings.city;
        _permission = permission;
        _scheduledCount = count;
        _lastSync = sync;
      });
    } catch (e) {
      if (mounted) {
        _snack('Gagal membuka pengaturan adzan: $e', error: true);
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _requestPermission() async {
    try {
      final state = await PrayerAdzanService.instance.requestPermissions();
      if (!mounted) return;
      setState(() => _permission = state);
    } catch (e) {
      if (mounted) _snack('Gagal meminta izin Android: $e', error: true);
    }
  }


  Future<void> _detectPreciseLocation() async {
    if (_locating) return;
    setState(() => _locating = true);
    try {
      final detected = await PrayerAdzanService.instance.detectPreciseLocation();
      if (!mounted) return;
      setState(() {
        _settings = detected;
        _cityController.text = detected.city;
      });
      final accuracy = detected.locationAccuracyMeters;
      _snack(
        accuracy == null
            ? 'Lokasi GPS presisi berhasil dipakai.'
            : 'Lokasi GPS dipakai (akurasi ±${accuracy.toStringAsFixed(0)} m).',
      );
    } catch (e) {
      if (mounted) _snack('$e', error: true);
    } finally {
      if (mounted) setState(() => _locating = false);
    }
  }

  Future<void> _save() async {
    final city = _cityController.text.trim();
    if (city.isEmpty) {
      _snack('Isi nama kota terlebih dahulu.', error: true);
      return;
    }

    setState(() => _saving = true);
    final cityChanged = city != _settings.city;
    final next = _settings.copyWith(
      city: city,
      clearCoordinates: cityChanged,
    );

    try {
      if (next.enabled) {
        await PrayerAdzanService.instance.requestPermissions();
      }

      final result = await PrayerAdzanService.instance.applySettings(
        next,
        requestPermission: false,
      );
      final permission = await PrayerAdzanService.instance.permissionState();
      final sync = await PrayerAdzanService.instance.lastSync();

      if (!mounted) return;
      setState(() {
        _settings = next;
        _permission = permission;
        _scheduledCount = result.scheduledCount;
        _lastSync = sync;
      });

      if (result.success) {
        _snack(
          next.enabled
              ? 'Auto Adzan aktif. ${result.scheduledCount} jadwal sudah dipasang.'
              : 'Auto Adzan dimatikan.',
        );
      } else {
        _snack('Gagal menjadwalkan: ${result.error}', error: true);
      }
    } catch (e) {
      if (mounted) _snack('Gagal menyimpan Auto Adzan: $e', error: true);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _test({bool subuh = false}) async {
    setState(() => _testing = true);
    try {
      await PrayerAdzanService.instance.saveSettings(_settings);
      await PrayerAdzanService.instance.testAdzan(subuh: subuh);
      if (mounted) {
        _snack(subuh ? 'Test Adzan Subuh diputar.' : 'Test Adzan biasa diputar.');
      }
    } catch (e) {
      if (mounted) _snack('Test gagal: $e', error: true);
    } finally {
      if (mounted) setState(() => _testing = false);
    }
  }

  Future<void> _stopAdzan() async {
    try {
      await PrayerAdzanService.instance.stopAdzan();
      if (mounted) _snack('Adzan dihentikan.');
    } catch (e) {
      if (mounted) _snack('Gagal menghentikan adzan: $e', error: true);
    }
  }

  void _snack(String text, {bool error = false}) {
    final fang = FangThemeController.instance.config;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text),
        backgroundColor: error ? const Color(0xFFB42318) : fang.accentColor,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: FangThemeController.instance,
      builder: (context, _) {
        final fang = FangThemeController.instance.config;
        return Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            title: const Text(
              'Jadwal Sholat & Auto Adzan',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17),
            ),
          ),
          body: FangBackground(
            child: _loading
                ? Center(
                    child: CircularProgressIndicator(color: fang.accentColor),
                  )
                : ListView(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
                    children: [
                      _hero(fang),
                      const SizedBox(height: 16),
                      _masterCard(fang),
                      const SizedBox(height: 16),
                      _locationCard(fang),
                      const SizedBox(height: 16),
                      _prayerCard(fang),
                      const SizedBox(height: 16),
                      _soundCard(fang),
                      const SizedBox(height: 16),
                      _permissionCard(fang),
                      const SizedBox(height: 16),
                      _statusCard(fang),
                      const SizedBox(height: 20),
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: _testing ? null : () => _test(subuh: false),
                              icon: _testing
                                  ? const SizedBox(
                                      width: 16,
                                      height: 16,
                                      child: CircularProgressIndicator(strokeWidth: 2),
                                    )
                                  : const Icon(Icons.volume_up_rounded),
                              label: const Text('TEST ADZAN'),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: _saving ? null : _save,
                              icon: _saving
                                  ? const SizedBox(
                                      width: 16,
                                      height: 16,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        color: Colors.white,
                                      ),
                                    )
                                  : const Icon(Icons.alarm_on_rounded),
                              label: Text(_saving ? 'MENYIMPAN...' : 'SIMPAN'),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      Text(
                        'Catatan: Android dapat membatasi alarm presisi jika izin Alarm & reminder belum diberikan. '
                        'Jadwal dibuat sampai ${PrayerAdzanService.scheduleDays} hari ke depan dan diperbarui otomatis saat aplikasi dibuka kembali.',
                        style: TextStyle(
                          color: fang.textSecondary,
                          fontSize: 11,
                          height: 1.5,
                        ),
                      ),
                    ],
                  ),
          ),
        );
      },
    );
  }

  Widget _hero(FangThemeConfig fang) {
    return FangCard(
      strongerGlow: true,
      padding: const EdgeInsets.all(18),
      child: Row(
        children: [
          FangNeonIcon(icon: Icons.mosque_rounded, boxSize: 58, size: 29),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'AUTO ADZAN',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 19,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  'Adzan tetap dijadwalkan oleh Android meskipun aplikasi sedang tidak dibuka.',
                  style: TextStyle(
                    color: fang.textSecondary,
                    fontSize: 11.5,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _masterCard(FangThemeConfig fang) {
    return FangCard(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      child: SwitchListTile(
        contentPadding: EdgeInsets.zero,
        value: _settings.enabled,
        activeColor: fang.accentColor,
        secondary: Icon(
          _settings.enabled ? Icons.notifications_active_rounded : Icons.notifications_off_rounded,
          color: fang.accentColor,
        ),
        title: const Text(
          'Auto Adzan',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800),
        ),
        subtitle: Text(
          _settings.enabled ? 'Aktif untuk jadwal yang dipilih.' : 'Tidak ada adzan yang dijadwalkan.',
          style: TextStyle(color: fang.textSecondary, fontSize: 11),
        ),
        onChanged: (value) {
          setState(() => _settings = _settings.copyWith(enabled: value));
        },
      ),
    );
  }

  Widget _locationCard(FangThemeConfig fang) {
    return FangCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle(fang, Icons.location_city_rounded, 'LOKASI JADWAL'),
          const SizedBox(height: 13),
          TextField(
            controller: _cityController,
            style: const TextStyle(color: Colors.white),
            textInputAction: TextInputAction.done,
            decoration: InputDecoration(
              hintText: 'Contoh: Jakarta, Surabaya, Makassar',
              prefixIcon: Icon(Icons.location_on_rounded, color: fang.accentColor),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _locating ? null : _detectPreciseLocation,
              icon: _locating
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.my_location_rounded),
              label: Text(_settings.latitude != null
                  ? 'PERBARUI GPS PRESISI'
                  : 'GUNAKAN GPS PRESISI'),
            ),
          ),
          const SizedBox(height: 9),
          Text(
            _settings.latitude != null && _settings.longitude != null
                ? 'Mode GPS aktif • ${_settings.latitude!.toStringAsFixed(5)}, ${_settings.longitude!.toStringAsFixed(5)}${_settings.locationAccuracyMeters != null ? ' • ±${_settings.locationAccuracyMeters!.toStringAsFixed(0)} m' : ''}'
                : 'Pilih GPS Presisi agar jadwal dihitung dari koordinat perangkat, bukan hanya nama kota.',
            style: TextStyle(color: fang.textSecondary, fontSize: 10.5),
          ),
          const SizedBox(height: 5),
          Text(
            'Perhitungan memakai metode Kementerian Agama Republik Indonesia.',
            style: TextStyle(color: fang.textSecondary, fontSize: 10.5),
          ),
        ],
      ),
    );
  }

  Widget _prayerCard(FangThemeConfig fang) {
    final items = <(String, IconData, bool, ValueChanged<bool>)>[
      ('Subuh', Icons.nights_stay_rounded, _settings.subuh,
          (v) => setState(() => _settings = _settings.copyWith(subuh: v))),
      ('Dzuhur', Icons.wb_sunny_rounded, _settings.dzuhur,
          (v) => setState(() => _settings = _settings.copyWith(dzuhur: v))),
      ('Ashar', Icons.light_mode_rounded, _settings.ashar,
          (v) => setState(() => _settings = _settings.copyWith(ashar: v))),
      ('Maghrib', Icons.wb_twilight_rounded, _settings.maghrib,
          (v) => setState(() => _settings = _settings.copyWith(maghrib: v))),
      ('Isya', Icons.dark_mode_rounded, _settings.isya,
          (v) => setState(() => _settings = _settings.copyWith(isya: v))),
    ];

    return FangCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle(fang, Icons.tune_rounded, 'ADZAN PER SHOLAT'),
          const SizedBox(height: 7),
          ...items.map((item) => SwitchListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                activeColor: fang.accentColor,
                value: item.$3,
                secondary: Icon(item.$2, color: item.$3 ? fang.accentColor : fang.textMuted),
                title: Text(
                  item.$1,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                ),
                onChanged: item.$4,
              )),
        ],
      ),
    );
  }

  Widget _soundCard(FangThemeConfig fang) {
    final percent = (_settings.volume * 100).round();

    return FangCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle(fang, Icons.volume_up_rounded, 'SUARA ADZAN'),
          const SizedBox(height: 10),

          Row(
            children: [
              const Icon(
                Icons.check_circle_rounded,
                color: Color(0xFF00E676),
                size: 18,
              ),
              const SizedBox(width: 8),
              const Expanded(
                child: Text(
                  'Adzan biasa • adhan.mp3',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFF00E676).withOpacity(.12),
                  borderRadius: BorderRadius.circular(99),
                  border: Border.all(
                    color: const Color(0xFF00E676).withOpacity(.45),
                  ),
                ),
                child: const Text(
                  'READY',
                  style: TextStyle(
                    color: Color(0xFF00E676),
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: .7,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 7),
          Row(
            children: [
              const Icon(
                Icons.check_circle_rounded,
                color: Color(0xFF00E676),
                size: 18,
              ),
              const SizedBox(width: 8),
              const Expanded(
                child: Text(
                  'Adzan Subuh • adhan_subuh.mp3',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFF00E676).withOpacity(.12),
                  borderRadius: BorderRadius.circular(99),
                  border: Border.all(
                    color: const Color(0xFF00E676).withOpacity(.45),
                  ),
                ),
                child: const Text(
                  'READY',
                  style: TextStyle(
                    color: Color(0xFF00E676),
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: .7,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            'Foreground playback • tetap berjalan sampai audio selesai saat '
            'notification shade dibuka, layar dikunci, atau pindah halaman.',
            style: TextStyle(
              color: fang.textSecondary,
              fontSize: 10.5,
              height: 1.45,
            ),
          ),

          const SizedBox(height: 14),

          Row(
            children: [
              Icon(Icons.volume_down_rounded, color: fang.accentColor),
              Expanded(
                child: Slider(
                  value: _settings.volume.clamp(0.05, 1.0),
                  min: 0.05,
                  max: 1.0,
                  divisions: 19,
                  label: '$percent%',
                  activeColor: fang.accentColor,
                  onChanged: (value) {
                    setState(() {
                      _settings = _settings.copyWith(volume: value);
                    });
                    PrayerAdzanService.instance.setPlaybackVolume(value);
                  },
                ),
              ),
              Icon(Icons.volume_up_rounded, color: fang.accentColor),
              const SizedBox(width: 6),
              SizedBox(
                width: 44,
                child: Text(
                  '$percent%',
                  textAlign: TextAlign.end,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 10),

          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _testing ? null : () => _test(subuh: false),
                  icon: const Icon(Icons.play_arrow_rounded),
                  label: const Text('TEST BIASA'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _testing ? null : () => _test(subuh: true),
                  icon: const Icon(Icons.nights_stay_rounded),
                  label: const Text('TEST SUBUH'),
                ),
              ),
            ],
          ),

          const SizedBox(height: 8),

          SizedBox(
            width: double.infinity,
            child: TextButton.icon(
              onPressed: _stopAdzan,
              icon: const Icon(Icons.stop_circle_outlined),
              label: const Text('STOP ADZAN'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _permissionCard(FangThemeConfig fang) {
    final notificationOk = _permission?.notificationsAllowed ?? false;
    final exactOk = _permission?.exactAlarmAllowed ?? false;

    return FangCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle(fang, Icons.admin_panel_settings_rounded, 'IZIN ANDROID'),
          const SizedBox(height: 12),
          _permissionRow(fang, 'Notifikasi', notificationOk),
          const SizedBox(height: 9),
          _permissionRow(fang, 'Alarm presisi', exactOk),
          if (!notificationOk || !exactOk) ...[
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: _requestPermission,
                icon: const Icon(Icons.lock_open_rounded),
                label: const Text('IZINKAN NOTIFIKASI & ALARM'),
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: TextButton.icon(
                onPressed: () => openAppSettings(),
                icon: const Icon(Icons.settings_rounded),
                label: const Text('BUKA SETELAN APLIKASI'),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _statusCard(FangThemeConfig fang) {
    final syncText = _lastSync == null
        ? 'Belum pernah sinkron'
        : '${_lastSync!.day.toString().padLeft(2, '0')}/${_lastSync!.month.toString().padLeft(2, '0')}/${_lastSync!.year} '
          '${_lastSync!.hour.toString().padLeft(2, '0')}:${_lastSync!.minute.toString().padLeft(2, '0')}';

    return FangCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle(fang, Icons.schedule_rounded, 'STATUS JADWAL'),
          const SizedBox(height: 13),
          Row(
            children: [
              Expanded(child: _stat(fang, 'TERPASANG', '$_scheduledCount', Icons.alarm_rounded)),
              const SizedBox(width: 10),
              Expanded(child: _stat(fang, 'HORIZON', '${PrayerAdzanService.scheduleDays} HARI', Icons.calendar_month_rounded)),
            ],
          ),
          const SizedBox(height: 12),
          Text('Sinkron terakhir: $syncText', style: TextStyle(color: fang.textSecondary, fontSize: 10.5)),
        ],
      ),
    );
  }

  Widget _stat(FangThemeConfig fang, String label, String value, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: fang.accentSoft,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: fang.weakBorderColor),
      ),
      child: Row(
        children: [
          Icon(icon, color: fang.accentColor, size: 20),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: TextStyle(color: fang.textSecondary, fontSize: 8, fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(value, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w900)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _permissionRow(FangThemeConfig fang, String label, bool ok) {
    return Row(
      children: [
        Icon(
          ok ? Icons.check_circle_rounded : Icons.error_outline_rounded,
          color: ok ? const Color(0xFF31D58B) : const Color(0xFFFFB020),
          size: 19,
        ),
        const SizedBox(width: 9),
        Expanded(
          child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
        ),
        Text(
          ok ? 'SIAP' : 'PERLU IZIN',
          style: TextStyle(
            color: ok ? const Color(0xFF31D58B) : const Color(0xFFFFB020),
            fontSize: 9,
            fontWeight: FontWeight.w900,
          ),
        ),
      ],
    );
  }

  Widget _sectionTitle(FangThemeConfig fang, IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, color: fang.accentColor, size: 19),
        const SizedBox(width: 8),
        Text(
          text,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w900,
            fontSize: 12,
            letterSpacing: .6,
          ),
        ),
      ],
    );
  }
}
