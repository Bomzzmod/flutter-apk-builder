import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

import 'api_config.dart';
import 'fang_global_theme.dart';

class ChatAllPage extends StatefulWidget {
  final String username;
  final String role;
  final String sessionKey;

  const ChatAllPage({
    super.key,
    required this.username,
    required this.role,
    required this.sessionKey,
  });

  @override
  State<ChatAllPage> createState() => _ChatAllPageState();
}

class _ChatAllPageState extends State<ChatAllPage> {
  final _messageController = TextEditingController();
  final _scrollController = ScrollController();
  final List<_ChatMessage> _messages = [];

  WebSocketChannel? _channel;
  StreamSubscription? _subscription;
  Timer? _reconnectTimer;
  Timer? _typingTimer;
  bool _disposed = false;
  bool _connected = false;
  bool _connecting = true;
  bool _sending = false;
  int _online = 0;
  String? _error;
  String? _typingUser;

  @override
  void initState() {
    super.initState();
    _connect();
  }

  @override
  void dispose() {
    _disposed = true;
    _reconnectTimer?.cancel();
    _typingTimer?.cancel();
    _subscription?.cancel();
    _channel?.sink.close();
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _connect() async {
    if (_disposed) return;
    _reconnectTimer?.cancel();
    _subscription?.cancel();
    _channel?.sink.close();

    setState(() {
      _connecting = true;
      _connected = false;
      _error = null;
    });

    try {
      final channel = WebSocketChannel.connect(Uri.parse(chatWsUrl));
      _channel = channel;
      await channel.ready.timeout(const Duration(seconds: 10));
      if (_disposed || _channel != channel) {
        await channel.sink.close();
        return;
      }

      _subscription = channel.stream.listen(
        _handleEvent,
        onError: (Object error) {
          if (_disposed) return;
          setState(() {
            _connected = false;
            _connecting = false;
            _error = 'Chat server tidak dapat dihubungi.';
          });
          _scheduleReconnect();
        },
        onDone: () {
          if (_disposed) return;
          setState(() {
            _connected = false;
            _connecting = false;
            _error = 'Koneksi chat terputus. Mencoba sambung ulang…';
          });
          _scheduleReconnect();
        },
      );

      // API menentukan username + role dari session key.
      // Field username/role tetap dikirim untuk kompatibilitas, tetapi server
      // tidak mempercayainya sebagai sumber otorisasi.
      channel.sink.add(jsonEncode({
        'type': 'auth',
        'key': widget.sessionKey,
        'username': widget.username,
        'role': widget.role,
      }));
    } catch (e) {
      if (_disposed) return;
      setState(() {
        _connected = false;
        _connecting = false;
        _error = 'Chat server tidak dapat dihubungi: $e';
      });
      _scheduleReconnect();
    }
  }

  void _scheduleReconnect() {
    if (_disposed) return;
    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(const Duration(seconds: 4), _connect);
  }

  void _handleEvent(dynamic raw) {
    if (_disposed) return;
    try {
      final decoded = jsonDecode(raw.toString());
      if (decoded is! Map) return;
      final data = Map<String, dynamic>.from(decoded);
      final type = data['type']?.toString();

      switch (type) {
        case 'ready':
          setState(() {
            _connected = true;
            _connecting = false;
            _error = null;
            _online = int.tryParse('${data['online'] ?? 0}') ?? 0;
          });
          break;
        case 'history':
          final rawMessages = data['messages'];
          if (rawMessages is List) {
            final parsed = rawMessages
                .whereType<Map>()
                .map((e) => _ChatMessage.fromJson(Map<String, dynamic>.from(e)))
                .toList();
            setState(() {
              _messages
                ..clear()
                ..addAll(parsed);
              _connected = true;
              _connecting = false;
              _error = null;
            });
          }
          break;
        case 'message':
          final rawMessage = data['message'];
          if (rawMessage is Map) {
            final message = _ChatMessage.fromJson(
              Map<String, dynamic>.from(rawMessage),
            );
            if (!_messages.any((m) => m.id == message.id)) {
              setState(() => _messages.add(message));
            }
          }
          break;
        case 'presence':
          setState(() {
            _online = int.tryParse('${data['online'] ?? 0}') ?? _online;
          });
          break;
        case 'typing':
          final user = data['username']?.toString();
          if (user != null && user.isNotEmpty && user != widget.username) {
            setState(() => _typingUser = user);
            _typingTimer?.cancel();
            _typingTimer = Timer(const Duration(seconds: 2), () {
              if (mounted) setState(() => _typingUser = null);
            });
          }
          break;
        case 'error':
          setState(() {
            _connecting = false;
            _error = data['message']?.toString() ?? 'Chat server error.';
          });
          break;
      }
    } catch (_) {}
  }

  void _sendTyping() {
    if (!_connected) return;
    try {
      _channel?.sink.add(jsonEncode({'type': 'typing'}));
    } catch (_) {}
  }

  Future<void> _send() async {
    final text = _messageController.text.trim();
    if (text.isEmpty || _sending) return;
    if (!_connected) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Chat belum terhubung ke server.')),
      );
      return;
    }

    setState(() => _sending = true);
    try {
      _channel?.sink.add(jsonEncode({
        'type': 'message',
        'text': text,
      }));
      _messageController.clear();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal mengirim pesan: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: FangThemeController.instance,
      builder: (context, _) {
        final fang = FangThemeController.instance.config;
        return FangBackground(
          child: SafeArea(
            child: Column(
              children: [
                _header(fang),
                if (_error != null) _connectionBanner(fang),
                Expanded(
                  child: _messages.isEmpty
                      ? _emptyState(fang)
                      : ListView.builder(
                          controller: _scrollController,
                          reverse: true,
                          padding: const EdgeInsets.fromLTRB(14, 12, 14, 16),
                          itemCount: _messages.length,
                          itemBuilder: (context, index) {
                            final message = _messages[_messages.length - 1 - index];
                            return _messageBubble(fang, message);
                          },
                        ),
                ),
                if (_typingUser != null)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 0, 18, 7),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        '$_typingUser sedang mengetik…',
                        style: TextStyle(
                          color: fang.textSecondary,
                          fontSize: 11,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ),
                  ),
                _composer(fang),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _header(FangThemeConfig fang) {
    final onlineColor = _connected ? const Color(0xFF31D58B) : const Color(0xFFFFB020);
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 8),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 280),
        curve: Curves.easeOutCubic,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: fang.surface.withOpacity(.96),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: fang.weakBorderColor, width: 1),
        ),
        child: Row(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 280),
              width: 50, height: 50,
              decoration: BoxDecoration(
                color: fang.accentColor.withOpacity(.10),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: fang.accentColor.withOpacity(.45)),
              ),
              child: Icon(Icons.forum_rounded, color: fang.accentColor, size: 25),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Text('GLOBAL CHAT', style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w900, letterSpacing: .5)),
                      const SizedBox(width: 7),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                        decoration: BoxDecoration(
                          color: fang.accentColor.withOpacity(.10),
                          borderRadius: BorderRadius.circular(7),
                          border: Border.all(color: fang.accentColor.withOpacity(.24)),
                        ),
                        child: Text('FANG', style: TextStyle(color: fang.accentColor, fontSize: 7, fontWeight: FontWeight.w900)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Ruang ngobrol seluruh pengguna',
                    style: TextStyle(color: fang.textSecondary, fontSize: 10.5, fontWeight: FontWeight.w500),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 500),
                      width: 8, height: 8,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: onlineColor),
                    ),
                    const SizedBox(width: 5),
                    Text(_connecting ? 'CONNECTING' : (_connected ? 'ONLINE' : 'OFFLINE'), style: TextStyle(color: onlineColor, fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: .4)),
                  ],
                ),
                const SizedBox(height: 5),
                Text('$_online ONLINE', style: TextStyle(color: fang.textMuted, fontSize: 8.5, fontWeight: FontWeight.w700)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _connectionBanner(FangThemeConfig fang) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 4, 14, 3),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        decoration: BoxDecoration(
          color: const Color(0xFFFFB020).withOpacity(.10),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFFFFB020).withOpacity(.35)),
        ),
        child: Row(
          children: [
            const Icon(Icons.info_outline_rounded, color: Color(0xFFFFB020), size: 17),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                _error!,
                style: const TextStyle(color: Colors.white70, fontSize: 10.5),
              ),
            ),
            TextButton(onPressed: _connect, child: const Text('COBA LAGI')),
          ],
        ),
      ),
    );
  }

  Widget _emptyState(FangThemeConfig fang) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            FangNeonIcon(icon: Icons.chat_bubble_outline_rounded, boxSize: 70, size: 32),
            const SizedBox(height: 16),
            Text(
              _connected ? 'Belum ada pesan' : 'Menghubungkan Chat All…',
              style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 5),
            Text(
              _connected
                  ? 'Jadi orang pertama yang kirim pesan di room ini.'
                  : 'Pastikan API DARKRELAY sedang online.',
              textAlign: TextAlign.center,
              style: TextStyle(color: fang.textSecondary, fontSize: 11),
            ),
          ],
        ),
      ),
    );
  }

  Widget _messageBubble(FangThemeConfig fang, _ChatMessage message) {
    final mine = message.username.toLowerCase() == widget.username.toLowerCase();
    final roleColor = _roleColor(message.role, fang);
    final initials = message.username.trim().isEmpty
        ? '?'
        : message.username.trim().substring(0, 1).toUpperCase();

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        mainAxisAlignment:
            mine ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!mine) ...[
            Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [
                    roleColor.withOpacity(.35),
                    fang.accentColor.withOpacity(.10),
                  ],
                ),
                border: Border.all(color: roleColor.withOpacity(.48)),
                boxShadow: [
                  BoxShadow(
                    color: roleColor.withOpacity(.13),
                    blurRadius: 10,
                  ),
                ],
              ),
              alignment: Alignment.center,
              child: Text(
                initials,
                style: TextStyle(
                  color: roleColor,
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Container(
              constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width * .78,
              ),
              padding: const EdgeInsets.fromLTRB(13, 10, 13, 9),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: mine
                      ? [
                          fang.accentColor.withOpacity(.92),
                          fang.accentColor.withOpacity(.78),
                        ]
                      : [
                          fang.surfaceAlt,
                          fang.surface,
                        ],
                ),
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(18),
                  topRight: const Radius.circular(18),
                  bottomLeft: Radius.circular(mine ? 18 : 5),
                  bottomRight: Radius.circular(mine ? 5 : 18),
                ),
                border: Border.all(
                  color: mine
                      ? fang.accentColor.withOpacity(.50)
                      : fang.weakBorderColor.withOpacity(.90),
                ),
                boxShadow: [
                  BoxShadow(
                    color: (mine ? fang.accentColor : Colors.black)
                        .withOpacity(mine ? .12 : .18),
                    blurRadius: 14,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Flexible(
                        child: Text(
                          message.username,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 11.5,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                      const SizedBox(width: 7),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6.5,
                          vertical: 2.5,
                        ),
                        decoration: BoxDecoration(
                          color: roleColor.withOpacity(.13),
                          borderRadius: BorderRadius.circular(7),
                          border: Border.all(
                            color: roleColor.withOpacity(.34),
                          ),
                        ),
                        child: Text(
                          message.role.toUpperCase(),
                          style: TextStyle(
                            color: roleColor,
                            fontSize: 7,
                            fontWeight: FontWeight.w900,
                            letterSpacing: .35,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    message.text,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      height: 1.38,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        _formatTime(message.createdAt),
                        style: TextStyle(
                          color: fang.textMuted,
                          fontSize: 8.5,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      if (mine) ...[
                        const SizedBox(width: 5),
                        Icon(
                          Icons.done_all_rounded,
                          size: 12,
                          color: fang.accentColor.withOpacity(.82),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _composer(FangThemeConfig fang) {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
        decoration: BoxDecoration(
          color: fang.navigationColor.withOpacity(.97),
          border: Border(
            top: BorderSide(color: fang.weakBorderColor.withOpacity(.8)),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.25),
              blurRadius: 18,
              offset: const Offset(0, -6),
            ),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  color: fang.surface.withOpacity(.92),
                  border: Border.all(color: fang.weakBorderColor),
                ),
                child: TextField(
                  controller: _messageController,
                  minLines: 1,
                  maxLines: 4,
                  maxLength: 250,
                  onChanged: (_) => _sendTyping(),
                  decoration: InputDecoration(
                    hintText: 'Tulis pesan ke Chat All…',
                    counterText: '',
                    prefixIcon: Icon(
                      Icons.chat_bubble_outline_rounded,
                      color: fang.accentColor,
                      size: 21,
                    ),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 4,
                      vertical: 13,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(17),
                boxShadow: [
                  BoxShadow(
                    color: fang.accentColor.withOpacity(.24),
                    blurRadius: 14,
                  ),
                ],
              ),
              child: FilledButton(
                style: FilledButton.styleFrom(
                  padding: EdgeInsets.zero,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(17),
                  ),
                ),
                onPressed: _sending ? null : _send,
                child: _sending
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.send_rounded, size: 22),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _roleColor(String role, FangThemeConfig fang) {
    switch (role.toLowerCase()) {
      case 'developer':
        return const Color(0xFF22D3EE);
      case 'owner':
        return const Color(0xFFFFB020);
      case 'admin':
        return const Color(0xFFFF4D67);
      case 'reseller':
        return const Color(0xFF31D58B);
      default:
        return fang.accentColor;
    }
  }

  String _formatTime(DateTime date) {
    final local = date.toLocal();
    return '${local.hour.toString().padLeft(2, '0')}:${local.minute.toString().padLeft(2, '0')}';
  }
}

class _ChatMessage {
  final String id;
  final String username;
  final String role;
  final String text;
  final DateTime createdAt;

  const _ChatMessage({
    required this.id,
    required this.username,
    required this.role,
    required this.text,
    required this.createdAt,
  });

  factory _ChatMessage.fromJson(Map<String, dynamic> json) {
    return _ChatMessage(
      id: json['id']?.toString() ?? DateTime.now().microsecondsSinceEpoch.toString(),
      username: json['username']?.toString() ?? 'user',
      role: json['role']?.toString() ?? 'user',
      text: json['text']?.toString() ?? '',
      createdAt: DateTime.tryParse(json['createdAt']?.toString() ?? '') ?? DateTime.now(),
    );
  }
}
