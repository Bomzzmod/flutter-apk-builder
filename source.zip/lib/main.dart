import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'admin_page.dart';
import 'ai_page.dart';
import 'dashboard_page.dart';
import 'developer_page.dart';
import 'fang_global_theme.dart';
import 'home_page.dart';
import 'landing.dart';
import 'login_page.dart';
import 'owner_page.dart';
import 'prayer_adzan_service.dart';
import 'seller_page.dart';

Route<dynamic> _generateRoute(RouteSettings settings) {
  final args = settings.arguments as Map<String, dynamic>?;
  late final Widget page;

  switch (settings.name) {
    case '/':
      page = LandingPage();
      break;
    case '/login':
      page = const LoginPage();
      break;
    case '/dashboard':
      if (args == null) {
        page = const _NotFoundPage(routeName: '/dashboard (missing arguments)');
        break;
      }
      page = DashboardPage(
        username: args['username']?.toString() ?? '',
        password: args['password']?.toString() ?? '',
        role: args['role']?.toString() ?? 'user',
        sessionKey: args['key']?.toString() ?? args['sessionKey']?.toString() ?? '',
        expiredDate: args['expiredDate']?.toString() ?? '-',
        listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? const []),
        listDoos: List<Map<String, dynamic>>.from(args['listDoos'] ?? const []),
        news: List<Map<String, dynamic>>.from(args['news'] ?? const []),
      );
      break;
    case '/home':
      if (args == null) {
        page = const _NotFoundPage(routeName: '/home (missing arguments)');
        break;
      }
      page = HomePage(
        username: args['username']?.toString() ?? '',
        password: args['password']?.toString() ?? '',
        role: args['role']?.toString() ?? 'user',
        expiredDate: args['expiredDate']?.toString() ?? '-',
        sessionKey: args['sessionKey']?.toString() ?? args['key']?.toString() ?? '',
        listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? const []),
      );
      break;
    case '/ai':
      if (args == null) {
        page = const _NotFoundPage(routeName: '/ai (missing arguments)');
        break;
      }
      page = AIChatPage(
        username: args['username']?.toString() ?? '',
        sessionKey: args['sessionKey']?.toString() ?? args['key']?.toString() ?? '',
      );
      break;
    case '/seller':
      page = SellerPage(keyToken: args?['keyToken']?.toString() ?? '');
      break;
    case '/admin':
      page = AdminPage(sessionKey: args?['sessionKey']?.toString() ?? '');
      break;
    case '/developer':
      page = DeveloperPage(
        sessionKey: args?['sessionKey']?.toString() ?? '',
      );
      break;
    case '/owner':
      page = OwnerPage(
        sessionKey: args?['sessionKey']?.toString() ?? '',
        username: args?['username']?.toString() ?? '',
      );
      break;
    default:
      page = _NotFoundPage(routeName: settings.name ?? 'unknown');
  }

  return PageRouteBuilder<dynamic>(
    settings: settings,
    transitionDuration: const Duration(milliseconds: 260),
    reverseTransitionDuration: const Duration(milliseconds: 220),
    pageBuilder: (_, __, ___) => page,
    transitionsBuilder: (_, animation, secondaryAnimation, child) {
      final curve = CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
      return FadeTransition(
        opacity: curve,
        child: SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 0.025),
            end: Offset.zero,
          ).animate(curve),
          child: child,
        ),
      );
    },
  );
}

class _NotFoundPage extends StatelessWidget {
  const _NotFoundPage({required this.routeName});

  final String routeName;

  @override
  Widget build(BuildContext context) {
    final fang = FangThemeController.instance.config;
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: FangBackground(
        child: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(28),
              child: FangCard(
                padding: const EdgeInsets.all(24),
                strongerGlow: true,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    FangNeonIcon(icon: Icons.explore_off_rounded, boxSize: 62, size: 28),
                    const SizedBox(height: 18),
                    const Text(
                      'Halaman tidak ditemukan',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      routeName,
                      textAlign: TextAlign.center,
                      style: TextStyle(color: fang.textSecondary, fontSize: 12),
                    ),
                    const SizedBox(height: 22),
                    OutlinedButton.icon(
                      onPressed: () => Navigator.of(context)
                          .pushNamedAndRemoveUntil('/', (_) => false),
                      icon: const Icon(Icons.home_rounded),
                      label: const Text('Kembali'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await FangThemeController.instance.init();

  // Jangan sampai masalah notifikasi/adzan membuat aplikasi gagal start.
  try {
    await PrayerAdzanService.instance.initialize();
  } catch (e, st) {
    debugPrint('PrayerAdzanService init error: $e\n$st');
  }

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    statusBarBrightness: Brightness.dark,
    systemNavigationBarColor: Color(0xFF04030A),
    systemNavigationBarDividerColor: Colors.transparent,
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  await SystemChrome.setPreferredOrientations(const [
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  runApp(const _FangApp());

  // Refresh jadwal di belakang setelah UI sudah tampil.
  unawaited(
    PrayerAdzanService.instance.refreshIfEnabled().catchError((Object error, StackTrace stack) {
      debugPrint('Auto Adzan refresh error: $error\n$stack');
    }),
  );
}

class _FangApp extends StatelessWidget {
  const _FangApp();

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: FangThemeController.instance,
      builder: (context, _) {
        final fang = FangThemeController.instance.config;
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Fang Shadow',
          theme: fang.toThemeData(),
          initialRoute: '/',
          onGenerateRoute: _generateRoute,
          builder: (context, child) {
            final mq = MediaQuery.of(context);
            final themedChild = FangBackground(
              child: child ?? const SizedBox.shrink(),
            );
            return MediaQuery(
              data: mq.copyWith(
                textScaler: TextScaler.linear(
                  mq.textScaler.scale(1).clamp(0.85, 1.20).toDouble(),
                ),
              ),
              child: themedChild,
            );
          },
        );
      },
    );
  }
}
