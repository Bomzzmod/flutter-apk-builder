
import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:math' show Random;
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:glaze_nav_bar/glaze_nav_bar.dart';

import 'api_config.dart';
import 'nik_check.dart';
import 'admin_page.dart';
import 'developer_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'al_quran.dart';
import 'anime_home.dart';
import 'fang_global_theme.dart';
import 'prayer_adzan_service.dart';
import 'prayer_adzan_settings_page.dart';
import 'chat_page.dart';
import 'ai_page.dart';
import 'spotify_page.dart';

// ─── COLORS ────────────────────────────────────────────────────────────────────
Color get kBg      => FangThemeController.instance.config.background;
Color get kCard    => FangThemeController.instance.config.surface;
Color get kCardAlt => FangThemeController.instance.config.surfaceAlt;
Color get kBorder  => FangThemeController.instance.config.borderColor;
Color get kCyan    => FangThemeController.instance.config.accentColor;
const Color kGreen   = Color(0xFF00E676);
const Color kPink    = Color(0xFFE91E8C);
const Color kOrange  = Color(0xFFFF6D00);
Color get kBlue    => FangThemeController.instance.config.accentColor;
Color get kPurple  => FangThemeController.instance.config.accentColor;
const Color kYellow  = Color(0xFFFFD600);
const Color kWhite   = Colors.white;
const Color kWhite54 = Colors.white54;
const Color kWhite24 = Colors.white24;

// ─── Prayer Time Service ───────────────────────────────────────────────────────
class PrayerTimeService {
  // Method 20 = Kementerian Agama Republik Indonesia on AlAdhan.
  // Prefer GPS coordinates because city-name lookup can point to a different
  // municipality and shift the calculated times by several minutes.
  static Future<Map<String, dynamic>> fetchPrayerTimes(
    String city, {
    double? latitude,
    double? longitude,
  }) async {
    final now = DateTime.now();
    final date = '${now.day.toString().padLeft(2, '0')}-'
        '${now.month.toString().padLeft(2, '0')}-${now.year}';
    final uri = (latitude != null && longitude != null)
        ? Uri.https('api.aladhan.com', '/v1/timings/$date', {
            'latitude': latitude.toString(),
            'longitude': longitude.toString(),
            'method': '20',
          })
        : Uri.https('api.aladhan.com', '/v1/timingsByCity', {
            'city': city,
            'country': 'Indonesia',
            'method': '20',
          });
    try {
      final res = await http.get(uri).timeout(const Duration(seconds: 12));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return {};
  }
}

// ─── Role helpers ─────────────────────────────────────────────────────────────
Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'developer': return const Color(0xFF22D3EE);
    case 'owner':    return const Color(0xFFF59E0B);
    case 'admin':    return const Color(0xFFEF4444);
    case 'reseller': return kGreen;
    case 'vip':      return kPurple;
    default:         return kCyan;
  }
}

IconData _roleIcon(String role) {
  switch (role.toLowerCase()) {
    case 'developer': return Icons.code_rounded;
    case 'owner':    return Icons.workspace_premium_rounded;
    case 'admin':    return Icons.admin_panel_settings_rounded;
    case 'reseller': return Icons.storefront_rounded;
    case 'vip':      return Icons.star_rounded;
    default:         return Icons.person_rounded;
  }
}

// ─── HEXAGON PATTERN PAINTER ──────────────────────────────────────────────────
class _HexagonPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = kCyan.withOpacity(0.12)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;

    const double w = 72.0;
    const double h = 52.0;

    for (double row = -1; row * h < size.height + h * 2; row++) {
      for (double col = -1; col * w < size.width + w * 2; col++) {
        final double offsetX = (row.toInt() % 2 == 0) ? 0 : w * 0.5;
        final cx = col * w + offsetX;
        final cy = row * h;
        _drawDiamond(canvas, paint, Offset(cx, cy), w * 0.5, h * 0.5);
      }
    }
  }

  void _drawDiamond(Canvas canvas, Paint paint, Offset center, double hw, double hh) {
    final path = Path()
      ..moveTo(center.dx, center.dy - hh)
      ..lineTo(center.dx + hw, center.dy)
      ..lineTo(center.dx, center.dy + hh)
      ..lineTo(center.dx - hw, center.dy)
      ..close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter _) => true;
}

// ─── GRID PATTERN PAINTER ─────────────────────────────────────────────────────
class _GridPatternPainter extends CustomPainter {
  final Color gridColor;
  final Color lineColor;
  final double spacing;
  const _GridPatternPainter({required this.gridColor, required this.lineColor, required this.spacing});
  @override
  void paint(Canvas canvas, Size size) {
    return;
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => true;
}

// ─── Dashboard Page ───────────────────────────────────────────────────────────
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  // ── State ────────────────────────────────────────────────────────────────
  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;

  WebSocketChannel? channel;
  StreamSubscription<dynamic>? _wsSubscription;
  Timer? _reconnectTimer;
  String androidId = 'unknown';
  File? _profileImage;
  VideoPlayerController? _menuVideoCtrl;

  int _navIndex   = 0;
  int onlineUsers = 0;
  int activeConns = 0;

  // ── Animation controllers ─────────────────────────────────────────────────
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;
  
  // ── Animasi tambahan ──────────────────────────────────────────────────────
  late AnimationController _bounceCtrl;
  late AnimationController _wobbleCtrl;
  late AnimationController _floatCtrl;
  late AnimationController _shadowCtrl;

  // Online Users polling
  Timer? _statsTimer;
  Timer? _prayerClockTimer;
  DateTime? _prayerLastFetchDate;

  // News carousel
  late PageController _newsPageCtrl;
  int _newsPageViewKey = 0;
  double _currentNewsPage = 0.0;

  // Quick Actions carousel
  late PageController _qaPageCtrl;
  double _currentQaPage = 0.0;

  // ── Location ──
  bool _locationLoading = false;
  bool _locationGranted = false;
  double? _prayerLatitude;
  double? _prayerLongitude;

  // ── Prayer times ──
  String _prayerCity = 'Jakarta';
  Map<String, String> _prayerTimes = {};
  String _nextPrayerLabel = '';
  String _nextPrayerTime  = '';
  bool _prayerLoading = true;

  // ── Hadith ──
  Map<String, dynamic>? _hadith;
  bool _hadithLoading = true;
  int _lastHadithNumber = 0;

  // ── Vinyl Animation ──
  late AnimationController _vinylRotateCtrl;
  bool _isVinylPlaying = false;

  @override
  void initState() {
    super.initState();
    sessionKey  = widget.sessionKey;
    username    = widget.username;
    FangThemeController.instance.switchAccount(username);
    password    = widget.password;
    role        = widget.role;
    expiredDate = widget.expiredDate;
    listBug     = widget.listBug;
    listDoos    = widget.listDoos;
    newsList    = widget.news;

    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();

    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.0).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _vinylRotateCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();


    // ── Init animasi tambahan ──
    _bounceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _wobbleCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _floatCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat(reverse: true);
    _shadowCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat(reverse: true);
    
    Future.delayed(Duration(milliseconds: 100 + math.Random().nextInt(400)), () {
      if (mounted) _bounceCtrl.forward();
    });

    _newsPageCtrl = PageController(viewportFraction: 0.88, initialPage: 0);
    _newsPageCtrl.addListener(() {
      if (mounted) setState(() => _currentNewsPage = _newsPageCtrl.page ?? 0.0);
    });

    _qaPageCtrl = PageController(viewportFraction: 0.88, initialPage: 0);
    _qaPageCtrl.addListener(() {
      if (mounted) setState(() => _currentQaPage = _qaPageCtrl.page ?? 0.0);
    });

    _initAndroidId();
    _loadProfileImage();
    _initMenuVideo();
    _detectLocationAndFetchPrayer();
    _prayerClockTimer = Timer.periodic(const Duration(minutes: 1), (_) {
      _updateNextPrayerFromClock();
    });
    _fetchRandomHadith();
  }

  @override
  void dispose() {
    _statsTimer?.cancel();
    _prayerClockTimer?.cancel();
    _reconnectTimer?.cancel();
    _wsSubscription?.cancel();
    channel?.sink.close(status.goingAway);
    _fadeCtrl.dispose();
    _pulseCtrl.dispose();
    _vinylRotateCtrl.dispose();
    _bounceCtrl.dispose();
    _wobbleCtrl.dispose();
    _floatCtrl.dispose();
    _shadowCtrl.dispose();
    _menuVideoCtrl?.dispose();
    _newsPageCtrl.dispose();
    _qaPageCtrl.dispose();
    super.dispose();
  }

  // ── Init helpers ──────────────────────────────────────────────────────────
  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path  = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty && mounted) {
      setState(() => _profileImage = File(path));
    }
  }

  void _initMenuVideo() {
    _menuVideoCtrl = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (mounted) setState(() {});
        _menuVideoCtrl?.setLooping(true);
        _menuVideoCtrl?.setVolume(0);
        _menuVideoCtrl?.play();
      });
  }

  Future<void> _initAndroidId() async {
    try {
      final info = await DeviceInfoPlugin().androidInfo;
      androidId = info.id;
    } catch (_) {
      androidId = 'unknown';
    }
    if (mounted) _connectWS();
  }

  Future<void> _connectWS() async {
    if (!mounted) return;

    _reconnectTimer?.cancel();
    _statsTimer?.cancel();
    _wsSubscription?.cancel();
    try {
      channel?.sink.close(status.goingAway);
    } catch (_) {}

    try {
      final nextChannel = WebSocketChannel.connect(Uri.parse(mainWsUrl));
      channel = nextChannel;
      await nextChannel.ready.timeout(const Duration(seconds: 10));
      if (!mounted || channel != nextChannel) {
        await nextChannel.sink.close(status.goingAway);
        return;
      }

      _wsSubscription = nextChannel.stream.listen(
        (event) {
          if (!mounted) return;
          try {
            final decoded = jsonDecode(event.toString());
            if (decoded is! Map) return;
            final data = Map<String, dynamic>.from(decoded);

            if (data['type'] == 'myInfo' && data['valid'] == true) {
              nextChannel.sink.add(jsonEncode({'type': 'stats'}));
            }

            if (data['type'] == 'stats') {
              setState(() {
                onlineUsers = int.tryParse('${data['onlineUsers'] ?? 0}') ?? 0;
                activeConns = int.tryParse('${data['activeConnections'] ?? 0}') ?? 0;
              });
            }

            if (data['type'] == 'myInfo' && data['valid'] == false) {
              _handleInvalidSession(data['reason']?.toString() ?? 'Session invalid');
            }

            if (data['type'] == 'forceLogout') {
              _handleInvalidSession(data['reason']?.toString() ?? 'Logged out');
            }
          } catch (_) {}
        },
        onError: (_) => _scheduleWsReconnect(),
        onDone: _scheduleWsReconnect,
        cancelOnError: false,
      );

      nextChannel.sink.add(jsonEncode({
        'type': 'validate',
        'key': sessionKey,
        'androidId': androidId,
      }));

      _statsTimer = Timer.periodic(const Duration(seconds: 5), (_) {
        try {
          nextChannel.sink.add(jsonEncode({'type': 'stats'}));
        } catch (_) {}
      });
    } catch (_) {
      _scheduleWsReconnect();
    }
  }

  void _scheduleWsReconnect() {
    if (!mounted) return;
    _statsTimer?.cancel();
    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(const Duration(seconds: 3), () {
      if (mounted) _connectWS();
    });
  }

  Future<void> _openUrl(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  Future<void> _launchDeveloperTelegram() async {
    final appUri = Uri.parse('tg://resolve?domain=BOMZZMODEJUT');
    final webUri = Uri.parse('https://t.me/BOMZZMODEJUT');

    try {
      final opened = await launchUrl(
        appUri,
        mode: LaunchMode.externalApplication,
      );
      if (opened) return;
    } catch (_) {}

    try {
      await launchUrl(
        webUri,
        mode: LaunchMode.externalApplication,
      );
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Tidak dapat membuka Telegram. Cari @BOMZZMODEJUT secara manual.'),
        ),
      );
    }
  }

  // ── Fetch Prayer Times ────────────────────────────────────────────────────
  Future<void> _fetchPrayerTimes() async {
    if (!mounted) return;
    setState(() => _prayerLoading = true);
    final data = await PrayerTimeService.fetchPrayerTimes(
      _prayerCity,
      latitude: _prayerLatitude,
      longitude: _prayerLongitude,
    );
    if (!mounted) return;
    if (data.isNotEmpty) {
      final timings = data['data']?['timings'] ?? {};
      final Map<String, String> times = {
        'Subuh': _cleanPrayerTime(timings['Fajr']),
        'Dzuhur': _cleanPrayerTime(timings['Dhuhr']),
        'Ashar': _cleanPrayerTime(timings['Asr']),
        'Maghrib': _cleanPrayerTime(timings['Maghrib']),
        'Isya': _cleanPrayerTime(timings['Isha']),
      };
      _prayerLastFetchDate = DateTime.now();
      setState(() {
        _prayerTimes = times;
        _prayerLoading = false;
      });
      _updateNextPrayerFromClock();
    } else {
      setState(() => _prayerLoading = false);
    }
  }

  String _cleanPrayerTime(dynamic value) {
    final raw = value?.toString() ?? '';
    final match = RegExp(r'(\d{1,2}):(\d{2})').firstMatch(raw);
    if (match == null) return '--:--';
    return '${match.group(1)!.padLeft(2, '0')}:${match.group(2)}';
  }

  void _updateNextPrayerFromClock() {
    if (!mounted || _prayerTimes.isEmpty) return;
    final now = DateTime.now();
    final order = ['Subuh', 'Dzuhur', 'Ashar', 'Maghrib', 'Isya'];
    String? nextLabel;
    String? nextTime;
    for (final key in order) {
      final value = _prayerTimes[key];
      if (value == null || value == '--:--') continue;
      final parts = value.split(':');
      if (parts.length != 2) continue;
      final hour = int.tryParse(parts[0]);
      final minute = int.tryParse(parts[1]);
      if (hour == null || minute == null) continue;
      final target = DateTime(now.year, now.month, now.day, hour, minute);
      final nowMinute = DateTime(now.year, now.month, now.day, now.hour, now.minute);
      if (!target.isBefore(nowMinute)) {
        nextLabel = key;
        nextTime = value;
        break;
      }
    }
    // Setelah Isya, berikutnya adalah Subuh besok.
    nextLabel ??= 'Subuh';
    nextTime ??= _prayerTimes['Subuh'] ?? '--:--';
    if (_nextPrayerLabel != nextLabel || _nextPrayerTime != nextTime) {
      setState(() {
        _nextPrayerLabel = nextLabel!;
        _nextPrayerTime = nextTime!;
      });
    }

    // Saat tanggal berganti, ambil jadwal baru agar tidak memakai jadwal kemarin.
    final fetched = _prayerLastFetchDate;
    if (fetched == null || fetched.year != now.year || fetched.month != now.month || fetched.day != now.day) {
      _fetchPrayerTimes();
    }
  }

  // ── Detect Location ───────────────────────────────────────────────────────
  Future<void> _detectLocationAndFetchPrayer() async {
    if (!mounted) return;
    setState(() => _locationLoading = true);

    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        if (mounted) {
          setState(() {
            _locationLoading = false;
            _prayerCity = 'Jakarta';
            _prayerLatitude = null;
            _prayerLongitude = null;
          });
          await _fetchPrayerTimes();
        }
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          if (mounted) {
            setState(() {
              _locationLoading = false;
              _prayerCity = 'Jakarta';
            });
            await _fetchPrayerTimes();
          }
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        if (mounted) {
          setState(() {
            _locationLoading = false;
            _prayerCity = 'Jakarta';
            _prayerLatitude = null;
            _prayerLongitude = null;
          });
          await _fetchPrayerTimes();
        }
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
      );

      final placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );

      if (placemarks.isNotEmpty && mounted) {
        final place = placemarks.first;
        final city = place.subAdministrativeArea?.isNotEmpty == true
            ? place.subAdministrativeArea!
            : place.locality?.isNotEmpty == true
                ? place.locality!
                : place.administrativeArea ?? 'Jakarta';

        setState(() {
          _prayerCity      = city;
          _prayerLatitude  = position.latitude;
          _prayerLongitude = position.longitude;
          _locationGranted = true;
          _locationLoading = false;
        });

        await _fetchPrayerTimes();
        await PrayerAdzanService.instance.updateCity(city);

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(children: [
                Icon(Icons.location_on_rounded, color: Colors.white, size: 16),
                const SizedBox(width: 8),
                Text('Lokasi terdeteksi: $city'),
              ]),
              backgroundColor: kGreen,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              duration: const Duration(seconds: 3),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _locationLoading = false;
          _prayerCity = 'Jakarta';
        });
        await _fetchPrayerTimes();
      }
    }
  }

  // ── Fetch Hadith ──────────────────────────────────────────────────────────
  Future<void> _fetchRandomHadith() async {
    if (!mounted) return;
    setState(() => _hadithLoading = true);
    try {
      int randomNumber;
      do {
        randomNumber = Random().nextInt(100) + 1;
      } while (randomNumber == _lastHadithNumber);
      _lastHadithNumber = randomNumber;
      final response = await http
          .get(Uri.parse('https://api.hadith.gading.dev/books/muslim/$randomNumber'))
          .timeout(const Duration(seconds: 8));
      if (response.statusCode == 200 && mounted) {
        setState(() { _hadith = json.decode(response.body); _hadithLoading = false; });
      } else {
        if (mounted) setState(() => _hadithLoading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _hadithLoading = false);
    }
  }

  Future<void> _openPrayerSettings() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const PrayerAdzanSettingsPage()),
    );
    final saved = await PrayerAdzanService.instance.loadSettings();
    if (!mounted) return;
    setState(() {
      _prayerCity = saved.city;
      _prayerLatitude = null;
      _prayerLongitude = null;
      _locationGranted = false;
    });
    await _fetchPrayerTimes();
  }

  // ── Change City Dialog ────────────────────────────────────────────────────
  void _showChangeCityDialog() {
    final ctrl = TextEditingController(text: _prayerCity);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text('Ganti Lokasi',
            style: TextStyle(color: kWhite, fontSize: 14)),
        content: TextField(
          controller: ctrl,
          style: const TextStyle(color: kWhite),
          decoration: InputDecoration(
            hintText: 'Nama kota (misal: Jakarta)',
            hintStyle: const TextStyle(color: kWhite54),
            filled: true, fillColor: kBg,
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
            prefixIcon: Icon(Icons.location_city_rounded, color: kGreen),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Batal', style: TextStyle(color: kWhite54))),
          ElevatedButton(
            onPressed: () {
              if (ctrl.text.trim().isNotEmpty) {
                setState(() {
                  _prayerCity = ctrl.text.trim();
                  _prayerLatitude = null;
                  _prayerLongitude = null;
                  _locationGranted = false;
                });
                _fetchPrayerTimes();
                PrayerAdzanService.instance.updateCity(ctrl.text.trim());
                Navigator.pop(context);
              }
            },
            style: ElevatedButton.styleFrom(
                backgroundColor: kGreen,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            child: Text('Simpan',
                style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  // ── Hadith Full Dialog ────────────────────────────────────────────────────
  void _showHadithFullDialog(String arabic, String indo, String source, String number, String grade) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
        child: Container(
          decoration: BoxDecoration(
            color: kCard, borderRadius: BorderRadius.circular(24),
            border: Border.all(color: kCyan.withOpacity(0.3)),
            boxShadow: [
              BoxShadow(color: kCyan.withOpacity(0.08), blurRadius: 30, spreadRadius: 2),
              BoxShadow(color: Colors.black.withOpacity(0.6), blurRadius: 20, offset: const Offset(0, 8)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
                  color: kCyan.withOpacity(0.08),
                  border: Border(bottom: BorderSide(color: kBorder.withOpacity(0.5))),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 42, height: 42,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: kCyan.withOpacity(0.2)),
                      child: Icon(Icons.menu_book_rounded, color: kCyan, size: 22),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('HADITH LENGKAP',
                            style: TextStyle(color: kWhite, fontWeight: FontWeight.bold, fontSize: 14)),
                        Text(grade, style: TextStyle(color: kCyan, fontSize: 11)),
                      ]),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        width: 34, height: 34,
                        decoration: BoxDecoration(shape: BoxShape.circle, color: kWhite.withOpacity(0.08)),
                        child: Icon(Icons.close_rounded, color: kWhite54, size: 18),
                      ),
                    ),
                  ],
                ),
              ),
              ConstrainedBox(
                constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.62),
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: double.infinity, padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          color: const Color(0xFF1A1F2E),
                          border: Border.all(color: kBorder.withOpacity(0.3)),
                        ),
                        child: Text(arabic,
                            textAlign: TextAlign.right, textDirection: TextDirection.rtl,
                            style: const TextStyle(color: kWhite, fontSize: 19, height: 2.2)),
                      ),
                      const SizedBox(height: 14),
                      Row(children: [
                        Container(width: 3, height: 18,
                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(2), color: kCyan)),
                        const SizedBox(width: 8),
                        Text('ARTINYA:', style: TextStyle(color: kCyan, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                      ]),
                      const SizedBox(height: 10),
                      Container(
                        width: double.infinity, padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: const Color(0xFF141824),
                          border: Border.all(color: kBorder.withOpacity(0.2)),
                        ),
                        child: Text(indo,
                            style: const TextStyle(color: kWhite, fontSize: 14, fontStyle: FontStyle.italic, height: 1.8)),
                      ),
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: kCyan.withOpacity(0.5)),
                          color: kCyan.withOpacity(0.08),
                        ),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          Icon(Icons.receipt_long_rounded, color: kCyan, size: 14),
                          const SizedBox(width: 6),
                          Text('${source.isNotEmpty ? source : "Muslim"} #$number',
                              style: TextStyle(color: kCyan, fontSize: 12, fontWeight: FontWeight.bold)),
                        ]),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('username');
    await prefs.remove('password');
    await prefs.remove('key');
    await FangThemeController.instance.switchAccount('guest');
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text('⚠️ Session Expired', style: TextStyle(color: kWhite)),
        content: Text(message, style: const TextStyle(color: kWhite54)),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false),
            child: Text('OK', style: TextStyle(color: kCyan)),
          ),
        ],
      ),
    );
  }

  // ── Navigation ────────────────────────────────────────────────────────────
  void _onNavTap(int index) {
    setState(() => _navIndex = index);
    if (index == 0) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_newsPageCtrl.hasClients) {
          setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
          _newsPageCtrl.jumpToPage(0);
        }
      });
    }
  }

  void _onDrawerNav(int index) {
    Widget page;
    switch (index) {
      case 1: page = SellerPage(keyToken: sessionKey); break;
      case 2: page = AdminPage(sessionKey: sessionKey); break;
      case 3: page = OwnerPage(sessionKey: sessionKey, username: username); break;
      case 4: page = DeveloperPage(sessionKey: sessionKey); break;
      default: return;
    }
    Navigator.pop(context);
    Navigator.push(context, MaterialPageRoute(builder: (_) => page)).then((_) {
      if (mounted) {
        setState(() => _navIndex = 0);
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_newsPageCtrl.hasClients) {
            setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
            _newsPageCtrl.jumpToPage(0);
          }
        });
      }
    });
  }

  // ── Current Page ──────────────────────────────────────────────────────────
  Widget _buildCurrentPage() {
    switch (_navIndex) {
      case 1:
        return HomePage(
          username: username, password: password,
          listBug: listBug, role: role,
          expiredDate: expiredDate, sessionKey: sessionKey,
        );
      case 2:
        return ChatAllPage(username: username, role: role, sessionKey: sessionKey);
      case 3:
        return InfoPage(sessionKey: sessionKey);
      case 4:
        return ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: listDoos);
      case 0:
      default:
        return _buildHomePage();
    }
  }

  // ─── HOME PAGE / FANG SHADOW ────────────────────────────────────────────────
  Widget _buildHomePage() {
    return Stack(
      children: [
        FadeTransition(
          opacity: _fadeAnim,
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(18, 16, 18, 126),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildV14OwnerCard(),
                const SizedBox(height: 14),
                _buildV14SectionHeader(
                  icon: Icons.newspaper_rounded,
                  title: 'BERITA TERBARU',
                  trailing: '${newsList.isEmpty ? 1 : newsList.length} ARTIKEL',
                ),
                const SizedBox(height: 12),
                _buildV14NewsCard(),
                const SizedBox(height: 16),
                _buildPrayerSection(),
                const SizedBox(height: 22),
                _buildV14JoinChannel(),
                const SizedBox(height: 24),
                _buildV14SectionHeader(
                  icon: Icons.bolt_rounded,
                  title: 'QUICK ACTIONS',
                  trailing: 'NEW FEATURES',
                ),
                const SizedBox(height: 12),
                _buildV14QuickAction(
                  icon: Icons.public_rounded,
                  title: 'GLOBAL CHAT',
                  subtitle: 'Chat With All User',
                  onTap: () => setState(() => _navIndex = 2),
                ),
                const SizedBox(height: 12),
                _buildV14QuickAction(
                  icon: Icons.smart_toy_rounded,
                  title: 'AI ASSISTANT',
                  subtitle: 'Chat with AI',
                  onTap: () => Navigator.push(
                    context,
                    _slideRoute(AIChatPage(username: username, sessionKey: sessionKey)),
                  ),
                ),
                const SizedBox(height: 12),
                _buildVinylMusicButton(),
                const SizedBox(height: 24),
              const SizedBox(height: 8),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ─── V14 SECTION HEADER ────────────────────────────────────────────────────
  Widget _buildV14SectionHeader({
    required IconData icon,
    required String title,
    required String trailing,
  }) {
    final accent = FangThemeController.instance.config.accentColor;
    final isQuick = title == 'QUICK ACTIONS';
    return Row(
      children: [
        if (!isQuick) Container(width: 5, height: 38, color: accent),
        if (isQuick)
          Container(
            width: 44,
            height: 44,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              border: Border.all(color: accent.withOpacity(.65)),
              color: accent.withOpacity(.035),
            ),
            child: Icon(icon, color: accent, size: 21),
          ),
        SizedBox(width: isQuick ? 12 : 11),
        Expanded(
          child: Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.25,
              fontFamily: 'monospace',
            ),
          ),
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              trailing,
              style: TextStyle(
                color: accent,
                fontSize: 10,
                fontWeight: FontWeight.w900,
                letterSpacing: 1,
                fontFamily: 'monospace',
              ),
            ),
            const SizedBox(height: 5),
            Container(width: 34, height: 2, color: accent),
          ],
        ),
      ],
    );
  }

  // ─── V14 OWNER CARD ─────────────────────────────────────────────────────────
  Widget _buildV14OwnerCard() {
    final fang = FangThemeController.instance.config;
    final accent = fang.accentColor;
    final displayRole = role.trim().isEmpty ? 'MEMBER' : role.toUpperCase();
    final exp = expiredDate.trim().isEmpty ? '-' : expiredDate;

    return AnimatedBuilder(
      animation: _shadowCtrl,
      builder: (context, _) {
        final shadowIntensity = (_shadowCtrl.value * 0.6 + 0.4);
        final floatOffset = math.sin(_floatCtrl.value * 2 * math.pi) * 4;

        return Transform.translate(
          offset: Offset(0, floatOffset),
          child: Container(
            decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  color: accent.withOpacity(0.15 * shadowIntensity),
                  blurRadius: 30 * shadowIntensity,
                  spreadRadius: 5 * shadowIntensity,
                ),
                BoxShadow(
                  color: accent.withOpacity(0.08),
                  blurRadius: 60,
                  spreadRadius: 20,
                ),
                BoxShadow(
                  color: Colors.black.withOpacity(0.4 + 0.2 * shadowIntensity),
                  blurRadius: 40,
                  offset: Offset(0, 10 + 5 * shadowIntensity),
                ),
              ],
            ),
            child: _fangCyberPanel(
              accent: accent,
              cut: 13,
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 17),
              child: Column(
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(
                            colors: [
                              accent.withOpacity(0.3),
                              accent.withOpacity(0.1),
                              Colors.transparent,
                            ],
                            radius: 1.2,
                          ),
                        ),
                        child: Container(
                          width: 78,
                          height: 72,
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: const Color(0xFF08060D),
                            border: Border.all(color: accent, width: 1.7),
                            boxShadow: [
                              BoxShadow(
                                color: accent.withOpacity(0.48 * shadowIntensity),
                                blurRadius: 18,
                              ),
                              BoxShadow(
                                color: accent.withOpacity(0.20 * shadowIntensity),
                                blurRadius: 34,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                          child: ClipOval(
                            child: _profileImage != null
                                ? Image.file(_profileImage!, fit: BoxFit.cover)
                                : Image.asset(
                                    username.trim().toLowerCase() == 'bomz'
                                        ? 'assets/images/bomzz_profile.jpg'
                                        : 'assets/images/logo.jpg',
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => Icon(
                                      Icons.shield_moon_rounded,
                                      color: accent,
                                      size: 40,
                                    ),
                                  ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 17),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ShaderMask(
                              shaderCallback: (rect) {
                                final width = rect.width;
                                final progress = _bounceCtrl.value;
                                final position = width * progress;
                                final shimmerWidth = width * 0.3;
                                return LinearGradient(
                                  begin: Alignment(-1.0 + progress * 2.0, 0),
                                  end: Alignment(1.0 + progress * 2.0, 0),
                                  colors: [
                                    Colors.transparent,
                                    accent.withOpacity(0.6),
                                    Colors.transparent,
                                  ],
                                  stops: [
                                    (position - shimmerWidth) / width,
                                    position / width,
                                    (position + shimmerWidth) / width,
                                  ],
                                ).createShader(rect);
                              },
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    'AKUN',
                                    style: TextStyle(
                                      color: accent.withOpacity(0.72),
                                      fontSize: 9,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 1.8,
                                      fontFamily: 'monospace',
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    username,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 21,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: .6,
                                      fontFamily: 'monospace',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                Flexible(
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
                                    decoration: BoxDecoration(
                                      color: accent.withOpacity(.11),
                                      border: Border.all(color: accent, width: 1.2),
                                      boxShadow: [
                                        BoxShadow(
                                          color: accent.withOpacity(0.24 * shadowIntensity),
                                          blurRadius: 12,
                                        ),
                                      ],
                                    ),
                                    child: Text(
                                      '● $displayRole',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        color: accent,
                                        fontSize: 10.5,
                                        fontWeight: FontWeight.w900,
                                        letterSpacing: .8,
                                        fontFamily: 'monospace',
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Text(
                                    '·  EXP: $exp',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 10.5,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: .65,
                                      fontFamily: 'monospace',
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  Row(
                    children: [
                      Expanded(
                        child: _buildV14Stat(
                          icon: Icons.groups_2_rounded,
                          value: '$onlineUsers',
                          label: 'ONLINE',
                        ),
                      ),
                      Expanded(
                        child: _buildV14Stat(
                          icon: Icons.wifi_rounded,
                          value: '$activeConns',
                          label: 'KONEKSI',
                        ),
                      ),
                      Expanded(
                        child: Container(
                          height: 62,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: const Color(0xFF07050A),
                            border: Border.all(color: accent.withOpacity(.72), width: 1.1),
                            boxShadow: [
                              BoxShadow(
                                color: accent.withOpacity(0.10 * shadowIntensity),
                                blurRadius: 14,
                              ),
                              BoxShadow(
                                color: Colors.green.withOpacity(0.15 * shadowIntensity),
                                blurRadius: 20,
                              ),
                            ],
                          ),
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.circle, color: Color(0xFF54FF54), size: 10),
                              SizedBox(width: 8),
                              Text(
                                'ONLINE',
                                style: TextStyle(
                                  color: Color(0xFF54FF54),
                                  fontSize: 12,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 1,
                                  fontFamily: 'monospace',
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ─── FANG CYBER PANEL ──────────────────────────────────────────────────────
  Widget _fangCyberPanel({
    required Widget child,
    required Color accent,
    EdgeInsetsGeometry padding = EdgeInsets.zero,
    double cut = 12,
    Color background = const Color(0xF507050A),
  }) {
    return ClipPath(
      clipper: _FangCyberClipper(cut: cut),
      child: CustomPaint(
        foregroundPainter: _FangCyberBorderPainter(
          color: accent.withOpacity(.76),
          cut: cut,
        ),
        child: Container(
          width: double.infinity,
          padding: padding,
          color: background,
          child: child,
        ),
      ),
    );
  }

  // ─── V14 STAT ──────────────────────────────────────────────────────────────
  Widget _buildV14Stat({
    required IconData icon,
    required String value,
    required String label,
  }) {
    final accent = FangThemeController.instance.config.accentColor;
    return AnimatedBuilder(
      animation: _shadowCtrl,
      builder: (context, _) {
        final shadowIntensity = (_shadowCtrl.value * 0.6 + 0.4);
        return Container(
          height: 58,
          decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
                color: accent.withOpacity(0.08 * shadowIntensity),
                blurRadius: 15 * shadowIntensity,
                spreadRadius: 2 * shadowIntensity,
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: accent.withOpacity(0.15 * shadowIntensity),
                      blurRadius: 12,
                    ),
                  ],
                ),
                child: Icon(icon, color: accent, size: 21),
              ),
              const SizedBox(width: 8),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  AnimatedBuilder(
                    animation: _bounceCtrl,
                    builder: (context, child) {
                      final bounceValue = _bounceCtrl.value;
                      final offset = -12.0 * (1 - bounceValue) * (1 - bounceValue) * 2;
                      final scale = 0.5 + 0.5 * (1 - (1 - bounceValue) * (1 - bounceValue) * 2).clamp(0, 1);
                      return Transform.translate(
                        offset: Offset(0, offset),
                        child: Transform.scale(
                          scale: scale,
                          child: child,
                        ),
                      );
                    },
                    child: Text(
                      value,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        height: 1,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'monospace',
                      ),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    label,
                    style: TextStyle(
                      color: Colors.white.withOpacity(.58),
                      fontSize: 9,
                      letterSpacing: 1.25,
                      fontWeight: FontWeight.w800,
                      fontFamily: 'monospace',
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildVinylMusicButton() {
    final accent = FangThemeController.instance.config.accentColor;
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: () => Navigator.push(context, _slideRoute(SpotifyPage())),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(16), border: Border.all(color: accent.withOpacity(.45))),
        child: Row(children: [
          Container(width: 46, height: 46, decoration: BoxDecoration(shape: BoxShape.circle, color: accent.withOpacity(.12), border: Border.all(color: accent.withOpacity(.6))), child: Icon(Icons.album_rounded, color: accent, size: 25)),
          const SizedBox(width: 12),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('FANG MUSIC', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: 1.0)),
            SizedBox(height: 3), Text('Buka musik & playlist', style: TextStyle(color: Colors.white54, fontSize: 11)),
          ])),
          Icon(Icons.arrow_forward_ios_rounded, color: accent, size: 16),
        ]),
      ),
    );
  }

  Widget _buildV14NewsCard() {
    final accent = FangThemeController.instance.config.accentColor;
    String title = 'FANG SHADOW';
    String subtitle = 'Project By Fang Shadow Team';
    if (newsList.isNotEmpty && newsList.first is Map) {
      final item = Map<String, dynamic>.from(newsList.first as Map);
      final candidateTitle = (item['title'] ?? item['judul'] ?? '').toString().trim();
      final candidateSubtitle =
          (item['subtitle'] ?? item['description'] ?? item['desc'] ?? '').toString().trim();
      if (candidateTitle.isNotEmpty) title = candidateTitle;
      if (candidateSubtitle.isNotEmpty) subtitle = candidateSubtitle;
    }

    return AnimatedBuilder(
      animation: _shadowCtrl,
      builder: (context, _) {
        final shadowIntensity = (_shadowCtrl.value * 0.6 + 0.4);
        return Container(
          decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
                color: accent.withOpacity(0.12 * shadowIntensity),
                blurRadius: 30 * shadowIntensity,
                spreadRadius: 5 * shadowIntensity,
              ),
              BoxShadow(
                color: Colors.black.withOpacity(0.3 * shadowIntensity),
                blurRadius: 30,
                offset: Offset(0, 8 * shadowIntensity),
              ),
            ],
          ),
          child: ClipPath(
            clipper: const _FangCyberClipper(cut: 13),
            child: CustomPaint(
              foregroundPainter: _FangCyberBorderPainter(
                color: accent.withOpacity(.78),
                cut: 13,
              ),
              child: SizedBox(
                height: 252,
                width: double.infinity,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.asset(
                      'assets/images/fang_shadow_hero.jpg',
                      fit: BoxFit.cover,
                      alignment: Alignment.center,
                    ),
                    DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.black.withOpacity(.02),
                            Colors.transparent,
                            Colors.black.withOpacity(.82),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      top: 17,
                      left: 17,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                        color: accent.withOpacity(.70),
                        child: const Text(
                          'NEWS',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1,
                            fontFamily: 'monospace',
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 18,
                      right: 18,
                      bottom: 18,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            title.toUpperCase(),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 19,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1,
                              fontFamily: 'monospace',
                            ),
                          ),
                          const SizedBox(height: 5),
                          Text(
                            subtitle,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: Colors.white.withOpacity(.78),
                              fontSize: 11,
                              letterSpacing: .45,
                              fontFamily: 'monospace',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  // ─── V14 JOIN CHANNEL ──────────────────────────────────────────────────────
  Widget _buildV14JoinChannel() {
    final accent = FangThemeController.instance.config.accentColor;
    return AnimatedBuilder(
      animation: _shadowCtrl,
      builder: (context, _) {
        final shadowIntensity = (_shadowCtrl.value * 0.6 + 0.4);
        return InkWell(
          onTap: () => _openUrl('https://t.me/MDRXBOMZ994'),
          child: Container(
            decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  color: accent.withOpacity(0.08 * shadowIntensity),
                  blurRadius: 20 * shadowIntensity,
                  spreadRadius: 3 * shadowIntensity,
                ),
              ],
            ),
            child: _fangCyberPanel(
              accent: accent,
              cut: 11,
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
              child: Row(
                children: [
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      border: Border.all(color: accent.withOpacity(.9), width: 1.1),
                      color: accent.withOpacity(.055),
                    ),
                    child: Icon(FontAwesomeIcons.telegram, color: accent, size: 22),
                  ),
                  const SizedBox(width: 17),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'JOIN CHANNEL',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 15.5,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1,
                            fontFamily: 'monospace',
                          ),
                        ),
                        SizedBox(height: 5),
                        Text(
                          'FANG SHADOW',
                          style: TextStyle(
                            color: Color(0xFF9D43FF),
                            fontSize: 11,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.1,
                            fontFamily: 'monospace',
                          ),
                        ),
                      ],
                    ),
                  ),
                  Icon(Icons.arrow_forward_ios_rounded, color: accent, size: 20),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ─── V14 QUICK ACTION ──────────────────────────────────────────────────────
  Widget _buildV14QuickAction({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    final accent = FangThemeController.instance.config.accentColor;
    return AnimatedBuilder(
      animation: _shadowCtrl,
      builder: (context, _) {
        final shadowIntensity = (_shadowCtrl.value * 0.6 + 0.4);
        final wobbleValue = _wobbleCtrl.value;
        final rotation = math.sin(wobbleValue * math.pi * 3) * 0.02 * (1 - wobbleValue);
        final scale = 1 + 0.01 * wobbleValue;

        return MouseRegion(
          onEnter: (_) => _wobbleCtrl.forward(),
          onExit: (_) => _wobbleCtrl.reverse(),
          child: Transform.rotate(
            angle: rotation,
            child: Transform.scale(
              scale: scale,
              child: InkWell(
                onTap: onTap,
                child: Container(
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: accent.withOpacity(0.12 * shadowIntensity),
                        blurRadius: 25 * shadowIntensity,
                        spreadRadius: 3 * shadowIntensity,
                      ),
                      BoxShadow(
                        color: Colors.black.withOpacity(0.3 * shadowIntensity),
                        blurRadius: 30,
                        offset: Offset(0, 8 * shadowIntensity),
                      ),
                    ],
                  ),
                  child: _fangCyberPanel(
                    accent: accent,
                    cut: 13,
                    padding: const EdgeInsets.symmetric(horizontal: 18),
                    child: SizedBox(
                      height: 136,
                      child: Row(
                        children: [
                          Container(
                            width: 72,
                            height: 72,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: const Color(0xFF0B0710),
                              border: Border.all(color: accent, width: 1.5),
                              boxShadow: [
                                BoxShadow(
                                  color: accent.withOpacity(0.45 * shadowIntensity),
                                  blurRadius: 18,
                                ),
                                BoxShadow(
                                  color: accent.withOpacity(0.16 * shadowIntensity),
                                  blurRadius: 32,
                                  spreadRadius: 3 * shadowIntensity,
                                ),
                              ],
                            ),
                            child: Icon(icon, color: accent, size: 30),
                          ),
                          const SizedBox(width: 20),
                          Expanded(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  title,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 18,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1,
                                    fontFamily: 'monospace',
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  subtitle,
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(.56),
                                    fontSize: 11,
                                    fontFamily: 'monospace',
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            width: 49,
                            height: 49,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: accent.withOpacity(.16),
                              boxShadow: [
                                BoxShadow(
                                  color: accent.withOpacity(0.42 * shadowIntensity),
                                  blurRadius: 19,
                                ),
                              ],
                            ),
                            child: const Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 27),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildV14MiniAction({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    final accent = FangThemeController.instance.config.accentColor;
    return InkWell(
      onTap: onTap,
      child: Container(
        height: 96,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: accent.withOpacity(.07),
          border: Border.all(color: accent.withOpacity(.45)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: accent, size: 22),
            const Spacer(),
            Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: 12,
                letterSpacing: .8,
              ),
            ),
            Text(
              subtitle,
              style: TextStyle(
                color: accent.withOpacity(.9),
                fontSize: 9,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── FANG SHADOW HERO ──────────────────────────────────────────────────────
  Widget _buildBannerVideo() {
    final fang = FangThemeController.instance.config;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        height: 300,
        width: double.infinity,
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          border: Border.all(
            color: fang.accentColor.withOpacity(0.72),
            width: 1.4,
          ),
          boxShadow: [
            fang.glow(multiplier: 1.0, spreadRadius: -6),
            BoxShadow(
              color: Colors.black.withOpacity(0.56),
              blurRadius: 26,
              offset: const Offset(0, 12),
            ),
          ],
        ),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(
              'assets/images/fang_shadow_hero.jpg',
              fit: BoxFit.cover,
              alignment: Alignment.center,
            ),
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.10),
                    Colors.transparent,
                    Colors.black.withOpacity(0.48),
                  ],
                ),
              ),
            ),
            Positioned(
              left: 16,
              top: 16,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
                decoration: BoxDecoration(
                  color: const Color(0xCC080610),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: fang.accentColor.withOpacity(0.42)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'FANG',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        height: 1,
                        fontWeight: FontWeight.w900,
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'SHADOW',
                      style: TextStyle(
                        color: fang.accentColor,
                        fontSize: 9,
                        letterSpacing: 2.1,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              right: 16,
              top: 16,
              child: Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xD10A0712),
                  border: Border.all(color: fang.accentColor.withOpacity(0.62)),
                  boxShadow: [fang.glow(multiplier: .55, spreadRadius: -5)],
                ),
                child: Icon(
                  Icons.change_history_rounded,
                  color: fang.accentColor,
                  size: 27,
                ),
              ),
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 12,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 7,
                    height: 7,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white38,
                    ),
                  ),
                  const SizedBox(width: 7),
                  Container(
                    width: 42,
                    height: 5,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      color: fang.accentColor,
                      boxShadow: [fang.glow(multiplier: .45, spreadRadius: -6)],
                    ),
                  ),
                  const SizedBox(width: 7),
                  Container(
                    width: 7,
                    height: 7,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white24,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFangStats() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Row(
        children: [
          Expanded(
            child: _buildFangStatCard(
              label: 'STATUS',
              icon: Icons.shield_rounded,
              value: '100%',
              footer: 'SYSTEM OK',
              progress: 1.0,
            ),
          ),
          const SizedBox(width: 9),
          Expanded(
            child: _buildFangStatCard(
              label: 'SERVER',
              icon: Icons.language_rounded,
              value: activeConns > 0 ? 'ONLINE' : 'READY',
              footer: '$activeConns ACTIVE',
              progress: activeConns > 0 ? .86 : .28,
            ),
          ),
          const SizedBox(width: 9),
          Expanded(
            child: _buildFangStatCard(
              label: 'MEMBER',
              icon: Icons.groups_2_rounded,
              value: '$onlineUsers',
              footer: 'ONLINE NOW',
              progress: onlineUsers <= 0 ? .18 : math.min(.95, .30 + onlineUsers / 100).toDouble(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFangStatCard({
    required String label,
    required IconData icon,
    required String value,
    required String footer,
    required double progress,
  }) {
    final fang = FangThemeController.instance.config;
    final accent = fang.accentColor;
    return Container(
      height: 154,
      padding: const EdgeInsets.fromLTRB(10, 12, 10, 10),
      decoration: BoxDecoration(
        color: fang.surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: accent.withOpacity(.43)),
        boxShadow: [
          fang.glow(multiplier: .55, spreadRadius: -7),
          BoxShadow(color: Colors.black.withOpacity(.36), blurRadius: 15, offset: const Offset(0, 7)),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: accent, size: 15),
              const SizedBox(width: 5),
              Flexible(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: accent,
                    fontSize: 9,
                    letterSpacing: .8,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
          const Spacer(),
          SizedBox(
            width: 66,
            height: 66,
            child: Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 64,
                  height: 64,
                  child: CircularProgressIndicator(
                    value: progress.clamp(0.0, 1.0).toDouble(),
                    strokeWidth: 5,
                    backgroundColor: accent.withOpacity(.10),
                    valueColor: AlwaysStoppedAnimation(accent),
                    strokeCap: StrokeCap.round,
                  ),
                ),
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: accent.withOpacity(.075),
                    border: Border.all(color: Colors.white.withOpacity(.08)),
                  ),
                  child: Icon(icon, color: Colors.white.withOpacity(.88), size: 22),
                ),
              ],
            ),
          ),
          const Spacer(),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: Colors.white,
              fontSize: value.length > 6 ? 10 : 16,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            footer,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: footer.contains('OK') ? kGreen : accent.withOpacity(.88),
              fontSize: 6.8,
              fontWeight: FontWeight.w800,
              letterSpacing: .55,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFangAccountTiles() {
    final fang = FangThemeController.instance.config;
    final shortExpired = expiredDate.length > 10 ? expiredDate.substring(0, 10) : expiredDate;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          color: fang.surface,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: fang.accentColor.withOpacity(.34)),
          boxShadow: [fang.glow(multiplier: .45, spreadRadius: -8)],
        ),
        child: Column(
          children: [
            _buildFangAccountTile(
              icon: Icons.person_rounded,
              title: username.toUpperCase(),
              subtitle: 'ACCOUNT  //  ${role.toUpperCase()}',
              trailing: 'ACTIVE',
              onTap: () => Navigator.push(
                context,
                _slideRoute(ProfilePage(
                  username: username,
                  password: password,
                  role: role,
                  expiredDate: expiredDate,
                  sessionKey: sessionKey,
                )),
              ),
            ),
            Divider(height: 1, color: fang.accentColor.withOpacity(.18), indent: 16, endIndent: 16),
            _buildFangAccountTile(
              icon: Icons.workspace_premium_rounded,
              title: 'SESSION ACCESS',
              subtitle: 'EXPIRATION DATE',
              trailing: shortExpired,
              onTap: () => Navigator.push(
                context,
                _slideRoute(ProfilePage(
                  username: username,
                  password: password,
                  role: role,
                  expiredDate: expiredDate,
                  sessionKey: sessionKey,
                )),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFangAccountTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required String trailing,
    required VoidCallback onTap,
  }) {
    final fang = FangThemeController.instance.config;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        splashColor: fang.accentColor.withOpacity(.10),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(13, 12, 12, 12),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: fang.accentSoft,
                  border: Border.all(color: fang.accentColor.withOpacity(.46)),
                  boxShadow: [fang.glow(multiplier: .38, spreadRadius: -8)],
                ),
                child: Icon(icon, color: fang.accentColor, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        letterSpacing: .55,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      subtitle,
                      style: const TextStyle(color: Colors.white54, fontSize: 8.5, letterSpacing: .55),
                    ),
                  ],
                ),
              ),
              Text(
                trailing,
                style: TextStyle(
                  color: fang.accentColor,
                  fontSize: trailing.length > 8 ? 8.5 : 10,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(width: 3),
              Icon(Icons.chevron_right_rounded, color: Colors.white38, size: 22),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFangFeaturePanels() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Row(
        children: [
          Expanded(
            child: _buildFangFeatureCard(
              icon: FontAwesomeIcons.whatsapp,
              title: 'MANAGE',
              subtitle: 'SENDER',
              onTap: () => Navigator.push(
                context,
                _slideRoute(BugSenderPage(
                  sessionKey: sessionKey,
                  username: username,
                  role: role,
                )),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: _buildFangFeatureCard(
              icon: Icons.build_rounded,
              title: 'OPEN',
              subtitle: 'TOOLS',
              onTap: () => _onNavTap(4),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFangFeatureCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    final fang = FangThemeController.instance.config;
    final accent = fang.accentColor;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(23),
        child: Ink(
          height: 140,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(23),
            gradient: LinearGradient(
              colors: [accent.withOpacity(.18), fang.surface],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            border: Border.all(color: accent.withOpacity(.52)),
            boxShadow: [fang.glow(multiplier: .55, spreadRadius: -7)],
          ),
          child: Stack(
            children: [
              Positioned(
                right: -8,
                bottom: -13,
                child: Icon(icon, color: accent.withOpacity(.055), size: 102),
              ),
              Padding(
                padding: const EdgeInsets.all(15),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: accent.withOpacity(.10),
                        border: Border.all(color: accent.withOpacity(.48)),
                        boxShadow: [fang.glow(multiplier: .4, spreadRadius: -8)],
                      ),
                      child: Icon(icon, color: accent, size: 22),
                    ),
                    const Spacer(),
                    Text(
                      title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontWeight: FontWeight.w900,
                        height: 1,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Row(
                      children: [
                        Text(
                          subtitle,
                          style: TextStyle(
                            color: accent,
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1.2,
                          ),
                        ),
                        const Spacer(),
                        Icon(Icons.arrow_forward_rounded, color: accent, size: 17),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Welcome Card ──────────────────────────────────────────────────────────
  Widget _buildWelcomeCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kBorder.withOpacity(0.6)),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 24, offset: const Offset(0, 10))
          ],
        ),
        child: Stack(
          children: [
            Positioned.fill(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: CustomPaint(painter: _HexagonPatternPainter()),
              ),
            ),
            Column(
              children: [
                Row(
                  children: [
                    ScaleTransition(
                      scale: _pulseAnim,
                      child: Container(
                        width: 58, height: 58,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(colors: [Colors.red, Colors.redAccent]),
                          boxShadow: [BoxShadow(color: Colors.red.withOpacity(0.5), blurRadius: 16, spreadRadius: 2)],
                        ),
                        child: Center(child: Icon(Icons.security_rounded, color: kWhite, size: 28)),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Welcome Back,',
                              style: TextStyle(color: kWhite54, fontSize: 12)),
                          Text(username,
                              style: const TextStyle(
                                color: kWhite, fontSize: 18, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 4),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: kCyan.withOpacity(0.5)),
                              color: kCyan.withOpacity(0.08),
                            ),
                            child: Text(role.toUpperCase(),
                                style: TextStyle(
                                  color: kCyan, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: 40, height: 40,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: kGreen.withOpacity(0.12),
                        border: Border.all(color: kGreen.withOpacity(0.3)),
                      ),
                      child: Icon(Icons.timer_outlined, color: kGreen, size: 20),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(color: kCyan.withOpacity(0.4)),
                    color: kCyan.withOpacity(0.04),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(width: 10),
                      Text('FANG SHADOW DASHBOARD',
                          style: TextStyle(
                            color: kCyan, fontSize: 11, fontWeight: FontWeight.bold,
                            letterSpacing: 1.5)),
                      const SizedBox(width: 10),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    _buildCircleStatItem(
                        icon: Icons.people_alt_rounded,
                        value: '$onlineUsers',
                        label: 'Online Users',
                        color: kGreen),
                    _buildStatDivider(),
                    _buildCircleStatItem(
                        icon: Icons.link_rounded,
                        value: '$activeConns',
                        label: 'Active Connections',
                        color: kBlue),
                    _buildStatDivider(),
                    _buildCircleStatItem(
                        icon: Icons.calendar_month_rounded,
                        value: expiredDate.length > 10 ? expiredDate.substring(0, 10) : expiredDate,
                        label: 'Expiration',
                        color: kOrange),
                  ],
                ),
                const SizedBox(height: 12),
                Align(
                  alignment: Alignment.centerLeft,
                  child: ScaleTransition(
                    scale: _pulseAnim,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: kGreen.withOpacity(0.5)),
                        color: kGreen.withOpacity(0.08),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const SizedBox(width: 6),
                          Text('LIVE',
                              style: TextStyle(
                                  color: kGreen, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1)),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCircleStatItem({
    required IconData icon,
    required String value,
    required String label,
    required Color color,
  }) {
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 62, height: 62,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withOpacity(0.18),
              border: Border.all(color: color.withOpacity(0.6), width: 2),
              boxShadow: [BoxShadow(color: color.withOpacity(0.4), blurRadius: 14, spreadRadius: 2)],
            ),
            child: Center(child: Icon(icon, color: color, size: 28)),
          ),
          const SizedBox(height: 8),
          Text(value,
              style: const TextStyle(
                  color: kWhite, fontWeight: FontWeight.bold, fontSize: 13)),
          const SizedBox(height: 2),
          Text(label, style: const TextStyle(color: kWhite54, fontSize: 9), textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _buildStatDivider() =>
      Container(width: 1, height: 60, color: kBorder.withOpacity(0.5));

  // ── Quick Actions ─────────────────────────────────────────────────────────
  Widget _buildQuickActionsSection() {
    final actions = [
      _QuickActionData(
        icon: FontAwesomeIcons.whatsapp,
        bgIcon: FontAwesomeIcons.whatsapp,
        title: 'Manage Sender',
        subtitle: 'Manage your active sender',
        gradient: [const Color(0xFFE91E8C), const Color(0xFFAD1457)],
        onTap: () => Navigator.push(
          context,
          _slideRoute(BugSenderPage(sessionKey: sessionKey, username: username, role: role)),
        ).then((_) {
          if (mounted && _newsPageCtrl.hasClients) {
            setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
            _newsPageCtrl.jumpToPage(0);
          }
        }),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.telegram,
        bgIcon: FontAwesomeIcons.telegram,
        title: 'Join Channel',
        subtitle: 'Astral Info Channel',
        gradient: [const Color(0xFF00B4D8), const Color(0xFF0077B6)],
        onTap: () => _openUrl('https://t.me/MDRXBOMZ994'),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.bookQuran,
        bgIcon: FontAwesomeIcons.bookQuran,
        title: 'Al Quran',
        subtitle: 'Baca Al-Quran',
        gradient: [const Color(0xFF7C4DFF), const Color(0xFF4A148C)],
        onTap: () => Navigator.push(context, _slideRoute(AlQuranPage())),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.tv,
        bgIcon: FontAwesomeIcons.tv,
        title: 'Anime',
        subtitle: 'Discover & Watch Anime',
        gradient: [const Color(0xFFFF6D00), const Color(0xFFE65100)],
        onTap: () => Navigator.push(context, _slideRoute(HomeAnimePage())),
      ),
      _QuickActionData(
        icon: Icons.smart_toy_rounded,
        bgIcon: Icons.smart_toy_rounded,
        title: 'AI Assistant',
        subtitle: 'Chat dengan AI',
        gradient: [const Color(0xFF6C63FF), const Color(0xFF3F3D9E)],
        onTap: () => Navigator.push(
          context,
          _slideRoute(AIChatPage(username: username, sessionKey: sessionKey)),
        ),
      ),
    ];

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            children: [
              Container(
                width: 44, height: 44,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: kYellow.withOpacity(0.18),
                  border: Border.all(color: kYellow.withOpacity(0.3)),
                ),
                child: Icon(Icons.bolt_rounded, color: kYellow, size: 22),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('QUICK ACTIONS',
                      style: TextStyle(
                        color: kWhite, fontWeight: FontWeight.bold, fontSize: 15,
                        letterSpacing: 1)),
                  Text('Beberapa Menu Tambahan',
                      style: TextStyle(color: kWhite54, fontSize: 12)),
                ],
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: kYellow.withOpacity(0.15),
                  border: Border.all(color: kYellow.withOpacity(0.4)),
                ),
                child: Row(children: [
                  Container(
                      width: 7, height: 7,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: kYellow)),
                  const SizedBox(width: 5),
                  Text('ASTRAL',
                      style: TextStyle(color: kYellow, fontSize: 11, fontWeight: FontWeight.bold)),
                ]),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 180,
          child: PageView.builder(
            controller: _qaPageCtrl,
            itemCount: actions.length,
            onPageChanged: (index) {
              if (mounted) setState(() => _currentQaPage = index.toDouble());
            },
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: _buildQuickActionCard(actions[index]),
              );
            },
          ),
        ),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(actions.length, (index) {
            final bool isActive = _currentQaPage.round() == index;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              width: isActive ? 24 : 8,
              height: 8,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                color: isActive ? kYellow : Colors.white24,
              ),
            );
          }),
        ),
      ],
    );
  }

  Widget _buildQuickActionCard(_QuickActionData action) {
    return GestureDetector(
      onTap: action.onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(
              colors: action.gradient,
              begin: Alignment.topLeft,
              end: Alignment.bottomRight),
          boxShadow: [
            BoxShadow(
                color: action.gradient.first.withOpacity(0.4),
                blurRadius: 20, offset: const Offset(0, 8))
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              right: -12, bottom: -12,
              child: Icon(action.bgIcon, color: Colors.white.withOpacity(0.08), size: 110),
            ),
            Padding(
              padding: const EdgeInsets.all(22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 50, height: 50,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle, color: Colors.white.withOpacity(0.22)),
                    child: Icon(action.icon, color: kWhite, size: 24),
                  ),
                  const Spacer(),
                  Align(
                    alignment: Alignment.topRight,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: Colors.white.withOpacity(0.22)),
                      child: Text('Tap →',
                          style: TextStyle(color: kWhite, fontSize: 11, fontWeight: FontWeight.bold)),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(action.title,
                      style: const TextStyle(
                        color: kWhite, fontWeight: FontWeight.bold, fontSize: 17)),
                  const SizedBox(height: 4),
                  Text(action.subtitle,
                      style: TextStyle(color: kWhite.withOpacity(0.8), fontSize: 12)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Latest Updates ────────────────────────────────────────────────────────
  Widget _buildLatestUpdates() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            children: [
              Icon(Icons.dashboard_customize_rounded, color: kOrange, size: 22),
              const SizedBox(width: 8),
              Text('LATEST UPDATES',
                  style: TextStyle(
                    color: kWhite, fontWeight: FontWeight.bold, fontSize: 15,
                    letterSpacing: 1)),
              const Spacer(),
              if (newsList.isNotEmpty)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: kOrange.withOpacity(0.15),
                    border: Border.all(color: kOrange.withOpacity(0.4)),
                  ),
                  child: Text('${newsList.length} Updates',
                      style: const TextStyle(
                          color: kOrange, fontSize: 11, fontWeight: FontWeight.bold)),
                ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        if (newsList.isNotEmpty)
          SizedBox(
            height: 200,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 14),
              itemCount: newsList.length,
              itemBuilder: (ctx, i) => _buildNewsCardHorizontal(newsList[i]),
            ),
          ),
        if (newsList.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Container(
              height: 120,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: kCard,
                  border: Border.all(color: kBorder.withOpacity(0.4))),
              child: Center(
                  child: Text('No updates available', style: TextStyle(color: kWhite54))),
            ),
          ),
      ],
    );
  }

  Widget _buildNewsCardHorizontal(dynamic item) {
    final imgUrl   = item['image']?.toString() ?? '';
    final title    = item['title']?.toString() ?? 'No Title';
    final date     = item['date']?.toString() ?? item['created_at']?.toString() ?? '';
    final cardWidth = (MediaQuery.of(context).size.width / 2) - 22;

    return Container(
      width: cardWidth,
      margin: const EdgeInsets.only(right: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: kCard,
        border: Border.all(color: kBorder.withOpacity(0.4)),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 12, offset: const Offset(0, 6))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
            child: Stack(
              children: [
                Container(
                  height: 110, width: double.infinity, color: kCardAlt,
                  child: imgUrl.isNotEmpty
                      ? Image.network(imgUrl, fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Center(
                              child: Icon(Icons.image_not_supported_rounded, color: kWhite54, size: 30)))
                      : Center(
                          child: Icon(Icons.article_rounded, color: kWhite54, size: 30)),
                ),
                Positioned(
                  top: 8, right: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.black.withOpacity(0.65),
                      border: Border.all(color: kOrange.withOpacity(0.7)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.circle_notifications_rounded, color: kOrange, size: 10),
                        SizedBox(width: 3),
                        Text('NEW',
                            style: TextStyle(
                                color: kOrange, fontSize: 9, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 6),
            child: Text(title,
                style: const TextStyle(
                  color: kWhite, fontSize: 16, fontWeight: FontWeight.bold,
                  height: 1.3),
                maxLines: 2, overflow: TextOverflow.ellipsis),
          ),
          const Spacer(),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
            child: Row(
              children: [
                Icon(Icons.access_time_rounded, color: kWhite54, size: 11),
                const SizedBox(width: 4),
                if (date.isNotEmpty)
                  Expanded(
                    child: Text(
                        date.length > 10 ? date.substring(0, 10) : date,
                        style: const TextStyle(color: kWhite54, fontSize: 10)),
                  ),
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: kOrange.withOpacity(0.18)),
                  child: Icon(Icons.arrow_forward_ios_rounded, color: kOrange, size: 9),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Prayer Section ────────────────────────────────────────────────────────
  Widget _buildPrayerSection() {
    final prayerColors = [
      const Color(0xFF5B4FD4),
      const Color(0xFFFF9800),
      const Color(0xFFFF5722),
      const Color(0xFF1E88E5),
      const Color(0xFF1565C0),
    ];
    final prayerIcons = [
      Icons.nights_stay_rounded,
      Icons.wb_sunny_rounded,
      Icons.cloud_rounded,
      Icons.wb_twilight_rounded,
      Icons.nightlight_round,
    ];
    final prayerKeys = ['Subuh', 'Dzuhur', 'Ashar', 'Maghrib', 'Isya'];
    final subuhTime = _prayerTimes['Subuh'] ?? '--:--';

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kBorder.withOpacity(0.5)),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 18, offset: const Offset(0, 8))
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 48, height: 48,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: kGreen.withOpacity(0.2),
                    border: Border.all(color: kGreen.withOpacity(0.4)),
                  ),
                  child: Center(child: Icon(Icons.mosque, color: kGreen, size: 26)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: InkWell(
                    borderRadius: BorderRadius.circular(10),
                    onTap: _openPrayerSettings,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('JADWAL SHOLAT',
                              style: TextStyle(
                                color: kWhite, fontWeight: FontWeight.bold, fontSize: 15,
                                letterSpacing: 1)),
                          Text(_prayerCity,
                              style: const TextStyle(color: kWhite54, fontSize: 12)),
                        ],
                      ),
                    ),
                  ),
                ),
                IconButton(
                  tooltip: 'Auto Adzan',
                  visualDensity: VisualDensity.compact,
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  constraints: const BoxConstraints(minWidth: 34, minHeight: 38),
                  onPressed: _openPrayerSettings,
                  icon: Icon(Icons.alarm_on_rounded, color: kGreen, size: 20),
                ),
                GestureDetector(
                  onTap: _locationLoading ? null : _detectLocationAndFetchPrayer,
                  child: Container(
                    width: 38, height: 38,
                    margin: const EdgeInsets.only(right: 8),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _locationGranted
                          ? kGreen.withOpacity(0.2)
                          : kWhite24.withOpacity(0.1),
                      border: Border.all(
                        color: _locationGranted
                            ? kGreen.withOpacity(0.6)
                            : kWhite54.withOpacity(0.3),
                      ),
                    ),
                    child: _locationLoading
                        ? const Padding(
                            padding: EdgeInsets.all(10),
                            child: CircularProgressIndicator(color: kGreen, strokeWidth: 2),
                          )
                        : Icon(
                            _locationGranted
                                ? Icons.my_location_rounded
                                : Icons.location_searching_rounded,
                            color: _locationGranted ? kGreen : kWhite54,
                            size: 18,
                          ),
                  ),
                ),
                InkWell(
                  borderRadius: BorderRadius.circular(20),
                  onTap: _showChangeCityDialog,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: kGreen,
                    ),
                    child: Row(children: [
                      Icon(Icons.edit_location_alt_rounded, color: Colors.white, size: 14),
                      SizedBox(width: 5),
                      Text('GANTI',
                          style: TextStyle(
                              color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                    ]),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                color: const Color(0xFF120B1E),
                border: Border.all(color: kPurple.withOpacity(0.55)),
              ),
              child: Row(
                children: [
                  Container(
                    width: 44, height: 44,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(13),
                      color: kPurple.withOpacity(0.14),
                      border: Border.all(color: kPurple.withOpacity(0.5)),
                    ),
                    child: Icon(Icons.nightlight_round, color: kPurple, size: 24),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('ADZAN SUBUH', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: .7)),
                        const SizedBox(height: 3),
                        Text(_prayerLoading ? 'Memuat jadwal...' : 'Subuh hari ini  •  $subuhTime', style: TextStyle(color: kWhite54, fontSize: 11)),
                      ],
                    ),
                  ),
                  IconButton(
                    tooltip: 'Tes Adzan Subuh',
                    onPressed: _prayerLoading ? null : () => PrayerAdzanService.instance.testAdzan(subuh: true),
                    icon: Icon(Icons.play_circle_fill_rounded, color: kPurple, size: 30),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),

            if (_nextPrayerLabel.isNotEmpty)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: kGreen.withOpacity(0.5)),
                ),
                child: Row(
                  children: [
                    ScaleTransition(
                      scale: _pulseAnim,
                      child: const SizedBox(width: 10),
                    ),
                    const SizedBox(width: 10),
                    Text('Menuju $_nextPrayerLabel : $_nextPrayerTime',
                        style: const TextStyle(
                          color: kWhite, fontSize: 13, fontWeight: FontWeight.w600)),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: kGreen.withOpacity(0.5)),
                      ),
                      child: Text('ASTRAL',
                          style: TextStyle(color: kGreen, fontSize: 10, fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 14),

            if (_prayerLoading)
              Center(child: CircularProgressIndicator(color: kGreen, strokeWidth: 2))
            else
              SizedBox(
                height: 118,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  itemCount: prayerKeys.length,
                  itemBuilder: (ctx, i) {
                    final key   = prayerKeys[i];
                    final time  = _prayerTimes[key] ?? '--:--';
                    final color = prayerColors[i];
                    final icon  = prayerIcons[i];
                    final isNext = key == _nextPrayerLabel;
                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 400),
                      curve: Curves.easeOut,
                      margin: EdgeInsets.only(right: 10, bottom: isNext ? 0 : 6, top: isNext ? 0 : 6),
                      width: 105,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(18),
                        color: color,
                        boxShadow: [
                          BoxShadow(
                              color: color.withOpacity(isNext ? 0.65 : 0.3),
                              blurRadius: isNext ? 18 : 8, offset: const Offset(0, 4))
                        ],
                        border: isNext
                            ? Border.all(color: Colors.white.withOpacity(0.5), width: 1.5)
                            : null,
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(icon, color: Colors.white, size: 24),
                            const SizedBox(height: 5),
                            Text(key.toUpperCase(),
                                style: const TextStyle(
                                    color: Colors.white, fontSize: 9,
                                    fontWeight: FontWeight.bold, letterSpacing: 0.8)),
                            const SizedBox(height: 5),
                            Text(time,
                                style: const TextStyle(
                                    color: Colors.white, fontSize: 19,
                                    fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: _openPrayerSettings,
                icon: const Icon(Icons.alarm_on_rounded),
                label: const Text(
                  'ATUR JADWAL & AUTO ADZAN',
                  style: TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Hadith Section ────────────────────────────────────────────────────────
  Widget _buildHadithSection() {
    if (_hadithLoading) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Container(
          height: 200,
          decoration: BoxDecoration(
            color: kCard, borderRadius: BorderRadius.circular(20),
            border: Border.all(color: kBorder.withOpacity(0.5)),
          ),
          child: Center(child: CircularProgressIndicator(color: kCyan, strokeWidth: 2)),
        ),
      );
    }

    final arabic = _hadith?['data']?['text']?['ar'] ??
        'إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى';
    final indo   = _hadith?['data']?['text']?['id'] ??
        'Sesungguhnya setiap amalan tergantung pada niatnya.';
    final number = _hadith?['data']?['id']?.toString() ?? '1';
    final source = _hadith?['data']?['source']?.toString() ?? 'Muslim';
    final grade  = _hadith?['data']?['grade']?.toString() ?? 'Sahih Muslim';

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: kCard, borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kBorder.withOpacity(0.5)),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 18, offset: const Offset(0, 8))
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 50, height: 50,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle, color: kCyan.withOpacity(0.18)),
                  child: Center(child: Icon(Icons.menu_book_rounded, color: kCyan, size: 26)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('HADITH OF THE DAY',
                        style: TextStyle(
                          color: kWhite, fontWeight: FontWeight.bold, fontSize: 15,
                          letterSpacing: 0.5)),
                    const SizedBox(height: 2),
                    Text('$grade · Tap card to read full',
                        style: const TextStyle(color: kWhite54, fontSize: 11)),
                  ]),
                ),
              ],
            ),
            const SizedBox(height: 14),
            GestureDetector(
              onTap: () => _showHadithFullDialog(arabic, indo, source, number, grade),
              child: Column(
                children: [
                  Container(
                    width: double.infinity, padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14),
                      color: const Color(0xFF1A1F2E),
                      border: Border.all(color: kBorder.withOpacity(0.3)),
                    ),
                    child: Text(arabic,
                        textAlign: TextAlign.right, textDirection: TextDirection.rtl,
                        style: const TextStyle(color: kWhite, fontSize: 17, height: 2.0)),
                  ),
                  const SizedBox(height: 10),
                  Container(
                    width: double.infinity, padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14), color: const Color(0xFF141824)),
                    child: Text(indo,
                        style: const TextStyle(
                          color: kWhite54, fontSize: 12, fontStyle: FontStyle.italic, height: 1.7),
                        maxLines: 3, overflow: TextOverflow.ellipsis),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: kCyan.withOpacity(0.45)),
                    color: kCyan.withOpacity(0.07),
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.receipt_long_rounded, color: kCyan, size: 13),
                    const SizedBox(width: 5),
                    Text('${source.isNotEmpty ? source : "Muslim"} #$number',
                        style: TextStyle(
                            color: kCyan, fontSize: 11, fontWeight: FontWeight.bold)),
                  ]),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: _fetchRandomHadith,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: kWhite54.withOpacity(0.3)),
                    ),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.touch_app_rounded, color: kWhite54, size: 14),
                      SizedBox(width: 4),
                      Text('Tap card', style: TextStyle(color: kWhite54, fontSize: 11)),
                    ]),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ── Build ─────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: FangThemeController.instance,
      builder: (context, _) {
        final fang = FangThemeController.instance.config;
        return Scaffold(
          backgroundColor: Colors.transparent,
          extendBody: true,
          appBar: _buildAppBar(),
          drawer: _buildDrawer(),
          body: FangBackground(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 350),
              transitionBuilder: (child, anim) => FadeTransition(opacity: anim, child: child),
              child: KeyedSubtree(
                key: ValueKey(_navIndex),
                child: _buildCurrentPage(),
              ),
            ),
          ),
          bottomNavigationBar: _buildBottomNav(),
        );
      },
    );
  }

  Widget _buildBackgroundGrid() {
    return const SizedBox.expand();
  }

  Future<void> _openDeveloperTelegram() async {
    final fang = FangThemeController.instance.config;
    await showDialog<void>(
      context: context,
      barrierColor: Colors.black.withOpacity(.78),
      builder: (dialogContext) => Dialog(
        backgroundColor: const Color(0xFF07050B),
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: BorderSide(color: fang.accentColor.withOpacity(.78), width: 1.3),
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 18, 22, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  const Expanded(
                    child: Text(
                      'TELEGRAM DEVELOPER',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontWeight: FontWeight.w900,
                        letterSpacing: .7,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(dialogContext),
                    icon: Icon(Icons.close_rounded, color: fang.accentColor),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Container(
                width: 112,
                height: 112,
                padding: const EdgeInsets.all(3),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: fang.accentColor, width: 1.5),
                  boxShadow: [
                    BoxShadow(
                      color: fang.accentColor.withOpacity(.35),
                      blurRadius: 24,
                    ),
                  ],
                ),
                child: ClipOval(
                  child: Image.asset(
                    'assets/images/bomzz_profile.jpg',
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Icon(
                      Icons.person_rounded,
                      color: fang.accentColor,
                      size: 52,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Text(
                'Developer',
                style: TextStyle(
                  color: fang.accentColor,
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 4),
              const Text(
                'BOMZZMODEJUT',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 19,
                  fontWeight: FontWeight.w900,
                  letterSpacing: .8,
                ),
              ),
              const SizedBox(height: 14),
              Text(
                'Jika kamu memiliki pertanyaan, saran, atau menemukan bug, silakan hubungi developer melalui Telegram.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: fang.textSecondary,
                  height: 1.5,
                  fontSize: 12.5,
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton.icon(
                  onPressed: () async {
                    Navigator.of(dialogContext).pop();
                    await _launchDeveloperTelegram();
                  },
                  icon: const Icon(Icons.send_rounded),
                  label: const Text(
                    'BUKA TELEGRAM',
                    style: TextStyle(fontWeight: FontWeight.w900),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── AppBar ──────────────────────────────────────────────────────────────────
  PreferredSizeWidget _buildAppBar() {
    final fang = FangThemeController.instance.config;
    return AppBar(
      toolbarHeight: 82,
      backgroundColor: const Color(0xFF030205),
      elevation: 0,
      automaticallyImplyLeading: false,
      titleSpacing: 18,
      title: Builder(
        builder: (context) => Row(
          children: [
            InkWell(
              onTap: () => Scaffold.of(context).openDrawer(),
              borderRadius: BorderRadius.circular(24),
              child: SizedBox(
                width: 42,
                height: 42,
                child: Icon(Icons.menu_rounded, color: fang.accentColor, size: 29),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: RichText(
                overflow: TextOverflow.ellipsis,
                text: TextSpan(
                  children: [
                    const TextSpan(
                      text: 'HAI,  ',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.2,
                        fontFamily: 'monospace',
                      ),
                    ),
                    TextSpan(
                      text: username,
                      style: TextStyle(
                        color: fang.accentColor,
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.1,
                        fontFamily: 'monospace',
                      ),
                    ),
                  ],
                ),
              ),
            ),
            IconButton(
              tooltip: 'Telegram Developer',
              onPressed: _openDeveloperTelegram,
              icon: Icon(Icons.headset_mic_rounded, color: fang.accentColor, size: 28),
            ),
            const SizedBox(width: 5),
            GestureDetector(
              onTap: () => Navigator.push(
                context,
                _slideRoute(ProfilePage(
                  username: username,
                  password: password,
                  role: role,
                  expiredDate: expiredDate,
                  sessionKey: sessionKey,
                )),
              ),
              child: Container(
                width: 52,
                height: 52,
                padding: const EdgeInsets.all(3),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFF09060E),
                  border: Border.all(color: fang.accentColor.withOpacity(.90), width: 1.4),
                  boxShadow: [
                    BoxShadow(color: fang.accentColor.withOpacity(.28), blurRadius: 18),
                  ],
                ),
                child: ClipOval(
                  child: _profileImage != null
                      ? Image.file(_profileImage!, fit: BoxFit.cover)
                      : (username.trim().toLowerCase() == 'bomz'
                          ? Image.asset('assets/images/bomzz_profile.jpg', fit: BoxFit.cover)
                          : Icon(Icons.person_outline_rounded, color: fang.accentColor, size: 31)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Bottom Nav ─────────────────────────────────────────────────────────────
  Widget _buildBottomNav() {
    final fang = FangThemeController.instance.config;
    final accent = fang.accentColor;
    final lis = fang.neonColor;

    final items = [
      GlazeNavBarItem(
        child: const Icon(Icons.home_rounded),
        label: 'HOME',
        labelStyle: const TextStyle(
          fontSize: 8.5,
          fontWeight: FontWeight.w800,
          letterSpacing: .35,
        ),
      ),
      GlazeNavBarItem(
        child: const FaIcon(FontAwesomeIcons.whatsapp, size: 21),
        label: 'WHATSAPP',
        labelStyle: const TextStyle(
          fontSize: 8.0,
          fontWeight: FontWeight.w800,
          letterSpacing: .25,
        ),
      ),
      GlazeNavBarItem(
        child: const Icon(Icons.chat_bubble_outline_rounded),
        label: 'CHAT ALL',
        labelStyle: const TextStyle(
          fontSize: 8.0,
          fontWeight: FontWeight.w800,
          letterSpacing: .25,
        ),
      ),
      GlazeNavBarItem(
        child: const Icon(Icons.info_outline_rounded),
        label: 'INFO',
        labelStyle: const TextStyle(
          fontSize: 8.5,
          fontWeight: FontWeight.w800,
          letterSpacing: .35,
        ),
      ),
      GlazeNavBarItem(
        child: const Icon(Icons.build_rounded),
        label: 'TOOLS',
        labelStyle: const TextStyle(
          fontSize: 8.5,
          fontWeight: FontWeight.w800,
          letterSpacing: .35,
        ),
      ),
    ];

    return SafeArea(
      top: false,
      minimum: const EdgeInsets.fromLTRB(12, 0, 12, 5),
      child: SizedBox(
        height: 76,
        child: GlazeNavBar(
          index: _navIndex,
          items: items,
          onTap: _onNavTap,
          height: 68,
          maxWidth: double.infinity,
          color: const Color(0xFF0B0711),
          backgroundColor: Colors.transparent,
          buttonBackgroundColor: const Color(0xFF120B1B),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFF110A19).withOpacity(.92),
              Color.alphaBlend(
                lis.withOpacity(.10),
                const Color(0xFF08050D),
              ),
            ],
          ),
          buttonGradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color.alphaBlend(
                accent.withOpacity(.38),
                const Color(0xFF180C24),
              ),
              Color.alphaBlend(
                lis.withOpacity(.44),
                const Color(0xFF0D0713),
              ),
            ],
          ),
          glassBlur: 22,
          glassOpacity: .18,
          glassBorderRadius: 28,
          glassBorderWidth: 1.35,
          glassBorderColor: lis.withOpacity(
            (.48 + (.30 * fang.lisLight)).clamp(0.0, 1.0).toDouble(),
          ),
          buttonBorderColor: lis.withOpacity(
            (.66 + (.28 * fang.lisLight)).clamp(0.0, 1.0).toDouble(),
          ),
          buttonBorderWidth: 2.0,
          iconPadding: 11,
          animationCurve: Curves.easeOutCubic,
          animationDuration: const Duration(milliseconds: 430),
        ),
      ),
    );
  }

  // ── Drawer ──────────────────────────────────────────────────────────────────
  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: Colors.transparent,
      width: MediaQuery.of(context).size.width * 0.8,
      child: Column(
        children: [
          Container(
            height: 240,
            color: Colors.black,
            child: Stack(
              children: [
                if (_menuVideoCtrl != null && _menuVideoCtrl!.value.isInitialized)
                  SizedBox.expand(
                    child: FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                        width: _menuVideoCtrl!.value.size.width,
                        height: _menuVideoCtrl!.value.size.height,
                        child: VideoPlayer(_menuVideoCtrl!),
                      ),
                    ),
                  ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter, end: Alignment.bottomCenter,
                      colors: [Colors.black.withOpacity(0.3), Colors.black.withOpacity(0.85)],
                    ),
                  ),
                ),
                SafeArea(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 80, height: 80,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: kCyan.withOpacity(0.6), width: 2.5),
                            boxShadow: [BoxShadow(color: kCyan.withOpacity(0.3), blurRadius: 14, spreadRadius: 2)],
                          ),
                          child: ClipOval(
                            child: _profileImage != null
                                ? Image.file(_profileImage!, fit: BoxFit.cover)
                                : Icon(FontAwesomeIcons.userAstronaut, size: 38, color: kWhite),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(username,
                            style: const TextStyle(
                                color: kWhite, fontSize: 18, fontWeight: FontWeight.bold)),
                        Text(role.toUpperCase(),
                            style: TextStyle(color: kCyan, fontSize: 12, letterSpacing: 2)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              color: kBg,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 16),
                children: [
                  if (role == 'reseller')
                    _buildDrawerItem(
                        icon: Icons.storefront_rounded,
                        label: 'Seller Page',
                        onTap: () => _onDrawerNav(1)),
                  if (role == 'admin')
                    _buildDrawerItem(
                        icon: Icons.admin_panel_settings_rounded,
                        label: 'Admin Page',
                        onTap: () => _onDrawerNav(2)),
                  if (role.trim().toLowerCase() == 'owner')
                    _buildDrawerItem(
                        icon: Icons.workspace_premium_rounded,
                        label: 'Owner Page',
                        onTap: () => _onDrawerNav(3)),
                  if (role.trim().toLowerCase() == 'developer' ||
                      role.trim().toLowerCase() == 'dev')
                    _buildDrawerItem(
                        icon: Icons.code_rounded,
                        label: 'Developer Page',
                        onTap: () => _onDrawerNav(4)),
                  _buildDrawerItem(
                    icon: Icons.forum_rounded,
                    label: 'Chat All',
                    onTap: () {
                      Navigator.pop(context);
                      setState(() => _navIndex = 2);
                    },
                  ),
                  _buildDrawerItem(
                    icon: Icons.history_rounded,
                    label: 'Riwayat Aktivitas',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                          context,
                          _slideRoute(RiwayatPage(sessionKey: sessionKey, role: role))).then((_) {
                        if (mounted && _newsPageCtrl.hasClients) {
                          setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
                          _newsPageCtrl.jumpToPage(0);
                        }
                      });
                    },
                  ),
                  _buildDrawerItem(
                    icon: Icons.smart_toy_rounded,
                    label: 'AI Assistant',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        _slideRoute(AIChatPage(username: username, sessionKey: sessionKey)),
                      );
                    },
                  ),
                  _buildDrawerItem(
                    icon: Icons.music_note_rounded,
                    label: 'Music Player',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        _slideRoute(const SpotifyPage()),
                      );
                    },
                  ),
                  _buildDrawerItem(
                    icon: Icons.palette_rounded,
                    label: 'Appearance / Theme',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        _slideRoute(const FangAppearancePage()),
                      );
                    },
                  ),
                  _buildDrawerItem(
                    icon: Icons.lock_outline_rounded,
                    label: 'Ganti Password',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        _slideRoute(ChangePasswordPage(username: username, sessionKey: sessionKey)),
                      );
                    },
                  ),
                  const SizedBox(height: 16),
                  _buildDrawerItem(
                    icon: Icons.logout_rounded,
                    label: 'Keluar',
                    isLogout: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.remove('username');
                      await prefs.remove('password');
                      await prefs.remove('key');
                      await FangThemeController.instance.switchAccount('guest');
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false);
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      decoration: BoxDecoration(
        color: isLogout ? Colors.red.withOpacity(0.08) : kCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: isLogout ? Colors.red.withOpacity(0.3) : kBorder.withOpacity(0.4)),
      ),
      child: ListTile(
        leading: Icon(icon, color: isLogout ? Colors.redAccent : kCyan, size: 20),
        title: Text(label,
            style: TextStyle(
                color: isLogout ? Colors.redAccent : kWhite,
                fontWeight: FontWeight.w600, fontSize: 14)),
        trailing: Icon(Icons.arrow_forward_ios_rounded, color: kWhite24, size: 13),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        onTap: onTap,
      ),
    );
  }
}

// ─── FANG CYBER CLIPPER ──────────────────────────────────────────────────────
class _FangCyberClipper extends CustomClipper<Path> {
  final double cut;
  const _FangCyberClipper({this.cut = 12});

  @override
  Path getClip(Size size) {
    final c = math.min(cut, math.min(size.width, size.height) / 3);
    return Path()
      ..moveTo(c, 0)
      ..lineTo(size.width - c, 0)
      ..lineTo(size.width, c)
      ..lineTo(size.width, size.height - c)
      ..lineTo(size.width - c, size.height)
      ..lineTo(c, size.height)
      ..lineTo(0, size.height - c)
      ..lineTo(0, c)
      ..close();
  }

  @override
  bool shouldReclip(covariant _FangCyberClipper oldClipper) => oldClipper.cut != cut;
}

// ─── FANG CYBER BORDER PAINTER ──────────────────────────────────────────────
class _FangCyberBorderPainter extends CustomPainter {
  final Color color;
  final double cut;
  const _FangCyberBorderPainter({required this.color, this.cut = 12});

  @override
  void paint(Canvas canvas, Size size) {
    final c = math.min(cut, math.min(size.width, size.height) / 3);
    final path = Path()
      ..moveTo(c, .7)
      ..lineTo(size.width - c, .7)
      ..lineTo(size.width - .7, c)
      ..lineTo(size.width - .7, size.height - c)
      ..lineTo(size.width - c, size.height - .7)
      ..lineTo(c, size.height - .7)
      ..lineTo(.7, size.height - c)
      ..lineTo(.7, c)
      ..close();

    final glow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4
      ..color = color.withOpacity(.13)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
    canvas.drawPath(path, glow);

    final line = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.15
      ..color = color;
    canvas.drawPath(path, line);

    final corner = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.7
      ..strokeCap = StrokeCap.square
      ..color = color.withOpacity(.82);
    canvas.drawLine(Offset(c + 7, 3), Offset(c + 28, 3), corner);
    canvas.drawLine(Offset(size.width - c - 28, size.height - 3),
        Offset(size.width - c - 7, size.height - 3), corner);
  }

  @override
  bool shouldRepaint(covariant _FangCyberBorderPainter oldDelegate) =>
      oldDelegate.color != color || oldDelegate.cut != cut;
}

// ─── Quick Action Data ─────────────────────────────────────────────────────────
class _QuickActionData {
  final IconData icon;
  final IconData bgIcon;
  final String title;
  final String subtitle;
  final List<Color> gradient;
  final VoidCallback onTap;
  const _QuickActionData({
    required this.icon,
    required this.bgIcon,
    required this.title,
    required this.subtitle,
    required this.gradient,
    required this.onTap,
  });
}

// ─── Nav Item ─────────────────────────────────────────────────────────────────
class _LiquidNavPainter extends CustomPainter {
  final double centerX;
  final Color accent;

  const _LiquidNavPainter({
    required this.centerX,
    required this.accent,
  });

  @override
  void paint(Canvas canvas, Size size) {
    const topY = 20.0;
    const radius = 24.0;
    const shoulder = 48.0;

    final path = Path()
      ..moveTo(radius, topY)
      ..lineTo(centerX - shoulder, topY)
      ..cubicTo(
        centerX - 35, topY,
        centerX - 34, 4,
        centerX - 22, 4,
      )
      ..cubicTo(
        centerX - 12, 4,
        centerX - 11, 0,
        centerX, 0,
      )
      ..cubicTo(
        centerX + 11, 0,
        centerX + 12, 4,
        centerX + 22, 4,
      )
      ..cubicTo(
        centerX + 34, 4,
        centerX + 35, topY,
        centerX + shoulder, topY,
      )
      ..lineTo(size.width - radius, topY)
      ..quadraticBezierTo(size.width, topY, size.width, topY + radius)
      ..lineTo(size.width, size.height - radius)
      ..quadraticBezierTo(
        size.width,
        size.height,
        size.width - radius,
        size.height,
      )
      ..lineTo(radius, size.height)
      ..quadraticBezierTo(0, size.height, 0, size.height - radius)
      ..lineTo(0, topY + radius)
      ..quadraticBezierTo(0, topY, radius, topY)
      ..close();

    final fill = Paint()
      ..style = PaintingStyle.fill
      ..color = const Color(0xF8080710);
    canvas.drawShadow(path, Colors.black.withOpacity(.85), 14, true);
    canvas.drawPath(path, fill);

    final border = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.15
      ..color = accent.withOpacity(.38);
    canvas.drawPath(path, border);

    final glow = Paint()
      ..shader = RadialGradient(
        colors: [
          accent.withOpacity(.34),
          accent.withOpacity(.10),
          Colors.transparent,
        ],
      ).createShader(
        Rect.fromCircle(
          center: Offset(centerX, 24),
          radius: 56,
        ),
      );
    canvas.drawCircle(Offset(centerX, 24), 56, glow);
  }

  @override
  bool shouldRepaint(covariant _LiquidNavPainter oldDelegate) {
    return oldDelegate.centerX != centerX || oldDelegate.accent != accent;
  }
}

class _NavItem {
  final IconData icon;
  final String label;
  const _NavItem({required this.icon, required this.label});
}

// ─── Slide Route ──────────────────────────────────────────────────────────────
PageRoute _slideRoute(Widget page) => PageRouteBuilder(
  pageBuilder: (_, __, ___) => page,
  transitionDuration: const Duration(milliseconds: 350),
  transitionsBuilder: (_, anim, __, child) => SlideTransition(
    position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
        .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
    child: FadeTransition(opacity: anim, child: child),
  ),
);

// ─── NewsMedia ────────────────────────────────────────────────────────────────
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});
  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _ctrl;
  bool _isVideo(String url) =>
      url.endsWith('.mp4') || url.endsWith('.webm') ||
      url.endsWith('.mov') || url.endsWith('.mkv');
  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _ctrl = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (mounted) setState(() {});
          _ctrl?.setLooping(true);
          _ctrl?.setVolume(0.0);
          _ctrl?.play();
        });
    }
  }
  @override
  void dispose() { _ctrl?.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_ctrl != null && _ctrl!.value.isInitialized) {
        return AspectRatio(aspectRatio: _ctrl!.value.aspectRatio, child: VideoPlayer(_ctrl!));
      }
      return Center(child: CircularProgressIndicator(color: kCyan, strokeWidth: 2));
    }
    return Image.network(
      widget.url, fit: BoxFit.cover,
      errorBuilder: (_, __, ___) =>
          Container(color: kCard, child: Icon(Icons.error_rounded, color: kWhite24)),
    );
  }
}
