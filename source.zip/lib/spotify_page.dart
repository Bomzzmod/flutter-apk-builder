import 'dart:convert';
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class FangShadowSpotifyPage extends StatefulWidget {
  const FangShadowSpotifyPage({super.key});

  @override
  State<FangShadowSpotifyPage> createState() => _FangShadowSpotifyPageState();
}

class _FangShadowSpotifyPageState extends State<FangShadowSpotifyPage>
    with SingleTickerProviderStateMixin {
  final TextEditingController _controller = TextEditingController();
  final AudioPlayer _player = AudioPlayer();
  late final AnimationController _pulse;

  Map<String, dynamic>? _song;
  bool _loading = false;
  bool _playing = false;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;
  String _error = '';

  static const Color bg = Color(0xFF08050D);
  static const Color panel = Color(0xFF120A1D);
  static const Color panel2 = Color(0xFF1B0D29);
  static const Color purple = Color(0xFF8B35FF);
  static const Color purpleSoft = Color(0xFFC47CFF);
  static const Color white70 = Colors.white70;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
      lowerBound: 0.94,
      upperBound: 1.0,
    )..repeat(reverse: true);

    _player.onPlayerStateChanged.listen((state) {
      if (!mounted) return;
      setState(() => _playing = state == PlayerState.playing);
    });
    _player.onPositionChanged.listen((position) {
      if (!mounted) return;
      setState(() => _position = position);
    });
    _player.onDurationChanged.listen((duration) {
      if (!mounted) return;
      setState(() => _duration = duration);
    });
    _player.onPlayerComplete.listen((_) {
      if (!mounted) return;
      setState(() {
        _playing = false;
        _position = Duration.zero;
      });
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _player.dispose();
    _pulse.dispose();
    super.dispose();
  }

  Future<void> searchSpotify(String input) async {
    final query = input.trim();
    if (query.isEmpty) return;

    setState(() {
      _loading = true;
      _error = '';
      _song = null;
    });

    String spotifyUrl = query;

    try {
      if (!spotifyUrl.contains('open.spotify.com')) {
        final searchRes = await http.get(Uri.parse(
          'https://riimusic.my.id/api/spotify/search?apikey=riicode&query=${Uri.encodeComponent(query)}',
        )).timeout(const Duration(seconds: 15));

        if (searchRes.statusCode != 200) {
          throw Exception('Search API ${searchRes.statusCode}');
        }

        final searchData = jsonDecode(searchRes.body) as Map<String, dynamic>;
        final songs = searchData['result']?['songs'];
        final track = songs is List && songs.isNotEmpty ? songs.first : null;

        if (track is! Map || track['url'] == null) {
          throw Exception('Lagu tidak ditemukan');
        }
        spotifyUrl = track['url'].toString();
      }

      final res = await http.get(Uri.parse(
        'https://api.ikyyxd.my.id/download/spotifydl?url=${Uri.encodeComponent(spotifyUrl)}',
      )).timeout(const Duration(seconds: 20));

      if (res.statusCode != 200) {
        throw Exception('Download API ${res.statusCode}');
      }

      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['status'] != true || data['result'] is! Map) {
        throw Exception('Gagal mengambil lagu');
      }

      final result = Map<String, dynamic>.from(data['result'] as Map);
      if (result['download'] == null) {
        throw Exception('URL audio tidak tersedia');
      }

      if (mounted) {
        setState(() {
          _song = result;
          _loading = false;
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e.toString().replaceFirst('Exception: ', '');
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('❌ $_error'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: panel2,
        ),
      );
    }
  }

  Future<void> playSong() async {
    final song = _song;
    if (song == null) return;

    final download = song['download']?.toString();
    if (download == null || download.isEmpty) return;

    try {
      if (_playing) {
        await _player.pause();
        return;
      }

      setState(() => _position = Duration.zero);
      await _player.stop();

      final response = await http.get(
        Uri.parse(download),
        headers: const {'User-Agent': 'Mozilla/5.0'},
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception('Audio gagal dimuat (${response.statusCode})');
      }

      final Uint8List bytes = response.bodyBytes;
      if (bytes.isEmpty) throw Exception('File audio kosong');

      await _player.play(BytesSource(bytes));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('❌ Audio gagal diputar: $e'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: panel2,
        ),
      );
    }
  }

  String _format(Duration value) {
    final minutes = value.inMinutes.remainder(60).toString().padLeft(2, '0');
    final seconds = value.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  String _text(dynamic value, [String fallback = '-']) {
    final text = value?.toString().trim() ?? '';
    return text.isEmpty ? fallback : text;
  }

  @override
  Widget build(BuildContext context) {
    final song = _song;
    final max = _duration.inMilliseconds <= 0
        ? 1.0
        : _duration.inMilliseconds.toDouble();
    final current = _position.inMilliseconds.clamp(0, max.toInt()).toDouble();

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg,
        elevation: 0,
        centerTitle: false,
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Row(
          children: [
            Icon(Icons.bolt_rounded, color: purpleSoft),
            SizedBox(width: 8),
            Text(
              'FANG SHADOW MUSIC',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.1,
              ),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: Stack(
          children: [
            ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 130),
              children: [
                _buildSearch(),
                const SizedBox(height: 16),
                if (_loading)
                  const Padding(
                    padding: EdgeInsets.all(30),
                    child: Center(
                      child: CircularProgressIndicator(color: purpleSoft),
                    ),
                  ),
                if (song != null) _buildSongCard(song, current, max),
                if (!_loading && song == null && _error.isEmpty)
                  _buildEmptyState(),
              ],
            ),
            if (_playing && song != null) _buildDynamicIsland(song),
          ],
        ),
      ),
    );
  }

  Widget _buildSearch() {
    return Container(
      decoration: BoxDecoration(
        color: panel,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: purple.withOpacity(0.38)),
      ),
      child: Row(
        children: [
          const Padding(
            padding: EdgeInsets.only(left: 14),
            child: Icon(Icons.search_rounded, color: purpleSoft),
          ),
          Expanded(
            child: TextField(
              controller: _controller,
              style: const TextStyle(color: Colors.white),
              textInputAction: TextInputAction.search,
              onSubmitted: searchSpotify,
              decoration: const InputDecoration(
                hintText: 'Judul lagu / URL Spotify',
                hintStyle: TextStyle(color: Colors.white38),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
              ),
            ),
          ),
          IconButton(
            onPressed: () => searchSpotify(_controller.text),
            icon: const Icon(Icons.arrow_forward_rounded, color: Colors.white),
          ),
        ],
      ),
    );
  }

  Widget _buildSongCard(
    Map<String, dynamic> song,
    double current,
    double max,
  ) {
    final thumbnail = _text(song['thumbnail'], '');
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: panel,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: purple.withOpacity(0.32)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: AspectRatio(
              aspectRatio: 1,
              child: thumbnail.isEmpty
                  ? const ColoredBox(
                      color: panel2,
                      child: Icon(Icons.music_note_rounded, color: purpleSoft, size: 70),
                    )
                  : Image.network(
                      thumbnail,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => const ColoredBox(
                        color: panel2,
                        child: Icon(Icons.music_note_rounded, color: purpleSoft, size: 70),
                      ),
                    ),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            _text(song['title'], 'Unknown Track'),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 21,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            '👤 ${_text(song['artist'])}',
            style: const TextStyle(color: white70),
          ),
          const SizedBox(height: 3),
          Text(
            '💿 ${_text(song['album'])}',
            style: const TextStyle(color: Colors.white54),
          ),
          const SizedBox(height: 18),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: purpleSoft,
              inactiveTrackColor: Colors.white12,
              thumbColor: Colors.white,
              overlayColor: purple.withOpacity(0.15),
            ),
            child: Slider(
              min: 0,
              max: max,
              value: current,
              onChanged: _duration == Duration.zero
                  ? null
                  : (value) => _player.seek(Duration(milliseconds: value.round())),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(_format(_position), style: const TextStyle(color: Colors.white38)),
                Text(_format(_duration), style: const TextStyle(color: Colors.white38)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: playSong,
              style: ElevatedButton.styleFrom(
                backgroundColor: purple,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 15),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
              icon: Icon(_playing ? Icons.pause_rounded : Icons.play_arrow_rounded),
              label: Text(_playing ? 'PAUSE' : 'PLAY MUSIC'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDynamicIsland(Map<String, dynamic> song) {
    final thumbnail = _text(song['thumbnail'], '');
    return Positioned(
      top: 8,
      left: 18,
      right: 18,
      child: GestureDetector(
        onTap: playSong,
        child: ScaleTransition(
          scale: _pulse,
          child: Container(
            height: 62,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              color: const Color(0xFF050308),
              borderRadius: BorderRadius.circular(32),
              border: Border.all(color: purple.withOpacity(0.55)),
              boxShadow: [
                BoxShadow(
                  color: purple.withOpacity(0.18),
                  blurRadius: 18,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: Row(
              children: [
                ClipOval(
                  child: SizedBox(
                    width: 42,
                    height: 42,
                    child: thumbnail.isEmpty
                        ? const ColoredBox(
                            color: panel2,
                            child: Icon(Icons.music_note, color: purpleSoft, size: 20),
                          )
                        : Image.network(
                            thumbnail,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => const ColoredBox(
                              color: panel2,
                              child: Icon(Icons.music_note, color: purpleSoft, size: 20),
                            ),
                          ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'NOW PLAYING • FANG SHADOW',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: purpleSoft,
                          fontSize: 8,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.8,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        _text(song['title']),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 6),
                const Icon(Icons.pause_rounded, color: Colors.white, size: 23),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Container(
      margin: const EdgeInsets.only(top: 40),
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        color: panel,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: purple.withOpacity(0.22)),
      ),
      child: const Column(
        children: [
          Icon(Icons.music_note_rounded, color: purpleSoft, size: 54),
          SizedBox(height: 12),
          Text(
            'FANG SHADOW MUSIC',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800),
          ),
          SizedBox(height: 6),
          Text(
            'Cari lagu untuk menampilkan player.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white54),
          ),
        ],
      ),
    );
  }
}

// Compatibility alias so existing navigation code can keep using SpotifyPage().
class SpotifyPage extends FangShadowSpotifyPage {
  const SpotifyPage({super.key});
}
