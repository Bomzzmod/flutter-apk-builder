import 'dart:convert';

import 'package:http/http.dart' as http;

class ToolApiException implements Exception {
  final String message;
  final int? statusCode;

  const ToolApiException(this.message, {this.statusCode});

  @override
  String toString() => statusCode == null
      ? message
      : '$message (HTTP $statusCode)';
}

class ToolApiClient {
  ToolApiClient._();

  static final ToolApiClient instance = ToolApiClient._();

  static const Duration defaultTimeout = Duration(seconds: 15);

  final http.Client _client = http.Client();

  Map<String, String> get _defaultHeaders => const {
        'Accept': 'application/json, text/plain, */*',
        'User-Agent': 'FangShadow/6.0 Flutter',
      };

  Future<http.Response> get(
    Uri uri, {
    Map<String, String>? headers,
    Duration timeout = defaultTimeout,
  }) async {
    try {
      return await _client
          .get(uri, headers: {..._defaultHeaders, ...?headers})
          .timeout(timeout);
    } on Exception catch (e) {
      throw ToolApiException('Koneksi gagal: $e');
    }
  }

  Future<Map<String, dynamic>> getJson(
    Uri uri, {
    Map<String, String>? headers,
    Duration timeout = defaultTimeout,
  }) async {
    final response = await get(uri, headers: headers, timeout: timeout);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw ToolApiException(
        'Server menolak permintaan',
        statusCode: response.statusCode,
      );
    }

    try {
      final decoded = jsonDecode(utf8.decode(response.bodyBytes));
      if (decoded is Map<String, dynamic>) return decoded;
      if (decoded is Map) return Map<String, dynamic>.from(decoded);
      throw const FormatException('Root JSON bukan object');
    } on FormatException catch (e) {
      throw ToolApiException('Format response tidak valid: $e');
    }
  }

  Future<String> getText(
    Uri uri, {
    Map<String, String>? headers,
    Duration timeout = defaultTimeout,
  }) async {
    final response = await get(uri, headers: headers, timeout: timeout);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw ToolApiException(
        'Server menolak permintaan',
        statusCode: response.statusCode,
      );
    }
    return utf8.decode(response.bodyBytes);
  }

  /// DNS-over-HTTPS JSON query. No API key required.
  Future<Map<String, dynamic>> dnsQuery(
    String name,
    String type, {
    Duration timeout = defaultTimeout,
  }) async {
    final clean = name.trim().toLowerCase();
    if (clean.isEmpty) {
      throw const ToolApiException('Nama domain kosong');
    }

    final cloudflare = Uri.https(
      'cloudflare-dns.com',
      '/dns-query',
      {'name': clean, 'type': type},
    );

    try {
      return await getJson(
        cloudflare,
        headers: const {'Accept': 'application/dns-json'},
        timeout: timeout,
      );
    } catch (_) {
      final google = Uri.https(
        'dns.google',
        '/resolve',
        {'name': clean, 'type': type},
      );
      return getJson(google, timeout: timeout);
    }
  }
}
