import 'package:flutter/material.dart';

import 'api_config.dart';
import 'fang_global_theme.dart';
import 'tool_api_client.dart';

class ToolsHealthPage extends StatefulWidget {
  final String sessionKey;

  const ToolsHealthPage({super.key, required this.sessionKey});

  @override
  State<ToolsHealthPage> createState() => _ToolsHealthPageState();
}

class _ToolsHealthPageState extends State<ToolsHealthPage> {
  bool _running = false;
  Map<String, _HealthResult> _results = const {};

  @override
  void initState() {
    super.initState();
    _run();
  }

  Future<void> _run() async {
    setState(() => _running = true);
    final checks = <String, Future<void> Function()>{
      'Backend App': () async {
        final uri = Uri.parse('$baseUrl/getServerInfo').replace(
          queryParameters: {'key': widget.sessionKey},
        );
        final response = await ToolApiClient.instance.get(uri);
        if (response.statusCode < 200 || response.statusCode >= 300) {
          throw ToolApiException('Backend tidak siap', statusCode: response.statusCode);
        }
      },
      'Chat All Server': () async {
        final response = await ToolApiClient.instance.get(
          chatHealthUri(widget.sessionKey),
          timeout: const Duration(seconds: 8),
        );
        if (response.statusCode < 200 || response.statusCode >= 300) {
          throw ToolApiException('Chat server tidak siap', statusCode: response.statusCode);
        }
      },
      'DNS Resolver': () async {
        await ToolApiClient.instance.dnsQuery('example.com', 'A');
      },
      'IP Geolocation': () async {
        final response = await ToolApiClient.instance.get(
          Uri.https('ipwho.is', '/8.8.8.8'),
          timeout: const Duration(seconds: 8),
        );
        if (response.statusCode < 200 || response.statusCode >= 300) {
          throw ToolApiException('IP lookup tidak siap', statusCode: response.statusCode);
        }
      },
      'Jadwal Sholat': () async {
        final uri = Uri.https('api.aladhan.com', '/v1/timingsByCity', {
          'city': 'Jakarta',
          'country': 'Indonesia',
          'method': '20',
        });
        await ToolApiClient.instance.getJson(uri);
      },
      'Drama Metadata': () async {
        // TVMaze /search/shows mengembalikan JSON array, jadi cukup
        // validasi koneksi + status HTTP di level response.
        final response = await ToolApiClient.instance.get(
          Uri.https('api.tvmaze.com', '/search/shows', {'q': 'love'}),
        );
        if (response.statusCode < 200 || response.statusCode >= 300) {
          throw ToolApiException('TV metadata tidak siap', statusCode: response.statusCode);
        }
      },
      'Downloader API': () async {
        // Hanya health check domain. Tidak melakukan download media.
        final response = await ToolApiClient.instance.get(
          Uri.https('api.siputzx.my.id', '/'),
          timeout: const Duration(seconds: 10),
        );
        if (response.statusCode < 200 || response.statusCode >= 300) {
          throw ToolApiException('Downloader API tidak siap', statusCode: response.statusCode);
        }
      },
      'Anime API': () async {
        final response = await ToolApiClient.instance.get(
          Uri.https('www.sankavollerei.com', '/anime/home'),
          timeout: const Duration(seconds: 10),
        );
        if (response.statusCode < 200 || response.statusCode >= 300) {
          throw ToolApiException('Anime API tidak siap', statusCode: response.statusCode);
        }
      },
    };

    final next = <String, _HealthResult>{};
    for (final entry in checks.entries) {
      final sw = Stopwatch()..start();
      try {
        await entry.value();
        sw.stop();
        next[entry.key] = _HealthResult(true, '${sw.elapsedMilliseconds} ms');
      } catch (e) {
        sw.stop();
        next[entry.key] = _HealthResult(false, e.toString());
      }
      if (mounted) setState(() => _results = Map.of(next));
    }

    if (mounted) setState(() => _running = false);
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: FangThemeController.instance,
      builder: (context, _) {
        final fang = FangThemeController.instance.config;
        return Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            title: const Text('Tools Diagnostics',
                style: TextStyle(fontWeight: FontWeight.w800)),
            actions: [
              IconButton(
                onPressed: _running ? null : _run,
                icon: const Icon(Icons.refresh_rounded),
              ),
            ],
          ),
          body: FangBackground(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
              children: [
                FangCard(
                  strongerGlow: true,
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      const FangNeonIcon(icon: Icons.monitor_heart_rounded),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('SERVICE STATUS',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w900)),
                            Text(
                              'Cek koneksi yang dipakai oleh menu Tools.',
                              style: TextStyle(
                                  color: fang.textSecondary, fontSize: 11),
                            ),
                          ],
                        ),
                      ),
                      if (_running)
                        SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: fang.accentColor,
                          ),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                ..._results.entries.map((entry) {
                  final result = entry.value;
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: FangCard(
                      padding: const EdgeInsets.all(14),
                      child: Row(
                        children: [
                          Icon(
                            result.ok
                                ? Icons.check_circle_rounded
                                : Icons.error_rounded,
                            color: result.ok
                                ? const Color(0xFF41F5B2)
                                : const Color(0xFFFF6B6B),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(entry.key,
                                    style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w800)),
                                const SizedBox(height: 3),
                                Text(result.detail,
                                    maxLines: 3,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                        color: fang.textSecondary,
                                        fontSize: 10.5)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }),
                if (_results.isEmpty && _running)
                  Padding(
                    padding: const EdgeInsets.only(top: 40),
                    child: Center(
                      child: CircularProgressIndicator(color: fang.accentColor),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _HealthResult {
  final bool ok;
  final String detail;
  const _HealthResult(this.ok, this.detail);
}
