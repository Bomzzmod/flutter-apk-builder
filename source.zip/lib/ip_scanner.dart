import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

import 'fang_global_theme.dart';

class IpScannerPage extends StatefulWidget {
  const IpScannerPage({super.key});

  @override
  State<IpScannerPage> createState() => _IpScannerPageState();
}

class _IpScannerPageState extends State<IpScannerPage> {
  final _controller = TextEditingController();
  bool _loading = false;
  String? _error;
  Map<String, dynamic>? _data;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _lookup() async {
    final input = _controller.text.trim();
    setState(() {
      _loading = true;
      _error = null;
      _data = null;
    });

    try {
      String ip = input;
      if (ip.isEmpty) {
        try {
          final res = await http
              .get(Uri.parse('https://api.ipify.org?format=json'))
              .timeout(const Duration(seconds: 8));
          if (res.statusCode != 200) throw Exception('ipify HTTP ${res.statusCode}');
          ip = (jsonDecode(utf8.decode(res.bodyBytes))['ip'] ?? '').toString();
        } catch (_) {
          // Fallback: ipwho.is juga bisa mendeteksi IP pemanggil tanpa API key.
          final res = await http
              .get(Uri.parse('https://ipwho.is/'))
              .timeout(const Duration(seconds: 8));
          if (res.statusCode != 200) throw Exception('Gagal mendeteksi IP publik');
          final decoded = jsonDecode(utf8.decode(res.bodyBytes));
          if (decoded is! Map || decoded['success'] == false) {
            throw Exception('Gagal mendeteksi IP publik');
          }
          ip = (decoded['ip'] ?? '').toString();
        }
      } else if (!_isValidIPv4(ip)) {
        throw Exception('Masukkan IPv4 yang valid, mis. 8.8.8.8');
      }

      if (!_isValidIPv4(ip)) {
        throw Exception('IP publik yang terdeteksi tidak valid');
      }

      if (_isPrivate(ip)) {
        if (!mounted) return;
        setState(() {
          _data = {
            'ip': ip,
            'type': 'Private / local network',
            'country_name': '-',
            'region': '-',
            'city': '-',
            'org': 'Local network',
            'timezone': DateTime.now().timeZoneName,
          };
        });
        return;
      }

      Map<String, dynamic>? data;
      Object? firstError;
      try {
        final response = await http
            .get(Uri.parse('https://ipapi.co/$ip/json/'),
                headers: const {'Accept': 'application/json'})
            .timeout(const Duration(seconds: 10));
        if (response.statusCode != 200) {
          throw Exception('ipapi HTTP ${response.statusCode}');
        }
        final decoded = jsonDecode(utf8.decode(response.bodyBytes));
        if (decoded is! Map) throw Exception('Format ipapi tidak valid');
        final parsed = Map<String, dynamic>.from(decoded);
        if (parsed['error'] == true) {
          throw Exception(parsed['reason'] ?? 'ipapi gagal');
        }
        data = parsed;
      } catch (e) {
        firstError = e;
      }

      if (data == null) {
        final response = await http
            .get(Uri.parse('https://ipwho.is/$ip'))
            .timeout(const Duration(seconds: 10));
        if (response.statusCode != 200) {
          throw Exception('Lookup gagal: ${firstError ?? ''}; ipwho.is HTTP ${response.statusCode}');
        }
        final decoded = jsonDecode(utf8.decode(response.bodyBytes));
        if (decoded is! Map || decoded['success'] == false) {
          throw Exception(decoded is Map
              ? (decoded['message'] ?? 'IP tidak dapat diperiksa')
              : 'Format ipwho.is tidak valid');
        }
        final fallback = Map<String, dynamic>.from(decoded);
        data = {
          ...fallback,
          'country_name': fallback['country'] ?? '-',
          'org': (fallback['connection'] is Map)
              ? ((fallback['connection'] as Map)['org'] ??
                  (fallback['connection'] as Map)['isp'] ?? '-')
              : '-',
          'timezone': (fallback['timezone'] is Map)
              ? ((fallback['timezone'] as Map)['id'] ?? '-')
              : (fallback['timezone'] ?? '-'),
        };
      }

      if (!mounted) return;
      setState(() => _data = data);
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  bool _isValidIPv4(String ip) {
    final parts = ip.split('.');
    if (parts.length != 4) return false;
    for (final part in parts) {
      if (part.isEmpty || part.length > 3) return false;
      if (part.length > 1 && part.startsWith('0')) return false;
      final value = int.tryParse(part);
      if (value == null || value < 0 || value > 255) return false;
    }
    return true;
  }

  bool _isPrivate(String ip) {
    if (!_isValidIPv4(ip)) return false;
    final parts = ip.split('.').map((e) => int.parse(e)).toList();
    final a = parts[0];
    final b = parts[1];
    return a == 10 ||
        a == 127 ||
        (a == 192 && b == 168) ||
        (a == 172 && b >= 16 && b <= 31) ||
        (a == 169 && b == 254);
  }

  void _copy(String value) {
    Clipboard.setData(ClipboardData(text: value));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Disalin'), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: FangThemeController.instance,
      builder: (context, _) {
        final fang = FangThemeController.instance.config;
        return Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            title: const Text('IP Information',
                style: TextStyle(fontWeight: FontWeight.w800)),
          ),
          body: FangBackground(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
              children: [
                FangCard(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      TextField(
                        controller: _controller,
                        keyboardType: TextInputType.number,
                        textInputAction: TextInputAction.search,
                        onSubmitted: (_) => _lookup(),
                        decoration: const InputDecoration(
                          labelText: 'IPv4',
                          hintText: 'Kosongkan untuk IP publik perangkat',
                          prefixIcon: Icon(Icons.public_rounded),
                        ),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: _loading ? null : _lookup,
                          icon: _loading
                              ? const SizedBox(
                                  width: 16,
                                  height: 16,
                                  child: CircularProgressIndicator(
                                      strokeWidth: 2, color: Colors.white),
                                )
                              : const Icon(Icons.search_rounded),
                          label: const Text('LOOKUP'),
                        ),
                      ),
                    ],
                  ),
                ),
                if (_error != null) ...[
                  const SizedBox(height: 14),
                  FangCard(
                    padding: const EdgeInsets.all(14),
                    child: Text(_error!,
                        style: const TextStyle(color: Color(0xFFFF8A8A))),
                  ),
                ],
                if (_data != null) ...[
                  const SizedBox(height: 14),
                  FangCard(
                    strongerGlow: true,
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        _row('IP', _value('ip'), copy: true),
                        _row('Type', _value('type')),
                        _row('Country', _value('country_name')),
                        _row('Region', _value('region')),
                        _row('City', _value('city')),
                        _row('Postal', _value('postal')),
                        _row('Timezone', _value('timezone')),
                        _row('ASN', _value('asn')),
                        _row('Organization', _value('org')),
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 10),
                Text(
                  'Informasi lokasi IP bersifat perkiraan berdasarkan database jaringan publik.',
                  style: TextStyle(color: fang.textSecondary, fontSize: 10.5),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  String _value(String key) {
    final value = _data?[key];
    if (value == null || value.toString().trim().isEmpty) return '-';
    return value.toString();
  }

  Widget _row(String label, String value, {bool copy = false}) {
    return InkWell(
      onTap: copy && value != '-' ? () => _copy(value) : null,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 7),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 100,
              child: Text(label,
                  style: const TextStyle(color: Colors.white54, fontSize: 11)),
            ),
            Expanded(
              child: SelectableText(value,
                  style: const TextStyle(color: Colors.white, fontSize: 11.5)),
            ),
            if (copy) const Icon(Icons.copy_rounded, size: 14, color: Colors.white38),
          ],
        ),
      ),
    );
  }
}
