import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

class PrayerAdzanSettings {
  final bool enabled;
  final String city;
  final bool subuh;
  final bool dzuhur;
  final bool ashar;
  final bool maghrib;
  final bool isya;
  final double volume;
  final double? latitude;
  final double? longitude;
  final double? locationAccuracyMeters;

  const PrayerAdzanSettings({
    this.enabled = false,
    this.city = 'Surabaya',
    this.subuh = true,
    this.dzuhur = true,
    this.ashar = true,
    this.maghrib = true,
    this.isya = true,
    this.volume = 1.0,
    this.latitude,
    this.longitude,
    this.locationAccuracyMeters,
  });

  PrayerAdzanSettings copyWith({
    bool? enabled,
    String? city,
    bool? subuh,
    bool? dzuhur,
    bool? ashar,
    bool? maghrib,
    bool? isya,
    double? volume,
    double? latitude,
    double? longitude,
    double? locationAccuracyMeters,
    bool clearCoordinates = false,
  }) {
    return PrayerAdzanSettings(
      enabled: enabled ?? this.enabled,
      city: city ?? this.city,
      subuh: subuh ?? this.subuh,
      dzuhur: dzuhur ?? this.dzuhur,
      ashar: ashar ?? this.ashar,
      maghrib: maghrib ?? this.maghrib,
      isya: isya ?? this.isya,
      volume: volume ?? this.volume,
      latitude: clearCoordinates ? null : (latitude ?? this.latitude),
      longitude: clearCoordinates ? null : (longitude ?? this.longitude),
      locationAccuracyMeters: clearCoordinates ? null : (locationAccuracyMeters ?? this.locationAccuracyMeters),
    );
  }

  bool isPrayerEnabled(String label) {
    switch (label) {
      case 'Subuh':
        return subuh;
      case 'Dzuhur':
        return dzuhur;
      case 'Ashar':
        return ashar;
      case 'Maghrib':
        return maghrib;
      case 'Isya':
        return isya;
      default:
        return false;
    }
  }
}

class PrayerAdzanScheduleResult {
  final int scheduledCount;
  final bool exactAlarm;
  final String city;
  final String? error;

  const PrayerAdzanScheduleResult({
    required this.scheduledCount,
    required this.exactAlarm,
    required this.city,
    this.error,
  });

  bool get success => error == null;
}

class PrayerAdzanPermissionState {
  final bool notificationsAllowed;
  final bool exactAlarmAllowed;

  const PrayerAdzanPermissionState({
    required this.notificationsAllowed,
    required this.exactAlarmAllowed,
  });
}

class PrayerAdzanService {
  PrayerAdzanService._();

  static final PrayerAdzanService instance = PrayerAdzanService._();

  static const _keyEnabled = 'auto_adzan_enabled';
  static const _keyCity = 'auto_adzan_city';
  static const _keySubuh = 'auto_adzan_subuh';
  static const _keyDzuhur = 'auto_adzan_dzuhur';
  static const _keyAshar = 'auto_adzan_ashar';
  static const _keyMaghrib = 'auto_adzan_maghrib';
  static const _keyIsya = 'auto_adzan_isya';
  static const _keyScheduledIds = 'auto_adzan_scheduled_ids';
  static const _keyLastCount = 'auto_adzan_last_count';
  static const _keyLastSync = 'auto_adzan_last_sync';
  static const _keyVolume = 'auto_adzan_volume';
  static const _keyLatitude = 'auto_adzan_latitude';
  static const _keyLongitude = 'auto_adzan_longitude';
  static const _keyLocationAccuracy = 'auto_adzan_location_accuracy';

  static const int scheduleDays = 60;
  static const String channelId = 'auto_adzan_v6_adhan';
  static const String subuhChannelId = 'auto_adzan_v6_adhan_subuh';

  static const MethodChannel _native =
      MethodChannel('fang_shadow/adzan_native');

  bool _initialized = false;

  Future<void> initialize() async {
    if (_initialized) return;

    tzdata.initializeTimeZones();
    // Device ini ditujukan untuk jadwal Indonesia. Untuk jadwal kota, timezone
    // tetap diambil dari metadata AlAdhan (Asia/Jakarta/Makassar/Jayapura).
    // Offset sistem hanya dipakai sebagai fallback saat metadata tidak tersedia.
    try {
      final offset = DateTime.now().timeZoneOffset.inHours;
      final fallback = offset >= 9
          ? 'Asia/Jayapura'
          : offset >= 8
              ? 'Asia/Makassar'
              : 'Asia/Jakarta';
      tz.setLocalLocation(tz.getLocation(fallback));
    } catch (_) {}

    // Suara adzan tidak lagi memakai notification sound.
    // Playback ditangani foreground service native agar tidak putus saat
    // notification shade dibuka dan Subuh dapat memakai audio khusus.


    _initialized = true;
  }

  Future<PrayerAdzanSettings> loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    return PrayerAdzanSettings(
      enabled: prefs.getBool(_keyEnabled) ?? false,
      city: prefs.getString(_keyCity) ?? 'Surabaya',
      subuh: prefs.getBool(_keySubuh) ?? true,
      dzuhur: prefs.getBool(_keyDzuhur) ?? true,
      ashar: prefs.getBool(_keyAshar) ?? true,
      maghrib: prefs.getBool(_keyMaghrib) ?? true,
      isya: prefs.getBool(_keyIsya) ?? true,
      volume: (prefs.getDouble(_keyVolume) ?? 1.0).clamp(0.05, 1.0),
      latitude: prefs.getDouble(_keyLatitude),
      longitude: prefs.getDouble(_keyLongitude),
      locationAccuracyMeters: prefs.getDouble(_keyLocationAccuracy),
    );
  }

  Future<void> saveSettings(PrayerAdzanSettings settings) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyEnabled, settings.enabled);
    await prefs.setString(_keyCity, settings.city.trim().isEmpty ? 'Surabaya' : settings.city.trim());
    await prefs.setBool(_keySubuh, settings.subuh);
    await prefs.setBool(_keyDzuhur, settings.dzuhur);
    await prefs.setBool(_keyAshar, settings.ashar);
    await prefs.setBool(_keyMaghrib, settings.maghrib);
    await prefs.setBool(_keyIsya, settings.isya);
    await prefs.setDouble(_keyVolume, settings.volume.clamp(0.05, 1.0));
    if (settings.latitude != null && settings.longitude != null) {
      await prefs.setDouble(_keyLatitude, settings.latitude!);
      await prefs.setDouble(_keyLongitude, settings.longitude!);
      if (settings.locationAccuracyMeters != null) {
        await prefs.setDouble(_keyLocationAccuracy, settings.locationAccuracyMeters!);
      }
    } else {
      await prefs.remove(_keyLatitude);
      await prefs.remove(_keyLongitude);
      await prefs.remove(_keyLocationAccuracy);
    }
  }


  Future<PrayerAdzanSettings> detectPreciseLocation() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      throw Exception('GPS/Location Service belum aktif. Aktifkan lokasi perangkat lalu coba lagi.');
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      throw Exception('Izin lokasi presisi belum diberikan. Aktifkan Precise Location untuk hasil jadwal terbaik.');
    }

    final accuracyStatus = await Geolocator.getLocationAccuracy();
    if (accuracyStatus == LocationAccuracyStatus.reduced) {
      throw Exception('Android sedang memakai lokasi perkiraan. Aktifkan Precise Location agar jadwal mengikuti posisi sebenarnya.');
    }

    final position = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.bestForNavigation,
      timeLimit: const Duration(seconds: 20),
    );

    String label = 'Lokasi GPS';
    try {
      final places = await placemarkFromCoordinates(position.latitude, position.longitude);
      if (places.isNotEmpty) {
        final p = places.first;
        final parts = <String>[
          if ((p.subAdministrativeArea ?? '').trim().isNotEmpty) p.subAdministrativeArea!.trim(),
          if ((p.administrativeArea ?? '').trim().isNotEmpty) p.administrativeArea!.trim(),
        ];
        if (parts.isNotEmpty) label = parts.join(', ');
      }
    } catch (_) {}

    final current = await loadSettings();
    final updated = current.copyWith(
      city: label,
      latitude: position.latitude,
      longitude: position.longitude,
      locationAccuracyMeters: position.accuracy,
    );
    await saveSettings(updated);
    return updated;
  }

  Future<void> updateCity(String city) async {
    final clean = city.trim();
    if (clean.isEmpty) return;
    final current = await loadSettings();
    if (current.city == clean) return;
    final updated = current.copyWith(city: clean, clearCoordinates: true);
    await saveSettings(updated);
    if (updated.enabled) {
      await scheduleAdzan(updated);
    }
  }

  Future<PrayerAdzanPermissionState> permissionState() async {
    await initialize();
    if (!Platform.isAndroid) {
      return const PrayerAdzanPermissionState(
        notificationsAllowed: true,
        exactAlarmAllowed: true,
      );
    }

    final notificationStatus = await Permission.notification.status;
    final exact = await _native.invokeMethod<bool>('canScheduleExactAlarms');
    return PrayerAdzanPermissionState(
      notificationsAllowed: notificationStatus.isGranted,
      exactAlarmAllowed: exact ?? true,
    );
  }

  Future<PrayerAdzanPermissionState> requestPermissions() async {
    await initialize();
    if (!Platform.isAndroid) {
      return const PrayerAdzanPermissionState(
        notificationsAllowed: true,
        exactAlarmAllowed: true,
      );
    }

    final notificationStatus = await Permission.notification.request();
    var exact = await _native.invokeMethod<bool>('canScheduleExactAlarms');
    if (exact == false) {
      await _native.invokeMethod<bool>('requestExactAlarmPermission');
      exact = await _native.invokeMethod<bool>('canScheduleExactAlarms');
    }

    final notificationsAllowed = notificationStatus.isGranted;
    return PrayerAdzanPermissionState(
      notificationsAllowed: notificationsAllowed,
      exactAlarmAllowed: exact ?? true,
    );
  }

  Future<void> refreshIfEnabled() async {
    await initialize();
    final settings = await loadSettings();
    if (!settings.enabled) return;

    final prefs = await SharedPreferences.getInstance();
    final rawLastSync = prefs.getString(_keyLastSync);
    final lastSync = rawLastSync == null ? null : DateTime.tryParse(rawLastSync);

    // Tidak perlu download ulang kalender pada setiap app dibuka.
    // Refresh setelah 7 hari agar horizon 60 hari tetap panjang.
    if (lastSync == null || DateTime.now().difference(lastSync).inDays >= 7) {
      await scheduleAdzan(settings);
    }
  }

  Future<PrayerAdzanScheduleResult> applySettings(
    PrayerAdzanSettings settings, {
    bool requestPermission = true,
  }) async {
    await saveSettings(settings);
    if (!settings.enabled) {
      await cancelScheduledAdzan();
      return PrayerAdzanScheduleResult(
        scheduledCount: 0,
        exactAlarm: false,
        city: settings.city,
      );
    }

    if (requestPermission) {
      await requestPermissions();
    }
    return scheduleAdzan(settings);
  }

  Future<PrayerAdzanScheduleResult> scheduleAdzan(
    PrayerAdzanSettings settings,
  ) async {
    await initialize();

    final cleanCity = settings.city.trim().isEmpty ? 'Surabaya' : settings.city.trim();
    // Jangan hapus alarm lama sebelum jadwal baru benar-benar berhasil dibuat.
    // Kalau API/koneksi sedang bermasalah, alarm lama tetap aman dan tetap berbunyi.
    final prefs = await SharedPreferences.getInstance();
    final previousIds = (prefs.getStringList(_keyScheduledIds) ?? const <String>[])
        .map(int.tryParse)
        .whereType<int>()
        .toSet();

    try {
      final permission = await permissionState();
      if (!permission.notificationsAllowed) {
        return PrayerAdzanScheduleResult(
          scheduledCount: 0,
          exactAlarm: permission.exactAlarmAllowed,
          city: cleanCity,
          error: 'Izin notifikasi belum diberikan. Buka izin Android lalu simpan ulang Auto Adzan.',
        );
      }
      final now = tz.TZDateTime.now(tz.local);
      final horizon = now.add(const Duration(days: scheduleDays));
      final scheduledIds = <int>[];
      var cursor = DateTime(now.year, now.month, 1);
      final endMonth = DateTime(horizon.year, horizon.month, 1);

      while (!cursor.isAfter(endMonth)) {
        final monthData = await _fetchCalendarMonth(
          city: cleanCity,
          latitude: settings.latitude,
          longitude: settings.longitude,
          year: cursor.year,
          month: cursor.month,
        );

        for (final dynamic rawDay in monthData) {
          if (rawDay is! Map) continue;
          final day = Map<String, dynamic>.from(rawDay);
          final gregorian = day['date']?['gregorian'] as Map?;
          final dateText = gregorian?['date']?.toString() ?? '';
          final date = _parseGregorianDate(dateText);
          if (date == null) continue;

          final meta = day['meta'];
          final cityTimezone = meta is Map ? meta['timezone']?.toString() : null;
          final location = _safeLocation(cityTimezone);
          final localNow = tz.TZDateTime.now(location);
          final localHorizon = localNow.add(const Duration(days: scheduleDays));

          final timingsRaw = day['timings'];
          if (timingsRaw is! Map) continue;
          final timings = Map<String, dynamic>.from(timingsRaw);

          final prayers = <(String, String)>[
            ('Subuh', 'Fajr'),
            ('Dzuhur', 'Dhuhr'),
            ('Ashar', 'Asr'),
            ('Maghrib', 'Maghrib'),
            ('Isya', 'Isha'),
          ];

          for (var prayerIndex = 0; prayerIndex < prayers.length; prayerIndex++) {
            final prayer = prayers[prayerIndex];
            if (!settings.isPrayerEnabled(prayer.$1)) continue;

            final hm = _extractHourMinute(timings[prayer.$2]?.toString() ?? '');
            if (hm == null) continue;

            final target = tz.TZDateTime(
              location,
              date.year,
              date.month,
              date.day,
              hm.$1,
              hm.$2,
            );

            if (!target.isAfter(localNow) || target.isAfter(localHorizon)) continue;

            // ID stabil berdasarkan tanggal + sholat. Ini mencegah collision
            // ketika sinkronisasi dilakukan lagi pada bulan berikutnya.
            final id = ((date.year % 100) * 1000000) +
                (date.month * 10000) +
                (date.day * 100) +
                prayerIndex;
            await _native.invokeMethod<bool>('scheduleAlarm', {
              'id': id,
              'epochMillis': target.millisecondsSinceEpoch,
              'prayerName': prayer.$1,
              'city': cleanCity,
              'volume': settings.volume.clamp(0.05, 1.0),
            });
            scheduledIds.add(id);
          }
        }

        cursor = DateTime(cursor.year, cursor.month + 1, 1);
      }

      if (scheduledIds.isEmpty) {
        return PrayerAdzanScheduleResult(
          scheduledCount: 0,
          exactAlarm: permission.exactAlarmAllowed,
          city: cleanCity,
          error: 'Tidak ada jadwal yang berhasil dipasang. Periksa nama kota dan koneksi internet.',
        );
      }

      // Jadwal baru berhasil. Baru sekarang hapus alarm lama yang tidak
      // termasuk daftar baru. Alarm dengan ID sama otomatis diperbarui.
      final newIds = scheduledIds.toSet();
      for (final staleId in previousIds.difference(newIds)) {
        try {
          await _native.invokeMethod<bool>('cancelAlarm', {'id': staleId});
        } catch (_) {}
      }

      await prefs.setStringList(
        _keyScheduledIds,
        scheduledIds.map((e) => e.toString()).toList(),
      );
      await prefs.setInt(_keyLastCount, scheduledIds.length);
      await prefs.setString(_keyLastSync, DateTime.now().toIso8601String());

      return PrayerAdzanScheduleResult(
        scheduledCount: scheduledIds.length,
        exactAlarm: permission.exactAlarmAllowed,
        city: cleanCity,
      );
    } catch (e) {
      return PrayerAdzanScheduleResult(
        scheduledCount: 0,
        exactAlarm: false,
        city: cleanCity,
        error: e.toString(),
      );
    }
  }

  Future<void> cancelScheduledAdzan() async {
    await initialize();
    final prefs = await SharedPreferences.getInstance();
    final ids = prefs.getStringList(_keyScheduledIds) ?? const <String>[];
    for (final raw in ids) {
      final id = int.tryParse(raw);
      if (id != null) {
        try {
          await _native.invokeMethod<bool>('cancelAlarm', {'id': id});
        } catch (_) {}
      }
    }
    await prefs.remove(_keyScheduledIds);
    await prefs.setInt(_keyLastCount, 0);
  }

  Future<int> lastScheduledCount() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_keyLastCount) ?? 0;
  }

  Future<DateTime?> lastSync() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_keyLastSync);
    return raw == null ? null : DateTime.tryParse(raw);
  }

  Future<void> testAdzan({bool subuh = false}) async {
    await initialize();
    final settings = await loadSettings();
    await _native.invokeMethod<bool>('playTest', {
      'prayerName': subuh ? 'Subuh' : 'Dzuhur',
      'volume': settings.volume.clamp(0.05, 1.0),
    });
  }

  Future<void> setPlaybackVolume(double volume) async {
    final safe = volume.clamp(0.05, 1.0).toDouble();
    final current = await loadSettings();
    await saveSettings(current.copyWith(volume: safe));
    await _native.invokeMethod<bool>('setAdzanVolume', {
      'volume': safe,
    });
  }

  Future<void> stopAdzan() async {
    await _native.invokeMethod<bool>('stopAdzan');
  }


  Future<List<dynamic>> _fetchCalendarMonth({
    required String city,
    required double? latitude,
    required double? longitude,
    required int year,
    required int month,
  }) async {
    final hasGps = latitude != null && longitude != null;
    final uri = hasGps
        ? Uri.https(
            'api.aladhan.com',
            '/v1/calendar/$year/$month',
            <String, String>{
              'latitude': latitude.toString(),
              'longitude': longitude.toString(),
              // Kementerian Agama Republik Indonesia.
              'method': '20',
            },
          )
        : Uri.https(
            'api.aladhan.com',
            '/v1/calendarByCity/$year/$month',
            <String, String>{
              'city': city,
              'country': 'Indonesia',
              'method': '20',
            },
          );

    final response = await http.get(uri).timeout(const Duration(seconds: 15));
    if (response.statusCode != 200) {
      throw Exception('Gagal mengambil jadwal sholat (${response.statusCode})');
    }

    final decoded = jsonDecode(response.body);
    if (decoded is! Map || decoded['data'] is! List) {
      throw Exception('Format jadwal sholat tidak valid');
    }
    return decoded['data'] as List<dynamic>;
  }

  tz.Location _safeLocation(String? identifier) {
    if (identifier != null && identifier.trim().isNotEmpty) {
      try {
        return tz.getLocation(identifier.trim());
      } catch (_) {}
    }
    return tz.local;
  }

  DateTime? _parseGregorianDate(String value) {
    final parts = value.split('-');
    if (parts.length != 3) return null;
    final day = int.tryParse(parts[0]);
    final month = int.tryParse(parts[1]);
    final year = int.tryParse(parts[2]);
    if (day == null || month == null || year == null) return null;
    return DateTime(year, month, day);
  }

  (int, int)? _extractHourMinute(String value) {
    final match = RegExp(r'(\d{1,2}):(\d{2})').firstMatch(value);
    if (match == null) return null;
    final hour = int.tryParse(match.group(1) ?? '');
    final minute = int.tryParse(match.group(2) ?? '');
    if (hour == null || minute == null) return null;
    return (hour, minute);
  }
}
