import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'api_config.dart';
import 'fang_global_theme.dart';

class ManageServerPage extends StatefulWidget {
  final String keyToken;
  const ManageServerPage({super.key, required this.keyToken});

  @override
  State<ManageServerPage> createState() => _ManageServerPageState();
}

class _ManageServerPageState extends State<ManageServerPage> {
  final _hostController = TextEditingController();
  final _userController = TextEditingController();
  final _passController = TextEditingController();

  List<Map<String, dynamic>> _servers = const [];
  bool _loading = true;
  bool _saving = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetch();
  }

  @override
  void dispose() {
    _hostController.dispose();
    _userController.dispose();
    _passController.dispose();
    super.dispose();
  }

  Future<http.Response> _get(Uri uri) =>
      http.get(uri).timeout(const Duration(seconds: 15));

  Future<http.Response> _post(Uri uri, Map<String, String> body) =>
      http.post(uri, body: body).timeout(const Duration(seconds: 15));

  dynamic _decode(http.Response response) {
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Server error ${response.statusCode}');
    }
    return jsonDecode(utf8.decode(response.bodyBytes));
  }

  Future<void> _fetch() async {
    if (mounted) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }
    try {
      final uri = Uri.parse('$baseUrl/myServer').replace(
        queryParameters: {'key': widget.keyToken},
      );
      final decoded = _decode(await _get(uri));
      List<Map<String, dynamic>> servers;
      if (decoded is List) {
        servers = decoded.whereType<Map>().map(Map<String, dynamic>.from).toList();
      } else if (decoded is Map && decoded['data'] is List) {
        servers = (decoded['data'] as List)
            .whereType<Map>()
            .map(Map<String, dynamic>.from)
            .toList();
      } else {
        servers = const [];
      }
      if (!mounted) return;
      setState(() => _servers = servers);
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = 'Gagal mengambil server: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _add() async {
    final host = _hostController.text.trim();
    final user = _userController.text.trim();
    final pass = _passController.text;
    if (host.isEmpty || user.isEmpty || pass.isEmpty) {
      _snack('Host, username, dan password wajib diisi.', error: true);
      return;
    }

    setState(() => _saving = true);
    try {
      final response = await _post(Uri.parse('$baseUrl/addServer'), {
        'key': widget.keyToken,
        'host': host,
        'username': user,
        'password': pass,
      });
      final decoded = _decode(response);
      final ok = decoded is Map
          ? decoded['success'] == true || decoded['status'] == true
          : response.statusCode >= 200 && response.statusCode < 300;
      if (!ok) {
        throw Exception(
          decoded is Map
              ? (decoded['error'] ?? decoded['message'] ?? 'Ditolak server')
              : 'Ditolak server',
        );
      }
      _hostController.clear();
      _userController.clear();
      _passController.clear();
      if (mounted) Navigator.pop(context);
      await _fetch();
      if (mounted) _snack('Server berhasil ditambahkan.');
    } catch (e) {
      if (mounted) _snack('Gagal menambah server: $e', error: true);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _delete(String host) async {
    if (host.isEmpty) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus server?'),
        content: Text(host),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('BATAL')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('HAPUS')),
        ],
      ),
    );
    if (confirmed != true) return;

    try {
      final decoded = _decode(await _post(Uri.parse('$baseUrl/delServer'), {
        'key': widget.keyToken,
        'host': host,
      }));
      if (decoded is Map &&
          decoded['success'] != true &&
          decoded['status'] != true) {
        throw Exception(decoded['error'] ?? decoded['message'] ?? 'Ditolak server');
      }
      await _fetch();
      if (mounted) _snack('Server dihapus.');
    } catch (e) {
      if (mounted) _snack('Gagal menghapus server: $e', error: true);
    }
  }

  void _snack(String text, {bool error = false}) {
    final fang = FangThemeController.instance.config;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text),
        backgroundColor: error ? const Color(0xFFB42318) : fang.accentColor,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _showAdd() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        final fang = FangThemeController.instance.config;
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(ctx).viewInsets.bottom,
          ),
          child: Container(
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
            decoration: BoxDecoration(
              color: fang.surface,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
              border: Border(top: BorderSide(color: fang.borderColor)),
            ),
            child: SafeArea(
              top: false,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: _hostController,
                    decoration: const InputDecoration(
                      labelText: 'Host / IP',
                      prefixIcon: Icon(Icons.dns_rounded),
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _userController,
                    decoration: const InputDecoration(
                      labelText: 'Username',
                      prefixIcon: Icon(Icons.person_rounded),
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _passController,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'Password',
                      prefixIcon: Icon(Icons.key_rounded),
                    ),
                  ),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _saving ? null : _add,
                      icon: const Icon(Icons.add_rounded),
                      label: const Text('TAMBAH SERVER'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: FangThemeController.instance,
      builder: (context, _) {
        final fang = FangThemeController.instance.config;
        return Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            title: const Text('Manage Server',
                style: TextStyle(fontWeight: FontWeight.w800)),
            actions: [
              IconButton(onPressed: _loading ? null : _fetch, icon: const Icon(Icons.refresh_rounded)),
            ],
          ),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: _showAdd,
            backgroundColor: fang.accentColor,
            foregroundColor: Colors.white,
            icon: const Icon(Icons.add_rounded),
            label: const Text('ADD'),
          ),
          body: FangBackground(
            child: _loading
                ? Center(child: CircularProgressIndicator(color: fang.accentColor))
                : RefreshIndicator(
                    onRefresh: _fetch,
                    color: fang.accentColor,
                    child: ListView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
                      children: [
                        if (_error != null)
                          FangCard(
                            padding: const EdgeInsets.all(14),
                            child: Text(_error!,
                                style: const TextStyle(color: Color(0xFFFF8A8A))),
                          ),
                        if (_error != null) const SizedBox(height: 12),
                        if (_servers.isEmpty)
                          FangCard(
                            padding: const EdgeInsets.all(24),
                            child: Column(
                              children: [
                                Icon(Icons.dns_outlined,
                                    color: fang.accentColor, size: 38),
                                const SizedBox(height: 12),
                                const Text('Belum ada server',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w800)),
                                const SizedBox(height: 5),
                                Text('Tekan ADD untuk menambahkan server.',
                                    style: TextStyle(
                                        color: fang.textSecondary, fontSize: 11)),
                              ],
                            ),
                          )
                        else
                          ..._servers.map((server) {
                            final host = (server['host'] ?? server['ip'] ?? '').toString();
                            final username = (server['username'] ?? server['user'] ?? '-').toString();
                            return Padding(
                              padding: const EdgeInsets.only(bottom: 10),
                              child: FangCard(
                                padding: const EdgeInsets.all(14),
                                child: Row(
                                  children: [
                                    const FangNeonIcon(icon: Icons.storage_rounded),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          SelectableText(host.isEmpty ? 'Unknown host' : host,
                                              style: const TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.w800)),
                                          const SizedBox(height: 4),
                                          Text(username,
                                              style: TextStyle(
                                                  color: fang.textSecondary,
                                                  fontSize: 11)),
                                        ],
                                      ),
                                    ),
                                    IconButton(
                                      tooltip: 'Hapus',
                                      onPressed: host.isEmpty ? null : () => _delete(host),
                                      icon: const Icon(Icons.delete_outline_rounded,
                                          color: Color(0xFFFF6B6B)),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          }),
                      ],
                    ),
                  ),
          ),
        );
      },
    );
  }
}
