#!/usr/bin/env bash
set -e
flutter clean
flutter pub get
flutter build apk --release --split-per-abi --tree-shake-icons
