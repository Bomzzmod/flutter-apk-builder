@echo off
call flutter clean
if errorlevel 1 exit /b 1
call flutter pub get
if errorlevel 1 exit /b 1
call flutter build apk --release --split-per-abi --tree-shake-icons
