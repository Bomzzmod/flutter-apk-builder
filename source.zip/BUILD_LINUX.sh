#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
flutter clean
flutter pub get
flutter build apk --release
echo "SUCCESS: build/app/outputs/flutter-apk/app-release.apk"
