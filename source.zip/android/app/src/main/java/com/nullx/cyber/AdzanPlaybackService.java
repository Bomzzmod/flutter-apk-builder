package com.nullx.cyber;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

public class AdzanPlaybackService extends Service {
    public static final String CHANNEL_ID = "fang_adzan_playback_v4";
    public static final String ACTION_STOP = "com.nullx.cyber.STOP_ADZAN";
    public static final String ACTION_SET_VOLUME = "com.nullx.cyber.SET_ADZAN_VOLUME";

    private MediaPlayer player;
    private PowerManager.WakeLock wakeLock;
    private AudioManager audioManager;
    private AudioFocusRequest audioFocusRequest;
    private int originalAlarmVolume = -1;

    @Override
    public void onCreate() {
        super.onCreate();
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        createChannel();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Adzan sedang diputar",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Notifikasi saat adzan sedang diputar");
            android.media.AudioAttributes notificationAudio = new android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            channel.setSound(android.provider.Settings.System.DEFAULT_NOTIFICATION_URI, notificationAudio);
            channel.enableVibration(true);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String prayerName, String city) {
        Intent openIntent = getPackageManager().getLaunchIntentForPackage(getPackageName());
        PendingIntent openPending = null;
        if (openIntent != null) {
            openIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            openPending = PendingIntent.getActivity(
                    this, 8302, openIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
        }

        Intent stopIntent = new Intent(this, AdzanPlaybackService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(
                this, 8303, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(getApplicationInfo().icon)
                .setContentTitle("Adzan " + prayerName)
                .setContentText(
                        "Waktu " + prayerName + " telah tiba" +
                        (city == null || city.isEmpty() ? "" : " di " + city)
                )
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setSilent(false)
                .setAutoCancel(false)
                .addAction(android.R.drawable.ic_media_pause, "STOP ADZAN", stopPending);

        if (openPending != null) b.setContentIntent(openPending);
        return b.build();
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(
                        PowerManager.PARTIAL_WAKE_LOCK,
                        "FangShadow:AdzanPlayback"
                );
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire(15 * 60 * 1000L);
            }
        } catch (Exception ignored) {}
    }

    private void requestAudioFocus() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest = new AudioFocusRequest.Builder(
                        AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
                )
                        .setAudioAttributes(
                                new AudioAttributes.Builder()
                                        .setUsage(AudioAttributes.USAGE_ALARM)
                                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                                        .build()
                        )
                        .setAcceptsDelayedFocusGain(false)
                        .setOnAudioFocusChangeListener(focusChange -> {
                            // Volume key / panel notification tidak boleh mem-pause adzan.
                            // Hanya OS audio focus yang benar-benar mengambil alih yang
                            // diabaikan di sini agar adzan tetap selesai.
                        })
                        .build();
                audioManager.requestAudioFocus(audioFocusRequest);
            } else {
                audioManager.requestAudioFocus(
                        focusChange -> {},
                        AudioManager.STREAM_ALARM,
                        AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
                );
            }
        } catch (Exception ignored) {}
    }

    private void abandonAudioFocus() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && audioFocusRequest != null) {
                audioManager.abandonAudioFocusRequest(audioFocusRequest);
            } else {
                audioManager.abandonAudioFocus(null);
            }
        } catch (Exception ignored) {}
        audioFocusRequest = null;
    }

    private void releaseWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Exception ignored) {}
        wakeLock = null;
    }

    private void stopPlayer() {
        try {
            if (player != null) {
                player.setOnCompletionListener(null);
                if (player.isPlaying()) player.stop();
                player.release();
            }
        } catch (Exception ignored) {}
        player = null;

        // Restore device alarm volume only after adzan finishes/stops.
        if (audioManager != null && originalAlarmVolume >= 0) {
            try {
                audioManager.setStreamVolume(
                        AudioManager.STREAM_ALARM,
                        originalAlarmVolume,
                        0
                );
            } catch (Exception ignored) {}
        }
        originalAlarmVolume = -1;

        abandonAudioFocus();
        releaseWakeLock();
    }

    private void startPlayback(String prayerName, String city, float volume) {
        stopPlayer();

        String normalized = prayerName == null ? "" : prayerName.trim().toLowerCase();
        String resourceName = normalized.equals("subuh") ? "adhan_subuh" : "adhan";
        int resId = getResources().getIdentifier(resourceName, "raw", getPackageName());

        if (resId == 0) {
            stopForeground(true);
            stopSelf();
            return;
        }

        float safeVolume = Math.max(0.05f, Math.min(1.0f, volume));

        // Set selected volume on ALARM stream. Pressing hardware volume +/- later
        // can still change this stream without touching MediaPlayer state.
        if (audioManager != null) {
            try {
                originalAlarmVolume = audioManager.getStreamVolume(AudioManager.STREAM_ALARM);
                int max = audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM);
                int desired = Math.max(1, Math.round(max * safeVolume));
                audioManager.setStreamVolume(AudioManager.STREAM_ALARM, desired, 0);
            } catch (Exception ignored) {}
        }

        startForeground(
                8301,
                buildNotification(
                        prayerName == null || prayerName.isEmpty() ? "Sholat" : prayerName,
                        city == null ? "" : city
                )
        );

        acquireWakeLock();
        requestAudioFocus();

        try {
            // Gunakan MediaPlayer.create(resource) agar tidak bergantung pada
            // openRawResourceFd(). AAPT/Gradle dapat mengemas MP3 terkompresi,
            // dan pada kondisi itu openRawResourceFd() bisa gagal.
            player = MediaPlayer.create(this, resId);
            if (player == null) {
                throw new IllegalStateException("MediaPlayer gagal membuat player untuk " + resourceName);
            }

            player.setAudioAttributes(
                    new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
            );
            player.setLooping(false);
            player.setVolume(safeVolume, safeVolume);
            try {
                player.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);
            } catch (Exception ignored) {}

            player.setOnCompletionListener(mp -> {
                stopPlayer();
                stopForeground(true);
                stopSelf();
            });

            player.setOnErrorListener((mp, what, extra) -> {
                stopPlayer();
                stopForeground(true);
                stopSelf();
                return true;
            });

            // MediaPlayer.create() sudah melakukan prepare().
            player.start();
        } catch (Exception e) {
            stopPlayer();
            stopForeground(true);
            stopSelf();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_SET_VOLUME.equals(intent.getAction())) {
            float value = intent.getFloatExtra("volume", 1.0f);
            float safe = Math.max(0.05f, Math.min(1.0f, value));
            try {
                if (player != null) {
                    player.setVolume(safe, safe);
                }
                if (audioManager != null) {
                    int max = audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM);
                    int desired = Math.max(1, Math.round(max * safe));
                    audioManager.setStreamVolume(
                            AudioManager.STREAM_ALARM,
                            desired,
                            AudioManager.FLAG_SHOW_UI
                    );
                }
            } catch (Exception ignored) {}
            return START_NOT_STICKY;
        }

        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopPlayer();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        String prayerName = intent == null ? "Sholat" : intent.getStringExtra("prayerName");
        String city = intent == null ? "" : intent.getStringExtra("city");
        float volume = intent == null ? 1.0f : intent.getFloatExtra("volume", 1.0f);

        startPlayback(prayerName, city, volume);
        return START_NOT_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // Jangan hentikan adzan hanya karena task UI diswipe/dipindah.
        // Playback tetap selesai lewat foreground service.
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        stopPlayer();
        stopForeground(true);
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
