package com.nullx.cyber;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AdzanAlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Intent service = new Intent(context, AdzanPlaybackService.class);
        service.putExtra("prayerName", intent.getStringExtra("prayerName"));
        service.putExtra("city", intent.getStringExtra("city"));
        service.putExtra("volume", intent.getFloatExtra("volume", 1.0f));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(service);
        } else {
            context.startService(service);
        }
    }
}
