package com.nullx.cyber;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;

import androidx.annotation.NonNull;

import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;

public class MainActivity extends FlutterActivity {
    private static final String CHANNEL = "fang_shadow/adzan_native";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Hardware volume +/- while app is active controls ALARM volume.
        // It never maps to play/pause/stop.
        setVolumeControlStream(AudioManager.STREAM_ALARM);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN &&
                (event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_UP ||
                 event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_DOWN)) {

            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                int direction = event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_UP
                        ? AudioManager.ADJUST_RAISE
                        : AudioManager.ADJUST_LOWER;

                am.adjustStreamVolume(
                        AudioManager.STREAM_ALARM,
                        direction,
                        AudioManager.FLAG_SHOW_UI
                );
            }
            // Consume the key: volume +/- only changes alarm volume.
            // It must never become play/pause/stop for adzan.
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);

        new MethodChannel(
                flutterEngine.getDartExecutor().getBinaryMessenger(),
                CHANNEL
        ).setMethodCallHandler((call, result) -> {
            try {
                switch (call.method) {
                    case "scheduleAlarm": {
                        Integer id = call.argument("id");
                        Long epochMillis = call.argument("epochMillis");
                        String prayerName = call.argument("prayerName");
                        String city = call.argument("city");
                        Double volume = call.argument("volume");

                        if (id == null || epochMillis == null) {
                            result.error("invalid_args", "id/epochMillis required", null);
                            return;
                        }

                        scheduleAlarm(
                                id,
                                epochMillis,
                                prayerName == null ? "Sholat" : prayerName,
                                city == null ? "" : city,
                                volume == null ? 1.0f : volume.floatValue()
                        );
                        result.success(true);
                        break;
                    }

                    case "cancelAlarm": {
                        Integer id = call.argument("id");
                        if (id != null) cancelAlarm(id);
                        result.success(true);
                        break;
                    }

                    case "canScheduleExactAlarms": {
                        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
                            result.success(true);
                        } else {
                            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                            result.success(am == null || am.canScheduleExactAlarms());
                        }
                        break;
                    }

                    case "requestExactAlarmPermission": {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                            intent.setData(Uri.parse("package:" + getPackageName()));
                            startActivity(intent);
                        }
                        result.success(true);
                        break;
                    }

                    case "playTest": {
                        String prayerName = call.argument("prayerName");
                        Double volume = call.argument("volume");

                        Intent service = new Intent(this, AdzanPlaybackService.class);
                        service.putExtra(
                                "prayerName",
                                prayerName == null ? "Dzuhur" : prayerName
                        );
                        service.putExtra("city", "TEST");
                        service.putExtra(
                                "volume",
                                volume == null ? 1.0f : volume.floatValue()
                        );

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            startForegroundService(service);
                        } else {
                            startService(service);
                        }

                        result.success(true);
                        break;
                    }

                    case "setAdzanVolume": {
                        Double volume = call.argument("volume");
                        Intent adjust = new Intent(this, AdzanPlaybackService.class);
                        adjust.setAction(AdzanPlaybackService.ACTION_SET_VOLUME);
                        adjust.putExtra(
                                "volume",
                                volume == null ? 1.0f : volume.floatValue()
                        );
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            startForegroundService(adjust);
                        } else {
                            startService(adjust);
                        }
                        result.success(true);
                        break;
                    }

                    case "stopAdzan": {
                        Intent stop = new Intent(this, AdzanPlaybackService.class);
                        stop.setAction(AdzanPlaybackService.ACTION_STOP);
                        startService(stop);
                        result.success(true);
                        break;
                    }

                    default:
                        result.notImplemented();
                }
            } catch (Exception e) {
                result.error("adzan_native_error", e.toString(), null);
            }
        });
    }

    private PendingIntent alarmPendingIntent(
            int id,
            String prayerName,
            String city,
            float volume
    ) {
        Intent intent = new Intent(this, AdzanAlarmReceiver.class);
        intent.putExtra("prayerName", prayerName);
        intent.putExtra("city", city);
        intent.putExtra("volume", volume);

        return PendingIntent.getBroadcast(
                this,
                id,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private void scheduleAlarm(
            int id,
            long epochMillis,
            String prayerName,
            String city,
            float volume
    ) {
        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        PendingIntent pi = alarmPendingIntent(id, prayerName, city, volume);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                    !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        epochMillis,
                        pi
                );
            } else {
                am.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        epochMillis,
                        pi
                );
            }
        } else {
            am.setExact(
                    AlarmManager.RTC_WAKEUP,
                    epochMillis,
                    pi
            );
        }
    }

    private void cancelAlarm(int id) {
        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        Intent intent = new Intent(this, AdzanAlarmReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(
                this,
                id,
                intent,
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
        );

        if (pi != null) {
            am.cancel(pi);
            pi.cancel();
        }
    }
}
