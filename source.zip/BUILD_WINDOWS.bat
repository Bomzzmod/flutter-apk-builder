@echo off
setlocal
cd /d %~dp0
echo [1/3] Flutter clean...
call flutter clean || goto :error
echo [2/3] Flutter pub get...
call flutter pub get || goto :error
echo [3/3] Build APK release...
call flutter build apk --release || goto :error
echo.
echo SUCCESS: build\app\outputs\flutter-apk\app-release.apk
pause
exit /b 0
:error
echo.
echo BUILD GAGAL. Copy error di atas lalu kirim untuk diperbaiki.
pause
exit /b 1
